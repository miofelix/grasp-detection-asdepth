"""`asdepth` 命令行入口。"""

from __future__ import annotations

from collections.abc import Sequence


def main(argv: Sequence[str] | None = None) -> int:
    """惰性导入根 CLI，保持包导入轻量。"""

    from .main import main as dispatch

    return dispatch(argv)


__all__ = ["main"]
