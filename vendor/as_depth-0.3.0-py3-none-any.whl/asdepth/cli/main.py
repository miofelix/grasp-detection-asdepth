"""AS-Depth 的统一命令行分发器。"""

from __future__ import annotations

import argparse
import importlib
import sys
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import cast

from asdepth import __version__
from asdepth.core.errors import AsDepthError

_EXPECTED_COMMAND_ERRORS = (AsDepthError, OSError, RuntimeError, ValueError)


@dataclass(frozen=True, slots=True)
class CommandSpec:
    """惰性命令目标，避免 `asdepth --help` 导入重型可选依赖。"""

    summary: str
    module: str
    function: str = "main"


COMMANDS: dict[str, CommandSpec] = {
    "train": CommandSpec("训练模型并写入统一 run 目录", "asdepth.training.cli"),
    "infer": CommandSpec("运行数据集或单样本推理", "asdepth.inference.cli"),
    "evaluate": CommandSpec("评估 PredictionArtifact 或旧 .npy 输出", "asdepth.evaluation.cli"),
    "export": CommandSpec("从 checkpoint 导出 ONNX", "asdepth.deployment.cli", "export_main"),
    "deploy": CommandSpec("构建并检查部署 runtime", "asdepth.deployment.cli", "deploy_main"),
    "realtime": CommandSpec("启动 D435 realtime 应用", "asdepth.realtime.cli"),
    "inspect": CommandSpec("检查包、资源、配置、模型或产物", "asdepth.cli.inspect"),
    "doctor": CommandSpec("检查本机依赖和可用后端", "asdepth.cli.doctor"),
}


def build_parser() -> argparse.ArgumentParser:
    """构建不导入任何命令实现的根 parser。"""

    parser = argparse.ArgumentParser(
        prog="asdepth",
        description="AS-Depth 训练、推理、评估、部署与 realtime 统一入口",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")
    for name, spec in COMMANDS.items():
        subparser = subparsers.add_parser(name, help=spec.summary, add_help=False)
        subparser.add_argument("args", nargs=argparse.REMAINDER, help=argparse.SUPPRESS)
    return parser


def _load_command(name: str) -> Callable[[Sequence[str] | None], int | None]:
    spec = COMMANDS[name]
    try:
        module = importlib.import_module(spec.module)
    except ModuleNotFoundError as exc:
        if exc.name == spec.module:
            raise RuntimeError(
                f"命令 {name!r} 的实现模块 {spec.module!r} 未包含在当前安装中；"
                "请确认 wheel 完整并重新安装。"
            ) from exc
        raise

    target = getattr(module, spec.function, None)
    if target is None or not callable(target):
        raise RuntimeError(f"命令 {name!r} 的入口 {spec.module}:{spec.function} 不存在或不可调用。")
    return cast(Callable[[Sequence[str] | None], int | None], target)


def _system_exit_code(exc: SystemExit) -> int:
    return exc.code if isinstance(exc.code, int) else 1


def _print_command_error(command: str, exc: Exception) -> None:
    detail = str(exc).strip() or type(exc).__name__
    print(f"asdepth {command}: error: {detail}", file=sys.stderr)


def main(argv: Sequence[str] | None = None) -> int:
    """分发 `asdepth` 子命令并返回进程状态码。"""

    arguments = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    if not arguments:
        parser.print_help()
        return 0

    if arguments[0] in {"-h", "--help"}:
        parser.print_help()
        return 0
    if arguments[0] in {"-V", "--version"}:
        print(f"asdepth {__version__}")
        return 0

    command = arguments[0]
    if command not in COMMANDS:
        parser.print_usage(sys.stderr)
        print(f"asdepth: error: unknown command: {command}", file=sys.stderr)
        return 2

    try:
        result = _load_command(command)(arguments[1:])
    except SystemExit as exc:
        return _system_exit_code(exc)
    except _EXPECTED_COMMAND_ERRORS as exc:
        _print_command_error(command, exc)
        return 2
    return int(result or 0)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
