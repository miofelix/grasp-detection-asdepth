"""检查已安装包及其 package data。"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections.abc import Sequence
from importlib import resources
from pathlib import Path
from typing import Any

from asdepth import __version__


def _resource_names() -> list[str]:
    root = resources.files("asdepth.resources")
    pending = [(root, "")]
    names: list[str] = []
    while pending:
        current, prefix = pending.pop()
        for item in current.iterdir():
            if item.name == "__pycache__" or item.name.endswith((".pyc", ".pyo")):
                continue
            relative = f"{prefix}{item.name}"
            if item.is_dir():
                pending.append((item, f"{relative}/"))
            else:
                names.append(relative)
    return sorted(names)


def package_report() -> dict[str, Any]:
    package_root = resources.files("asdepth")
    return {
        "version": __version__,
        "package_root": str(package_root),
        "resources": _resource_names(),
        "cwd": str(Path.cwd()),
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="asdepth inspect", description=__doc__)
    subparsers = parser.add_subparsers(dest="subject", required=True)
    package = subparsers.add_parser("package", help="显示安装位置和 package data")
    package.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    catalog = subparsers.add_parser("catalog", help="显示 canonical model catalog")
    catalog.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    checkpoint = subparsers.add_parser("checkpoint", help="只读检查 checkpoint 格式与模型身份")
    checkpoint.add_argument("path", help="checkpoint 文件、Accelerate 目录或 envelope 目录")
    checkpoint.add_argument("--model", help="无 manifest 时显式指定 canonical model_id")
    checkpoint.add_argument("--no-checksum", action="store_true", help="跳过 envelope checksum")
    checkpoint.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    return parser


def catalog_report() -> dict[str, Any]:
    from asdepth.models import ModelCatalog

    catalog = ModelCatalog.from_package()
    return {
        "count": len(catalog.entries),
        "models": [
            {
                "model_id": entry.model_id,
                "identity": entry.to_model_spec().identity,
                "entrypoint": entry.entrypoint,
                "depth": entry.depth.representation.value,
                "legacy_registry_name": entry.legacy_registry_name,
            }
            for entry in catalog.entries
        ],
    }


def checkpoint_report(
    path: str,
    *,
    model_id: str | None = None,
    verify_checksums: bool = True,
) -> dict[str, Any]:
    from asdepth.models import CheckpointLoader, ModelCatalog

    loaded = CheckpointLoader().load(path, verify_checksums=verify_checksums)
    catalog = ModelCatalog.from_package()
    resolution = catalog.resolve(
        checkpoint_manifest=loaded.manifest,
        model_id=model_id,
        checkpoint_path=path,
    )
    keys = list(loaded.state_dict)
    key_hash = hashlib.sha256("\n".join(keys).encode("utf-8")).hexdigest()
    return {
        "path": str(loaded.path),
        "format": loaded.checkpoint_format.value,
        "step": loaded.step,
        "state_key_count": len(keys),
        "state_keys_sha256": key_hash,
        "state_key_head": keys[:10],
        "model_id": resolution.spec.model_id,
        "model_identity": resolution.spec.identity,
        "depth": resolution.spec.depth.to_dict(),
        "resolution_source": resolution.source.value,
    }


def _print_report(report: dict[str, Any], *, as_json: bool) -> None:
    if as_json:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
        return
    for key, value in report.items():
        print(f"{key}: {value}")


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.subject == "package":
        report = package_report()
        if args.json:
            print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        print(f"AS-Depth {report['version']}")
        print(f"Package: {report['package_root']}")
        print("Resources:")
        for name in report["resources"]:
            print(f"  {name}")
        return 0
    if args.subject == "catalog":
        _print_report(catalog_report(), as_json=args.json)
        return 0
    if args.subject == "checkpoint":
        _print_report(
            checkpoint_report(
                args.path,
                model_id=args.model,
                verify_checksums=not args.no_checksum,
            ),
            as_json=args.json,
        )
        return 0
    raise AssertionError(args.subject)  # pragma: no cover - argparse enforces this
