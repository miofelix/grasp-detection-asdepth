"""检查 AS-Depth 基础依赖、可选组件与 runtime 能力。"""

from __future__ import annotations

import argparse
import importlib.metadata
import importlib.util
import json
import platform
import shutil
import sys
from collections.abc import Sequence
from typing import Any

from asdepth import __version__

BASE_DISTRIBUTIONS = ("numpy", "omegaconf", "opencv-python", "pyyaml", "safetensors", "torch")
OPTIONAL_DISTRIBUTIONS = (
    "accelerate",
    "onnx",
    "onnxruntime",
    "onnxscript",
    "pyrealsense2",
    "tensorrt",
    "wandb",
    "webdataset",
)


def _distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def collect_report() -> dict[str, Any]:
    """收集不修改环境的诊断报告。"""

    dependencies = {
        name: _distribution_version(name) for name in (*BASE_DISTRIBUTIONS, *OPTIONAL_DISTRIBUTIONS)
    }
    runtime: dict[str, Any] = {"cuda_available": False, "cuda_version": None, "gpu": None}
    if importlib.util.find_spec("torch") is not None:
        import torch

        runtime["cuda_available"] = torch.cuda.is_available()
        runtime["cuda_version"] = torch.version.cuda
        if torch.cuda.is_available():
            runtime["gpu"] = torch.cuda.get_device_name(0)

    return {
        "asdepth": __version__,
        "python": platform.python_version(),
        "executable": sys.executable,
        "platform": platform.platform(),
        "dependencies": dependencies,
        "runtime": runtime,
        "executables": {
            "trtexec": shutil.which("trtexec"),
        },
        "capabilities": {
            "torch": dependencies["torch"] is not None,
            "onnx": dependencies["onnx"] is not None,
            "onnxruntime": dependencies["onnxruntime"] is not None,
            "onnxscript": dependencies["onnxscript"] is not None,
            "tensorrt_python": dependencies["tensorrt"] is not None,
            "trtexec": shutil.which("trtexec") is not None,
            "realsense": dependencies["pyrealsense2"] is not None,
        },
    }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="asdepth doctor", description=__doc__)
    parser.add_argument("--json", action="store_true", help="输出机器可读 JSON")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="基础依赖缺失时返回非零；可选依赖缺失不算失败",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    report = collect_report()
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(f"AS-Depth {report['asdepth']} | Python {report['python']}")
        print(f"Platform: {report['platform']}")
        print(
            "Runtime: "
            f"CUDA={report['runtime']['cuda_available']} "
            f"version={report['runtime']['cuda_version']} "
            f"gpu={report['runtime']['gpu']}"
        )
        for name, value in report["dependencies"].items():
            print(f"  {name}: {value or 'not installed'}")

    missing_base = [name for name in BASE_DISTRIBUTIONS if report["dependencies"][name] is None]
    return 1 if args.strict and missing_base else 0
