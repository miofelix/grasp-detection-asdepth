"""深度序列的稳定点云锚点与视频装配。"""

from __future__ import annotations

import argparse
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import cv2
import numpy as np
from loguru import logger
from numpy.typing import NDArray
from tqdm import tqdm  # type: ignore[import-untyped]

from asdepth.data.io import read_rgb

_PAD_RATIO = 0.3
_TOTAL_POINTS_BUDGET = 2_000_000
_MIN_POINTS_PER_FRAME = 1_024
_PAD_BG_BGR = (255, 255, 255)


@dataclass(frozen=True, slots=True)
class SequenceAnchor:
    """一段深度序列共用的固定画布和三维旋转中心。"""

    canvas_hw: tuple[int, int]
    rot_center: NDArray[np.float32]
    num_points: int
    source: str


def stable_canvas_hw(height: int, width: int) -> tuple[int, int]:
    """返回与点云 reproject padding 契约一致的固定画布。"""

    if height < 1 or width < 1:
        raise ValueError("image height and width must be positive")
    pad = int(max(height, width) * _PAD_RATIO)
    return height + 2 * pad, width + 2 * pad


def parse_rot_center_cli(value: str) -> NDArray[np.float32]:
    """解析 ``x,y,z`` 三维旋转中心。"""

    parts = [part.strip() for part in value.split(",") if part.strip()]
    if len(parts) != 3:
        raise argparse.ArgumentTypeError(
            f'--rot-center requires three comma-separated floats "x,y,z", got {value!r}'
        )
    try:
        return np.asarray([float(part) for part in parts], dtype=np.float32)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"failed to parse --rot-center: {exc}") from exc


def load_rgb(path: Path) -> NDArray[np.uint8]:
    """通过 canonical reader 返回 RGB order 的 uint8 图像。"""

    return read_rgb(path)


def _depth_2d(
    load_depth: Callable[[str], NDArray[np.float32]],
    frame_id: str,
) -> NDArray[np.float32]:
    depth = np.asarray(load_depth(frame_id), dtype=np.float32).squeeze()
    if depth.ndim != 2:
        raise ValueError(f"load_depth({frame_id!r}) returned ndim={depth.ndim}; expected a 2D map")
    return depth


def precompute_sequence_anchor(
    frame_ids: Sequence[str],
    load_depth: Callable[[str], NDArray[np.float32]],
    intrinsics: NDArray[np.float32],
    max_depth: float,
    *,
    rng_seed: int = 0,
) -> SequenceAnchor:
    """从整段 metric depth 均匀采样，计算固定画布与平均三维中心。"""

    if not frame_ids:
        raise ValueError("frame_ids must not be empty")
    if max_depth <= 0:
        raise ValueError("max_depth must be positive")
    matrix = np.asarray(intrinsics, dtype=np.float32)
    if matrix.shape != (3, 3):
        raise ValueError(f"intrinsics must be 3x3, got {matrix.shape}")
    fx, fy = float(matrix[0, 0]), float(matrix[1, 1])
    if not np.isfinite(fx) or not np.isfinite(fy) or fx == 0.0 or fy == 0.0:
        raise ValueError("intrinsics fx/fy must be finite and non-zero")

    first_depth = _depth_2d(load_depth, frame_ids[0])
    height, width = first_depth.shape
    canvas_hw = stable_canvas_hw(height, width)
    max_per_frame = max(
        _MIN_POINTS_PER_FRAME,
        _TOTAL_POINTS_BUDGET // len(frame_ids),
    )
    cx, cy = float(matrix[0, 2]), float(matrix[1, 2])
    generator = np.random.default_rng(rng_seed)
    sum_xyz = np.zeros(3, dtype=np.float64)
    total_count = 0

    for index, frame_id in enumerate(tqdm(frame_ids, desc="Pre-scan rot_center", unit="frame")):
        depth = first_depth if index == 0 else _depth_2d(load_depth, frame_id)
        if depth.shape != (height, width):
            logger.warning(
                "Skipping frame {} with depth shape {} (expected {})",
                frame_id,
                depth.shape,
                (height, width),
            )
            continue
        valid = np.isfinite(depth) & (depth > 1e-8) & (depth <= max_depth)
        if not valid.any():
            continue
        ys, xs = np.where(valid)
        if xs.size > max_per_frame:
            selected = generator.choice(xs.size, size=max_per_frame, replace=False)
            ys, xs = ys[selected], xs[selected]
        z = depth[ys, xs].astype(np.float32, copy=False)
        x = (xs.astype(np.float32) - cx) * z / fx
        y = (ys.astype(np.float32) - cy) * z / fy
        sum_xyz += (float(x.sum()), float(y.sum()), float(z.sum()))
        total_count += int(z.size)

    if total_count == 0:
        raise ValueError(
            "sequence contains no finite depth values in (0, max_depth]; "
            "check depth scale and range"
        )
    return SequenceAnchor(
        canvas_hw=canvas_hw,
        rot_center=np.asarray(sum_xyz / total_count, dtype=np.float32),
        num_points=total_count,
        source="prescan",
    )


def resolve_sequence_anchor(
    frame_ids: Sequence[str],
    load_depth: Callable[[str], NDArray[np.float32]],
    intrinsics: NDArray[np.float32],
    max_depth: float,
    cli_rot_center: NDArray[np.float32] | None,
    rot_x_deg: float,
    rot_y_deg: float,
) -> SequenceAnchor:
    """按 CLI center > 正视短路 > 全段预扫描解析稳定锚点。"""

    if not frame_ids:
        raise ValueError("frame_ids must not be empty")
    first_depth = _depth_2d(load_depth, frame_ids[0])
    canvas_hw = stable_canvas_hw(*first_depth.shape)
    if cli_rot_center is not None:
        center = np.asarray(cli_rot_center, dtype=np.float32)
        if center.shape != (3,):
            raise ValueError(f"rotation center must have shape (3,), got {center.shape}")
        return SequenceAnchor(canvas_hw, center.copy(), 0, "cli")
    if rot_x_deg == 0.0 and rot_y_deg == 0.0:
        return SequenceAnchor(
            canvas_hw,
            np.zeros(3, dtype=np.float32),
            0,
            "frontal",
        )
    return precompute_sequence_anchor(
        frame_ids,
        load_depth,
        intrinsics,
        max_depth,
    )


def compute_canvas_size(frame_paths: Sequence[Path]) -> tuple[int, int]:
    """读取帧尺寸并返回不缩放视频所需的最大 ``(H, W)``。"""

    if not frame_paths:
        raise ValueError("frame_paths must not be empty")
    max_height = 0
    max_width = 0
    for frame_path in frame_paths:
        image = cv2.imread(str(frame_path), cv2.IMREAD_COLOR)
        if image is None:
            raise FileNotFoundError(f"cannot read video frame: {frame_path}")
        max_height = max(max_height, int(image.shape[0]))
        max_width = max(max_width, int(image.shape[1]))
    return max_height, max_width


def pad_to(
    image: NDArray[np.uint8],
    target_hw: tuple[int, int],
    bg_bgr: tuple[int, int, int] = _PAD_BG_BGR,
) -> NDArray[np.uint8]:
    """白底居中 padding 到目标尺寸，不拉伸内容。"""

    target_height, target_width = target_hw
    height, width = image.shape[:2]
    if height > target_height or width > target_width:
        raise ValueError(f"image {image.shape[:2]} does not fit target canvas {target_hw}")
    if (height, width) == target_hw:
        return image
    canvas = np.full((target_height, target_width, 3), bg_bgr, dtype=image.dtype)
    top = (target_height - height) // 2
    left = (target_width - width) // 2
    canvas[top : top + height, left : left + width] = image
    return canvas


def write_video(
    frame_paths: Sequence[Path],
    output_path: Path,
    fps: int,
    codec: str,
) -> tuple[int, int]:
    """将 RGB/JPEG 帧以最大画布居中写入视频。"""

    if fps < 1:
        raise ValueError("fps must be positive")
    if len(codec) != 4:
        raise ValueError("codec must contain exactly four characters")
    canvas_hw = compute_canvas_size(frame_paths)
    height, width = canvas_hw
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fourcc_factory: Any = cv2.VideoWriter_fourcc  # type: ignore[attr-defined]
    writer = cv2.VideoWriter(
        str(output_path),
        int(fourcc_factory(*codec)),
        fps,
        (width, height),
    )
    if not writer.isOpened():
        raise RuntimeError(
            f"failed to open video writer: {output_path} "
            f"(codec={codec}, fps={fps}, size={(width, height)})"
        )
    try:
        for frame_path in tqdm(frame_paths, desc="Writing frames", unit="frame"):
            image = cv2.imread(str(frame_path), cv2.IMREAD_COLOR)
            if image is None:
                raise FileNotFoundError(f"cannot read video frame: {frame_path}")
            writer.write(pad_to(cast(NDArray[np.uint8], image), canvas_hw))
    finally:
        writer.release()
    return canvas_hw


__all__ = [
    "SequenceAnchor",
    "compute_canvas_size",
    "load_rgb",
    "pad_to",
    "parse_rot_center_cli",
    "precompute_sequence_anchor",
    "resolve_sequence_anchor",
    "stable_canvas_hw",
    "write_video",
]
