"""安装包内可复用的深度与误差可视化。"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any, cast

import cv2
import numpy as np
from numpy.typing import NDArray
from PIL import Image, ImageDraw, ImageFont


def depth_percentile_range(
    depth: NDArray[Any],
    percentile_min: float = 1.0,
    percentile_max: float = 99.0,
    fallback_min: float = 0.0,
    fallback_max: float = 1.0,
) -> tuple[float, float]:
    """按有限正深度的百分位返回稳定可视化范围。"""

    values = np.asarray(depth, dtype=np.float32).squeeze()
    valid = (values > 0) & np.isfinite(values)
    if valid.any():
        lower_percentile = float(np.clip(percentile_min, 0.0, 100.0))
        upper_percentile = float(np.clip(percentile_max, 0.0, 100.0))
        if upper_percentile < lower_percentile:
            lower_percentile, upper_percentile = upper_percentile, lower_percentile
        lower, upper = np.percentile(
            values[valid],
            [lower_percentile, upper_percentile],
        )
        minimum, maximum = float(lower), float(upper)
    else:
        minimum, maximum = float(fallback_min), float(fallback_max)
    if maximum <= minimum:
        maximum = minimum + 1e-6
    return minimum, maximum


def _colormap(name: str, values: NDArray[np.float32], *, bytes_output: bool = False) -> Any:
    try:
        import matplotlib
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise RuntimeError(
            "depth visualization requires the 'eval' extra: pip install 'as-depth[eval]'"
        ) from exc
    return matplotlib.colormaps[name](values, bytes=bytes_output)


def colorize_depth(
    depth: NDArray[Any],
    vmin: float | None = None,
    vmax: float | None = None,
    cmap: str = "Spectral",
) -> NDArray[np.uint8]:
    """把 metric depth 上色为 RGB uint8；invalid 区域固定为黑色。"""

    values = np.asarray(depth, dtype=np.float32).squeeze()
    if values.ndim != 2:
        raise ValueError(f"depth must squeeze to 2D, got {values.shape}")
    valid = (values > 0) & np.isfinite(values)
    lower = 0.0 if vmin is None else float(vmin)
    upper = float(values[valid].max()) if vmax is None and valid.any() else vmax
    upper = 1.0 if upper is None else float(upper)
    if upper <= lower:
        upper = lower + 1e-6
    normalized = np.zeros_like(values, dtype=np.float32)
    normalized[valid] = np.clip((values[valid] - lower) / (upper - lower), 0.0, 1.0)
    colored = (_colormap(cmap, normalized)[..., :3] * 255).astype(np.uint8)
    colored[~valid] = 0
    return cast(NDArray[np.uint8], colored)


def colorize_relative_error(
    prediction: NDArray[Any],
    target: NDArray[Any],
    cmap: str = "magma",
) -> NDArray[np.uint8]:
    """把 ``|prediction-target|/target`` 上色，invalid 区域为黑色。"""

    pred = np.asarray(prediction, dtype=np.float32)
    truth = np.asarray(target, dtype=np.float32)
    if pred.shape != truth.shape:
        raise ValueError(f"prediction/target shapes differ: {pred.shape} vs {truth.shape}")
    valid = (truth > 0) & np.isfinite(truth) & np.isfinite(pred)
    error = np.zeros_like(truth, dtype=np.float32)
    error[valid] = np.clip(np.abs(pred[valid] - truth[valid]) / truth[valid], 0.0, 1.0)
    colored = np.asarray(_colormap(cmap, error, bytes_output=True)[..., :3], dtype=np.uint8)
    colored[~valid] = 0
    return colored


def make_grid(images: Sequence[NDArray[Any]], ncols: int) -> NDArray[np.uint8]:
    """把等尺寸 RGB panel 按固定列数拼成 grid。"""

    if ncols < 1 or not images or len(images) % ncols:
        raise ValueError("images must be non-empty and divisible by positive ncols")
    rows = [
        np.concatenate(
            [np.asarray(image, dtype=np.uint8) for image in images[index : index + ncols]],
            axis=1,
        )
        for index in range(0, len(images), ncols)
    ]
    return np.concatenate(rows, axis=0)


def blank_panel(
    height: int,
    width: int,
    color: tuple[int, int, int] = (255, 255, 255),
) -> NDArray[np.uint8]:
    """创建用于补齐对比图的纯色 RGB panel。"""

    if height < 1 or width < 1:
        raise ValueError("panel height and width must be positive")
    return np.full((height, width, 3), color, dtype=np.uint8)


def panels_grid(
    panels: Sequence[NDArray[Any]],
    *,
    rows: int,
    cols: int,
) -> NDArray[np.uint8]:
    """拼接固定 ``rows x cols`` 的 RGB panel。"""

    if rows < 1 or cols < 1 or len(panels) != rows * cols:
        raise ValueError(f"panels length must equal positive rows * cols, got {len(panels)}")
    return make_grid(panels, ncols=cols)


def letterbox_image(
    image: NDArray[Any],
    target_hw: tuple[int, int],
    *,
    color: tuple[int, int, int] = (255, 255, 255),
) -> NDArray[np.uint8]:
    """等比例缩放 RGB 图像并居中填充到 ``target_hw``。"""

    values = rgb_to_uint8(image)
    target_height, target_width = target_hw
    if target_height < 1 or target_width < 1:
        raise ValueError("letterbox target dimensions must be positive")
    source_height, source_width = values.shape[:2]
    scale = min(target_width / source_width, target_height / source_height)
    resized_width = max(1, round(source_width * scale))
    resized_height = max(1, round(source_height * scale))
    interpolation = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR
    resized = cv2.resize(values, (resized_width, resized_height), interpolation=interpolation)
    canvas = blank_panel(target_height, target_width, color)
    top = (target_height - resized_height) // 2
    left = (target_width - resized_width) // 2
    canvas[top : top + resized_height, left : left + resized_width] = resized
    return canvas


def shared_content_crop(
    images: Sequence[NDArray[Any]],
    *,
    background_threshold: int = 250,
    margin_ratio: float = 0.04,
) -> tuple[NDArray[np.uint8], ...]:
    """按多张同尺寸 RGB 图像的联合非背景区域执行同一裁剪。"""

    if not images:
        raise ValueError("images must not be empty")
    if not 0 <= background_threshold <= 255:
        raise ValueError("background_threshold must be in [0, 255]")
    if margin_ratio < 0:
        raise ValueError("margin_ratio must be non-negative")
    values = tuple(rgb_to_uint8(image) for image in images)
    reference_hw = values[0].shape[:2]
    if any(image.shape[:2] != reference_hw for image in values):
        raise ValueError("shared crop images must have identical spatial shapes")

    occupied = np.zeros(reference_hw, dtype=np.bool_)
    for image in values:
        occupied |= np.any(image < background_threshold, axis=2)
    rows = np.flatnonzero(occupied.any(axis=1))
    columns = np.flatnonzero(occupied.any(axis=0))
    if not rows.size or not columns.size:
        return values

    height, width = reference_hw
    margin = max(2, round(max(height, width) * margin_ratio))
    top = max(0, int(rows[0]) - margin)
    bottom = min(height, int(rows[-1]) + margin + 1)
    left = max(0, int(columns[0]) - margin)
    right = min(width, int(columns[-1]) + margin + 1)
    return tuple(image[top:bottom, left:right] for image in values)


def rgb_to_uint8(
    rgb: NDArray[Any],
    *,
    assume_float_range: float | None = None,
) -> NDArray[np.uint8]:
    """把三通道图像稳定转换为 uint8，不改变通道顺序。"""

    values = np.asarray(rgb)
    if values.ndim != 3 or values.shape[-1] != 3:
        raise ValueError(f"rgb must have shape (H, W, 3), got {values.shape}")
    if np.issubdtype(values.dtype, np.floating):
        scale = assume_float_range
        if scale is None:
            finite = values[np.isfinite(values)]
            scale = 1.0 if not finite.size or float(finite.max()) <= 1.5 else 255.0
        clipped = np.clip(values, 0.0, scale)
        if scale <= 1.5:
            clipped = clipped * 255.0
        return cast(NDArray[np.uint8], clipped.astype(np.uint8))
    return cast(NDArray[np.uint8], np.clip(values, 0, 255).astype(np.uint8))


def colorize_metric_depth(
    depth: NDArray[Any],
    min_depth: float,
    max_depth: float,
    *,
    percentile_min: float = 2.0,
    percentile_max: float = 98.0,
    cmap: str = "Spectral",
) -> NDArray[np.uint8]:
    """按有效像素百分位上色 metric depth，退化时使用显式范围。"""

    lower, upper = depth_percentile_range(
        depth,
        percentile_min=percentile_min,
        percentile_max=percentile_max,
        fallback_min=min_depth,
        fallback_max=max_depth,
    )
    if upper <= lower:
        lower, upper = float(min_depth), float(max_depth)
    if upper <= lower:
        upper = lower + 1e-6
    return colorize_depth(depth, vmin=lower, vmax=upper, cmap=cmap)


def add_title(
    image: NDArray[Any],
    title: str,
    height: int = 28,
    bg_color: tuple[int, int, int] = (255, 255, 255),
    text_color: tuple[int, int, int] = (0, 0, 0),
    text_offset: tuple[int, int] = (8, 6),
) -> NDArray[np.uint8]:
    """在 RGB 图像顶部增加标题条。"""

    if height < 1:
        raise ValueError("title height must be positive")
    panel = Image.fromarray(np.asarray(image, dtype=np.uint8)).convert("RGB")
    canvas = Image.new("RGB", (panel.width, panel.height + height), color=bg_color)
    canvas.paste(panel, (0, height))
    drawer = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.load_default()
    except OSError:  # pragma: no cover - Pillow fallback
        font = None
    drawer.text(text_offset, title, fill=text_color, font=font)
    return np.asarray(canvas)


def resize_depth_to(
    depth: NDArray[Any],
    target_hw: tuple[int, int],
) -> NDArray[np.float32]:
    """以 nearest 把深度 resize 到 ``(H, W)``。"""

    target_height, target_width = target_hw
    values = np.asarray(depth, dtype=np.float32)
    if values.shape == target_hw:
        return values
    return np.asarray(
        cv2.resize(values, (target_width, target_height), interpolation=cv2.INTER_NEAREST),
        dtype=np.float32,
    )


def resize_image_to(
    image: NDArray[Any],
    target_hw: tuple[int, int],
) -> NDArray[Any]:
    """以 linear 把图像 resize 到 ``(H, W)``。"""

    target_height, target_width = target_hw
    values = np.asarray(image)
    if values.shape[:2] == target_hw:
        return values
    return np.asarray(
        cv2.resize(values, (target_width, target_height), interpolation=cv2.INTER_LINEAR)
    )


def save_jpeg(
    path: str | Path,
    image: NDArray[Any],
    quality: int = 95,
    *,
    subsampling: int | None = None,
) -> Path:
    """保存 RGB JPEG；``subsampling=0`` 可显式使用 4:4:4。"""

    if not 1 <= quality <= 100:
        raise ValueError("JPEG quality must be in [1, 100]")
    if subsampling not in {None, 0, 1, 2}:
        raise ValueError("JPEG subsampling must be one of None, 0, 1, or 2")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    save_kwargs: dict[str, Any] = {"format": "JPEG", "quality": quality}
    if subsampling is not None:
        save_kwargs["subsampling"] = subsampling
    Image.fromarray(np.asarray(image, dtype=np.uint8), mode="RGB").save(target, **save_kwargs)
    return target


def save_rgb_image(
    path: str | Path,
    image: NDArray[Any],
    *,
    compress_level: int = 6,
) -> Path:
    """保存 RGB PNG，并只覆盖调用方指定的精确文件。"""

    if not 0 <= compress_level <= 9:
        raise ValueError("compress_level must be in [0, 9]")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(np.asarray(image, dtype=np.uint8), mode="RGB").save(
        target,
        format="PNG",
        compress_level=compress_level,
    )
    return target


__all__ = [
    "add_title",
    "blank_panel",
    "colorize_depth",
    "colorize_metric_depth",
    "colorize_relative_error",
    "depth_percentile_range",
    "letterbox_image",
    "make_grid",
    "panels_grid",
    "resize_depth_to",
    "resize_image_to",
    "rgb_to_uint8",
    "save_jpeg",
    "save_rgb_image",
    "shared_content_crop",
]
