"""设备无关的深度反投影与伪点云渲染。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, cast

import cv2
import numpy as np
from numpy.typing import NDArray

from .sequence import stable_canvas_hw

_PAD_RATIO = 0.3


def scale_intrinsics(
    intrinsics: NDArray[Any],
    original_hw: tuple[int, int],
    target_hw: tuple[int, int],
) -> NDArray[np.float32]:
    """按图像高宽缩放 ``fx/fy/cx/cy``，返回独立 3x3 float32 矩阵。"""

    matrix = np.asarray(intrinsics, dtype=np.float32)
    if matrix.shape != (3, 3):
        raise ValueError(f"intrinsics must be 3x3, got {matrix.shape}")
    if any(value < 1 for value in (*original_hw, *target_hw)):
        raise ValueError("image dimensions must be positive")
    scale_y = target_hw[0] / original_hw[0]
    scale_x = target_hw[1] / original_hw[1]
    scaled = matrix.copy()
    scaled[0] *= scale_x
    scaled[1] *= scale_y
    return cast(NDArray[np.float32], scaled)


def filter_pointcloud_knn(
    points: NDArray[np.float32],
    colors: NDArray[np.uint8],
    *,
    k: int = 16,
    std_ratio: float = 2.0,
) -> tuple[NDArray[np.float32], NDArray[np.uint8]]:
    """按 KNN 平均距离过滤离群点；scipy 不可用时保持输入不变。"""

    if k < 1 or points.shape[0] <= k:
        return points, colors
    try:
        from scipy.spatial import cKDTree  # type: ignore[import-untyped]
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise RuntimeError(
            "KNN point-cloud filtering requires the 'eval' extra: pip install 'as-depth[eval]'"
        ) from exc
    try:
        distances, _ = cKDTree(points).query(
            points,
            k=min(k + 1, points.shape[0]),
            workers=-1,
        )
    except Exception:
        return points, colors
    if distances.ndim == 1:
        return points, colors
    mean_distances = distances[:, 1:].mean(axis=1)
    finite = np.isfinite(mean_distances)
    if not finite.any():
        return points, colors
    values = mean_distances[finite]
    threshold = values.mean() + std_ratio * values.std()
    keep = finite & (mean_distances <= threshold)
    if not keep.any():
        return points, colors
    return points[keep], colors[keep]


@dataclass(frozen=True, slots=True)
class _CanvasConfig:
    height: int
    width: int
    pad: int
    canvas_height: int
    canvas_width: int
    supersample: int
    pad_scaled: int
    canvas_height_scaled: int
    canvas_width_scaled: int
    stable: bool


def _canvas_config(
    height: int,
    width: int,
    canvas_hw: tuple[int, int] | None,
    supersample: int,
) -> _CanvasConfig:
    expected_hw = stable_canvas_hw(height, width)
    if canvas_hw is not None and tuple(canvas_hw) != expected_hw:
        raise ValueError(f"canvas_hw={canvas_hw} does not match expected {expected_hw}")
    factor = max(1, int(supersample))
    pad = int(max(height, width) * _PAD_RATIO)
    return _CanvasConfig(
        height=height,
        width=width,
        pad=pad,
        canvas_height=expected_hw[0],
        canvas_width=expected_hw[1],
        supersample=factor,
        pad_scaled=pad * factor,
        canvas_height_scaled=expected_hw[0] * factor,
        canvas_width_scaled=expected_hw[1] * factor,
        stable=canvas_hw is not None,
    )


def _empty_canvas(
    config: _CanvasConfig,
    bg_color: tuple[int, int, int],
) -> NDArray[np.uint8]:
    shape = (
        (config.canvas_height, config.canvas_width, 3)
        if config.stable
        else (config.height, config.width, 3)
    )
    return np.full(shape, bg_color, dtype=np.uint8)


def _depth_to_points_and_colors(
    depth: NDArray[np.float32],
    intrinsics: NDArray[np.float32],
    rgb: NDArray[np.uint8],
) -> tuple[NDArray[np.float32], NDArray[np.uint8]] | None:
    height, width = depth.shape
    if rgb.shape[:2] != (height, width):
        raise ValueError(f"RGB/depth shapes differ: rgb={rgb.shape[:2]}, depth={depth.shape}")
    fx, fy = float(intrinsics[0, 0]), float(intrinsics[1, 1])
    cx, cy = float(intrinsics[0, 2]), float(intrinsics[1, 2])
    if not np.isfinite(fx) or not np.isfinite(fy) or fx == 0.0 or fy == 0.0:
        raise ValueError("intrinsics fx/fy must be finite and non-zero")
    u, v = np.meshgrid(np.arange(width), np.arange(height))
    valid = (depth > 1e-8) & np.isfinite(depth)
    if not valid.any():
        return None
    z = depth[valid]
    x = (u[valid] - cx) * z / fx
    y = (v[valid] - cy) * z / fy
    points = np.stack((x, y, z), axis=-1).astype(np.float32, copy=False)
    colors = np.clip(rgb, 0, 255).astype(np.uint8, copy=False)[valid]
    return points, colors


def depth_pointcloud_centroid(
    depth_map: NDArray[Any],
    intrinsics: NDArray[Any],
    *,
    knn_filter: bool = True,
    knn_k: int = 16,
    knn_std_ratio: float = 2.0,
) -> NDArray[np.float32]:
    """返回有效深度反投影点的质心，可选使用与渲染一致的 KNN 过滤。"""

    depth = np.asarray(depth_map, dtype=np.float32).squeeze()
    if depth.ndim != 2:
        raise ValueError(f"depth must squeeze to 2D, got {depth.shape}")
    matrix = np.asarray(intrinsics, dtype=np.float32)
    if matrix.shape != (3, 3):
        raise ValueError(f"intrinsics must be 3x3, got {matrix.shape}")
    rgb = np.zeros((*depth.shape, 3), dtype=np.uint8)
    projected = _depth_to_points_and_colors(depth, matrix, rgb)
    if projected is None:
        raise ValueError("depth has no valid point for a point-cloud centroid")
    points, colors = projected
    if knn_filter:
        points, _ = filter_pointcloud_knn(
            points,
            colors,
            k=knn_k,
            std_ratio=knn_std_ratio,
        )
    if not points.size:
        raise ValueError("point cloud is empty after KNN filtering")
    return np.asarray(points.mean(axis=0), dtype=np.float32)


def _rotate_points(
    points: NDArray[np.float32],
    rot_x_deg: float,
    rot_y_deg: float,
    rot_center: NDArray[Any] | None,
) -> NDArray[np.float32]:
    center = (
        np.asarray(rot_center, dtype=np.float32).reshape(3)
        if rot_center is not None
        else points.mean(axis=0)
    )
    centered = points - center
    rx, ry = np.radians(rot_x_deg), np.radians(rot_y_deg)
    cos_x, sin_x = np.cos(rx), np.sin(rx)
    cos_y, sin_y = np.cos(ry), np.sin(ry)
    x1 = centered[:, 0]
    y1 = centered[:, 1] * cos_x - centered[:, 2] * sin_x
    z1 = centered[:, 1] * sin_x + centered[:, 2] * cos_x
    x2 = x1 * cos_y + z1 * sin_y
    y2 = y1
    z2 = -x1 * sin_y + z1 * cos_y
    return np.asarray(np.stack((x2, y2, z2), axis=-1) + center, dtype=np.float32)


def _project_points(
    points: NDArray[np.float32],
    colors: NDArray[np.uint8],
    intrinsics: NDArray[np.float32],
    config: _CanvasConfig,
) -> tuple[NDArray[np.int32], NDArray[np.int32], NDArray[np.uint8]] | None:
    fx, fy = float(intrinsics[0, 0]), float(intrinsics[1, 1])
    cx, cy = float(intrinsics[0, 2]), float(intrinsics[1, 2])
    z = points[:, 2]
    keep = z > 1e-4
    if not keep.any():
        return None
    projected_u = points[keep, 0] * fx / z[keep] + cx
    projected_v = points[keep, 1] * fy / z[keep] + cy
    projected_z = z[keep]
    projected_colors = colors[keep]
    ui = np.round(projected_u * config.supersample + config.pad_scaled).astype(np.int32)
    vi = np.round(projected_v * config.supersample + config.pad_scaled).astype(np.int32)
    in_bounds = (
        (ui >= 0)
        & (ui < config.canvas_width_scaled)
        & (vi >= 0)
        & (vi < config.canvas_height_scaled)
    )
    ui = ui[in_bounds]
    vi = vi[in_bounds]
    projected_z = projected_z[in_bounds]
    projected_colors = projected_colors[in_bounds]
    order = np.argsort(-projected_z)
    return ui[order], vi[order], projected_colors[order]


def _splat(
    ui: NDArray[np.int32],
    vi: NDArray[np.int32],
    colors: NDArray[np.uint8],
    config: _CanvasConfig,
    bg_color: tuple[int, int, int],
) -> tuple[NDArray[np.uint8], NDArray[np.uint8]]:
    canvas = np.full(
        (config.canvas_height_scaled, config.canvas_width_scaled, 3),
        bg_color,
        dtype=np.uint8,
    )
    filled = np.zeros(
        (config.canvas_height_scaled, config.canvas_width_scaled),
        dtype=np.uint8,
    )
    for delta_u in range(2):
        for delta_v in range(2):
            splat_u = np.clip(ui + delta_u, 0, config.canvas_width_scaled - 1)
            splat_v = np.clip(vi + delta_v, 0, config.canvas_height_scaled - 1)
            canvas[splat_v, splat_u] = colors
            filled[splat_v, splat_u] = 255
    return canvas, filled


def _fill_holes(
    canvas: NDArray[np.uint8],
    filled: NDArray[np.uint8],
    supersample: int,
) -> NDArray[np.uint8]:
    dilate_size, blur_size = 2 * supersample + 1, 4 * supersample + 1
    kernel = np.ones((dilate_size, dilate_size), dtype=np.uint8)
    dilated = cast(NDArray[np.uint8], cv2.dilate(filled, kernel, iterations=1))
    holes = (dilated > 0) & (filled == 0)
    if holes.any():
        for channel in range(3):
            blurred = cv2.blur(canvas[:, :, channel].astype(np.float32), (blur_size, blur_size))
            canvas[:, :, channel][holes] = blurred[holes].astype(np.uint8)
    return dilated


def _finalize(
    canvas: NDArray[np.uint8],
    dilated: NDArray[np.uint8],
    config: _CanvasConfig,
) -> NDArray[np.uint8]:
    if config.stable:
        if config.supersample > 1:
            canvas = cast(
                NDArray[np.uint8],
                cv2.resize(
                    canvas,
                    (config.canvas_width, config.canvas_height),
                    interpolation=cv2.INTER_AREA,
                ),
            )
        return np.asarray(canvas, dtype=np.uint8)
    rows = np.any(dilated > 0, axis=1)
    columns = np.any(dilated > 0, axis=0)
    if rows.any() and columns.any():
        row_min, row_max = np.where(rows)[0][[0, -1]]
        column_min, column_max = np.where(columns)[0][[0, -1]]
        margin = 10 * config.supersample
        row_min = max(0, int(row_min) - margin)
        row_max = min(config.canvas_height_scaled - 1, int(row_max) + margin)
        column_min = max(0, int(column_min) - margin)
        column_max = min(config.canvas_width_scaled - 1, int(column_max) + margin)
        canvas = canvas[row_min : row_max + 1, column_min : column_max + 1]
    if config.supersample > 1:
        canvas = cast(
            NDArray[np.uint8],
            cv2.resize(
                canvas,
                (
                    max(1, canvas.shape[1] // config.supersample),
                    max(1, canvas.shape[0] // config.supersample),
                ),
                interpolation=cv2.INTER_AREA,
            ),
        )
    return np.asarray(canvas, dtype=np.uint8)


def render_pointcloud_reproject(
    depth_map: NDArray[Any],
    intrinsics: NDArray[Any],
    rgb_image: NDArray[Any],
    rot_x_deg: float = 25.0,
    rot_y_deg: float = 15.0,
    bg_color: tuple[int, int, int] = (255, 255, 255),
    knn_filter: bool = True,
    knn_k: int = 16,
    knn_std_ratio: float = 2.0,
    *,
    canvas_hw: tuple[int, int] | None = None,
    rot_center: NDArray[Any] | None = None,
    supersample: int = 1,
) -> NDArray[np.uint8]:
    """反投影 depth、旋转并重新投影为 RGB 伪点云视图。"""

    depth = np.asarray(depth_map, dtype=np.float32).squeeze()
    if depth.ndim != 2:
        raise ValueError(f"depth must squeeze to 2D, got {depth.shape}")
    matrix = np.asarray(intrinsics, dtype=np.float32)
    if matrix.shape != (3, 3):
        raise ValueError(f"intrinsics must be 3x3, got {matrix.shape}")
    rgb = np.asarray(rgb_image, dtype=np.uint8)
    config = _canvas_config(depth.shape[0], depth.shape[1], canvas_hw, supersample)
    projected = _depth_to_points_and_colors(depth, matrix, rgb)
    if projected is None:
        return _empty_canvas(config, bg_color)
    points, colors = projected
    if knn_filter:
        points, colors = filter_pointcloud_knn(
            points,
            colors,
            k=knn_k,
            std_ratio=knn_std_ratio,
        )
    rotated = _rotate_points(points, rot_x_deg, rot_y_deg, rot_center)
    canvas_points = _project_points(rotated, colors, matrix, config)
    if canvas_points is None:
        return _empty_canvas(config, bg_color)
    canvas, filled = _splat(*canvas_points, config, bg_color)
    dilated = _fill_holes(canvas, filled, config.supersample)
    return _finalize(canvas, dilated, config)


__all__ = [
    "depth_pointcloud_centroid",
    "filter_pointcloud_knn",
    "render_pointcloud_reproject",
    "scale_intrinsics",
]
