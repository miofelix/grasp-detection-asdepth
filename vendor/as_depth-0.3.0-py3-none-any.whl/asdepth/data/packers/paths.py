"""Packer 输入路径的显式、可测试解析规则。"""

from __future__ import annotations

import re
from pathlib import Path

SCENE_PATTERN = re.compile(r"^Scene\d+$")


def apply_prefix_mapping(
    raw_path: str,
    path_prefix_from: str | None,
    path_prefix_to: str | None,
) -> Path | None:
    if not path_prefix_from or not path_prefix_to:
        return None
    prefix = path_prefix_from.rstrip("/")
    if raw_path == prefix:
        suffix = ""
    elif raw_path.startswith(prefix + "/"):
        suffix = raw_path[len(prefix) + 1 :]
    else:
        return None
    return Path(path_prefix_to) / suffix


def apply_scene_suffix_mapping(raw_path: str, base_dir: Path) -> Path | None:
    parts = Path(raw_path).parts
    for index, part in enumerate(parts):
        if SCENE_PATTERN.match(part):
            return base_dir.joinpath(*parts[index:])
    return None


def resolve_data_path(
    raw_path: str,
    base_dir: Path,
    *,
    path_prefix_from: str | None = None,
    path_prefix_to: str | None = None,
    enable_scene_suffix_mapping: bool = False,
) -> Path:
    path = Path(raw_path).expanduser()
    if path.is_absolute():
        if path.exists():
            return path
        mapped = apply_prefix_mapping(raw_path, path_prefix_from, path_prefix_to)
        if mapped is not None:
            return mapped
        if enable_scene_suffix_mapping:
            scene_mapped = apply_scene_suffix_mapping(raw_path, base_dir)
            if scene_mapped is not None:
                return scene_mapped
        return path

    candidate = base_dir / path
    if candidate.exists():
        return candidate
    if enable_scene_suffix_mapping:
        scene_mapped = apply_scene_suffix_mapping(raw_path, base_dir)
        if scene_mapped is not None:
            return scene_mapped
    return candidate


def resolve_jsonl_path(path: str | None, base_dir: Path, default_name: str) -> Path:
    if not path:
        return base_dir / default_name
    jsonl_path = Path(path).expanduser()
    if jsonl_path.is_absolute():
        return jsonl_path
    cwd_path = Path.cwd() / jsonl_path
    if cwd_path.exists():
        return cwd_path
    base_path = base_dir / jsonl_path
    if base_path.exists():
        return base_path
    return cwd_path
