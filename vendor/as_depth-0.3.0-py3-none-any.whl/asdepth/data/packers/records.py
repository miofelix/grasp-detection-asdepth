"""Packer JSONL 的去重、别名解析和文件预检。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from asdepth.core import ContractError

from .paths import resolve_data_path
from .specs import FileSpec, PackerConfig


@dataclass(frozen=True, slots=True)
class PackerEntryFile:
    canonical_key: str
    tar_name: str
    is_binary: bool
    source_key: str
    source_path: str


@dataclass(frozen=True, slots=True)
class MissingFile:
    canonical_key: str
    path: Path
    missing_field: bool = False


def get_entry_value(
    entry: dict[str, Any],
    canonical_key: str,
    spec: FileSpec,
) -> tuple[str | None, str | None]:
    candidate_keys = spec.aliases or (canonical_key,)
    for source_key in candidate_keys:
        value = entry.get(source_key)
        if value:
            return source_key, str(value)
    return None, None


def get_sample_name(
    entry: dict[str, Any],
    config: PackerConfig,
    fallback_index: int = 0,
) -> str:
    for key in config.name_keys:
        value = entry.get(key)
        if value:
            return str(value)

    rgb_spec = config.file_specs.get("rgb")
    rgb_path: str | None = None
    if rgb_spec is not None:
        _, rgb_path = get_entry_value(entry, "rgb", rgb_spec)
    rgb_path = rgb_path or str(entry.get("rgb") or entry.get("left_img") or "")
    if rgb_path:
        sample_name = rgb_path.replace("/", "-").replace("\\", "-")
        for suffix in (".png", ".jpg", ".jpeg", ".npy", ".npz"):
            if sample_name.lower().endswith(suffix):
                return sample_name[: -len(suffix)]
        return sample_name
    return f"sample-{fallback_index:08d}"


def make_sample_key(sample_name: str) -> str:
    if not sample_name:
        raise ContractError("packer sample name cannot be empty")
    return sample_name.replace("@", "_").replace("/", "-").replace("\\", "-").replace(":", "-")


def iter_entry_files(
    entry: dict[str, Any],
    config: PackerConfig,
) -> tuple[PackerEntryFile, ...]:
    files: list[PackerEntryFile] = []
    for canonical_key, spec in config.file_specs.items():
        source_key, source_path = get_entry_value(entry, canonical_key, spec)
        if source_key is not None and source_path is not None:
            files.append(
                PackerEntryFile(
                    canonical_key=canonical_key,
                    tar_name=spec.tar_name,
                    is_binary=spec.is_binary,
                    source_key=source_key,
                    source_path=source_path,
                )
            )
    return tuple(files)


def find_missing_files(
    entry: dict[str, Any],
    base_dir: Path,
    config: PackerConfig,
    *,
    path_prefix_from: str | None = None,
    path_prefix_to: str | None = None,
) -> tuple[MissingFile, ...]:
    missing: list[MissingFile] = []
    for canonical_key, spec in config.file_specs.items():
        _, source_path = get_entry_value(entry, canonical_key, spec)
        if source_path is None:
            if spec.required:
                missing.append(
                    MissingFile(
                        canonical_key=canonical_key,
                        path=Path("<missing-jsonl-field>"),
                        missing_field=True,
                    )
                )
            continue
        resolved = resolve_data_path(
            source_path,
            base_dir,
            path_prefix_from=(path_prefix_from if config.enable_prefix_mapping else None),
            path_prefix_to=(path_prefix_to if config.enable_prefix_mapping else None),
            enable_scene_suffix_mapping=config.enable_scene_suffix_mapping,
        )
        if not resolved.is_file():
            missing.append(MissingFile(canonical_key=canonical_key, path=resolved))
    return tuple(missing)


def load_jsonl_entries(
    jsonl_path: Path,
    config: PackerConfig,
    *,
    malformed: Literal["raise", "skip"] = "raise",
) -> tuple[dict[str, Any], ...]:
    """读取并按稳定 sample key 去重；正式 API 默认拒绝损坏行。"""

    if malformed not in {"raise", "skip"}:
        raise ContractError(f"unsupported malformed policy {malformed!r}")
    entries: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    with jsonl_path.open(encoding="utf-8") as stream:
        for line_no, line in enumerate(stream, start=1):
            text = line.strip()
            if not text:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError as exc:
                if malformed == "skip":
                    continue
                raise ContractError(f"malformed JSONL line {line_no}: {jsonl_path}") from exc
            if not isinstance(payload, dict):
                if malformed == "skip":
                    continue
                raise ContractError(f"JSONL line {line_no} must be an object: {jsonl_path}")
            sample_key = make_sample_key(get_sample_name(payload, config, line_no))
            if sample_key in seen_keys:
                continue
            seen_keys.add(sample_key)
            entries.append(payload)
    return tuple(entries)
