"""与旧 `_common.py` 对齐、但不绑定 CLI 的 packer 配置契约。"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import Any

from asdepth.core import ContractError
from asdepth.core.serialization import frozen_mapping


@dataclass(frozen=True, slots=True)
class FileSpec:
    """一个 JSONL 文件字段到 WebDataset tar member 的映射。"""

    tar_name: str
    required: bool = False
    aliases: tuple[str, ...] = ()
    is_binary: bool = True

    def __post_init__(self) -> None:
        member = PurePosixPath(self.tar_name)
        if not self.tar_name or member.is_absolute() or ".." in member.parts:
            raise ContractError(f"unsafe packer tar_name {self.tar_name!r}")
        aliases = tuple(str(value) for value in self.aliases)
        if any(not value for value in aliases):
            raise ContractError("packer aliases cannot contain empty values")
        if len(set(aliases)) != len(aliases):
            raise ContractError("packer aliases must be unique")
        object.__setattr__(self, "aliases", aliases)


@dataclass(frozen=True, slots=True)
class SplitSpec:
    name: str
    default_jsonl_name: str
    cli_jsonl_flag: str

    def __post_init__(self) -> None:
        if not self.name or not self.default_jsonl_name:
            raise ContractError("packer split name and default_jsonl_name are required")
        if not self.cli_jsonl_flag.startswith("--"):
            raise ContractError("packer cli_jsonl_flag must start with '--'")


DEFAULT_SPLITS: tuple[SplitSpec, ...] = (SplitSpec("train", "train.jsonl", "--train-jsonl"),)


ScanEntries = Callable[[Path, Any, SplitSpec], list[dict[str, Any]]]
ExtendArgparser = Callable[[Any], None]
ExtraCheckStats = Callable[[list[dict[str, Any]]], None]


@dataclass(frozen=True, slots=True)
class PackerConfig:
    """数据集 packer 的不可变公共配置。"""

    dataset_name: str
    shard_prefix: str
    file_specs: Mapping[str, FileSpec]
    splits: tuple[SplitSpec, ...] = DEFAULT_SPLITS
    name_keys: tuple[str, ...] = ("name", "seq_name")
    samples_per_shard: int = 500
    maxsize_bytes: float = 20e9
    progress_interval: int = 500
    extra_metadata: Mapping[str, Any] = field(default_factory=frozen_mapping)
    enable_prefix_mapping: bool = False
    enable_scene_suffix_mapping: bool = False
    use_split_subdir: bool = False
    shard_pattern_template_override: str | None = None
    scan_entries: ScanEntries | None = None
    extend_argparser: ExtendArgparser | None = None
    extra_check_stats: ExtraCheckStats | None = None
    cli_description: str | None = None
    base_dir_default: str | None = None
    output_dir_default: str | None = None

    def __post_init__(self) -> None:
        if not self.dataset_name or not self.shard_prefix:
            raise ContractError("packer dataset_name and shard_prefix are required")
        file_specs = dict(self.file_specs)
        if not file_specs or any(not key for key in file_specs):
            raise ContractError("packer file_specs must contain non-empty canonical keys")
        if len({spec.tar_name for spec in file_specs.values()}) != len(file_specs):
            raise ContractError("packer tar member names must be unique")
        if self.samples_per_shard <= 0 or self.maxsize_bytes <= 0:
            raise ContractError("packer shard limits must be positive")
        if self.progress_interval <= 0:
            raise ContractError("packer progress_interval must be positive")
        splits = tuple(self.splits)
        if not splits or len({split.name for split in splits}) != len(splits):
            raise ContractError("packer split names must be non-empty and unique")
        name_keys = tuple(str(value) for value in self.name_keys)
        if not name_keys or any(not value for value in name_keys):
            raise ContractError("packer name_keys must contain non-empty values")
        if self.shard_pattern_template_override is not None:
            rendered = self.shard_pattern_template_override.format(
                prefix=self.shard_prefix,
                split=splits[0].name,
            )
            if not re.search(r"%0?\d*d", rendered):
                raise ContractError("packer shard pattern must contain a printf integer token")
        object.__setattr__(self, "file_specs", MappingProxyType(file_specs))
        object.__setattr__(self, "splits", splits)
        object.__setattr__(self, "name_keys", name_keys)
        if not isinstance(self.extra_metadata, MappingProxyType):
            object.__setattr__(self, "extra_metadata", frozen_mapping(dict(self.extra_metadata)))

    def shard_pattern(self, split: SplitSpec) -> str:
        if split not in self.splits:
            raise ContractError(f"split {split.name!r} does not belong to {self.dataset_name!r}")
        if self.shard_pattern_template_override is not None:
            return self.shard_pattern_template_override.format(
                prefix=self.shard_prefix,
                split=split.name,
            )
        return f"{self.shard_prefix}_{split.name}-%06d.tar"

    def shard_glob_pattern(self, split: SplitSpec) -> str:
        return re.sub(r"%0?\d*d", "*", self.shard_pattern(split))
