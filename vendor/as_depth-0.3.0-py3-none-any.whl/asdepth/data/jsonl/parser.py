"""将六类旧 JSONL 布局规范化为固定 `RgbdRecord`。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from glob import glob
from pathlib import Path
from types import MappingProxyType
from typing import Any

from asdepth.core import ContractError, DepthSpec
from asdepth.core.serialization import frozen_mapping

from ..records import RgbdRecord, legacy_sample_id
from ..specs import DatasetSpec


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open(encoding="utf-8") as stream:
        for line_no, line in enumerate(stream, start=1):
            text = line.strip()
            if not text:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError as exc:
                raise ContractError(f"invalid JSON at {path}:{line_no}: {exc.msg}") from exc
            if not isinstance(payload, dict):
                raise ContractError(f"JSONL row {line_no} must be an object: {path}")
            rows.append(payload)
    if not rows:
        raise ContractError(f"dataset JSONL is empty: {path}")
    return rows


def _resolve(root: Path, value: Any, *, field: str, row: int) -> Path:
    if value is None or str(value) == "":
        raise ContractError(f"JSONL row {row} is missing {field!r}")
    path = Path(str(value)).expanduser()
    return path if path.is_absolute() else root / path


def _optional_resolve(root: Path, value: Any) -> Path | None:
    if value is None or str(value) == "":
        return None
    path = Path(str(value)).expanduser()
    return path if path.is_absolute() else root / path


def _row_metadata(row_index: int, payload: dict[str, Any]) -> MappingProxyType[str, Any]:
    return frozen_mapping(
        {
            "jsonl_row": row_index,
            "source_fields": tuple(sorted(str(key) for key in payload)),
        }
    )


def _direct_records(
    root: Path,
    rows: list[dict[str, Any]],
    spec: DatasetSpec,
    *,
    require_target: bool,
) -> list[RgbdRecord]:
    records: list[RgbdRecord] = []
    for row_index, item in enumerate(rows, start=1):
        rgb = _resolve(root, item.get("rgb"), field="rgb", row=row_index)
        if spec.dataset_id == "hammer":
            if spec.raw_type is None:
                raise ContractError("HAMMER requires raw_type")
            raw_key = f"{spec.raw_type}_depth"
            raw = _resolve(root, item.get(raw_key), field=raw_key, row=row_index)
            target = (
                _resolve(root, item.get("depth"), field="depth", row=row_index)
                if require_target
                else None
            )
            sample_id = legacy_sample_id("hammer", rgb)
            intrinsics = None
        elif spec.dataset_id == "transcg":
            raw_value = item.get("d435_depth") or item.get("raw_depth")
            raw = _resolve(root, raw_value, field="d435_depth/raw_depth", row=row_index)
            target = (
                _resolve(root, item.get("depth"), field="depth", row=row_index)
                if require_target
                else None
            )
            sample_id = str(item.get("sample_name") or legacy_sample_id("transcg", rgb))
            intrinsics = None
        elif spec.dataset_id == "transpose":
            raw = _resolve(root, item.get("l515_depth"), field="l515_depth", row=row_index)
            target = (
                _resolve(root, item.get("depth"), field="depth", row=row_index)
                if require_target
                else None
            )
            sample_id = str(item.get("seq_name") or legacy_sample_id("transpose", rgb))
            intrinsics = None
        elif spec.dataset_id == "kitti":
            raw_value = item.get("lidar") or item.get("velodyne_raw") or item.get("raw_depth")
            raw = _resolve(root, raw_value, field="lidar/velodyne_raw/raw_depth", row=row_index)
            target = (
                _resolve(root, item.get("depth"), field="depth", row=row_index)
                if require_target
                else None
            )
            sample_id = str(
                item.get("name") or item.get("sample_name") or legacy_sample_id("kitti", rgb)
            )
            intrinsics = _optional_resolve(root, item.get("intrinsics"))
        else:
            raise ContractError(f"dataset {spec.dataset_id!r} is not a direct JSONL layout")

        records.append(
            RgbdRecord(
                sample_id=sample_id,
                rgb_path=rgb,
                raw_depth_path=raw,
                target_depth_path=target,
                intrinsics_path=intrinsics,
                metadata=_row_metadata(row_index, item),
            )
        )
    return records


def _glob_paths(directory: Path, suffix: Any, *, field: str, row: int) -> list[Path]:
    if suffix is None or str(suffix) == "":
        raise ContractError(f"JSONL row {row} is missing {field!r}")
    return [Path(value) for value in sorted(glob(str(directory / f"*{suffix}")))]


def _sequence_keys(
    paths: list[Path],
    suffix: Any,
    *,
    field: str,
    row: int,
) -> dict[str, Path]:
    suffix_text = str(suffix)
    keyed: dict[str, Path] = {}
    for path in paths:
        if not path.name.endswith(suffix_text):
            raise ContractError(
                f"JSONL row {row} {field!r} produced a path without suffix {suffix_text!r}: {path}"
            )
        key = path.name[: -len(suffix_text)] if suffix_text else path.name
        if not key:
            raise ContractError(f"JSONL row {row} {field!r} produced an empty frame key")
        if key in keyed:
            raise ContractError(f"JSONL row {row} {field!r} has duplicate frame key {key!r}")
        keyed[key] = path
    return keyed


def _sequence_records(
    root: Path,
    rows: list[dict[str, Any]],
    spec: DatasetSpec,
    *,
    max_length_each_sequence: int | None,
    require_target: bool,
) -> list[RgbdRecord]:
    records: list[RgbdRecord] = []
    limit = max_length_each_sequence
    if limit is None:
        raw_limit = spec.metadata.get("max_length_each_sequence")
        limit = int(raw_limit) if raw_limit is not None else None
    if limit is not None and limit <= 0:
        raise ContractError("max_length_each_sequence must be positive")

    for row_index, item in enumerate(rows, start=1):
        directory = _resolve(root, item.get("rgb"), field="rgb", row=row_index)
        rgbs = _glob_paths(directory, item.get("rgb-suffix"), field="rgb-suffix", row=row_index)
        raw_depths = _glob_paths(
            directory,
            item.get("raw_depth-suffix"),
            field="raw_depth-suffix",
            row=row_index,
        )
        rgb_by_key = _sequence_keys(
            rgbs,
            item.get("rgb-suffix"),
            field="rgb-suffix",
            row=row_index,
        )
        raw_by_key = _sequence_keys(
            raw_depths,
            item.get("raw_depth-suffix"),
            field="raw_depth-suffix",
            row=row_index,
        )
        target_by_key: dict[str, Path] = {}
        if require_target:
            targets = _glob_paths(
                directory,
                item.get("depth-suffix"),
                field="depth-suffix",
                row=row_index,
            )
            target_by_key = _sequence_keys(
                targets,
                item.get("depth-suffix"),
                field="depth-suffix",
                row=row_index,
            )
        key_sets = [set(rgb_by_key), set(raw_by_key)]
        if require_target:
            key_sets.append(set(target_by_key))
        if not rgb_by_key or any(keys != key_sets[0] for keys in key_sets[1:]):
            target_detail = f", target={sorted(target_by_key)}" if require_target else ""
            raise ContractError(
                f"JSONL row {row_index} has unaligned sequence files: "
                f"rgb={sorted(rgb_by_key)}, raw={sorted(raw_by_key)}{target_detail}"
            )
        frame_keys = sorted(rgb_by_key)
        if limit is not None:
            frame_keys = frame_keys[:limit]
        for frame_key in frame_keys:
            rgb = rgb_by_key[frame_key]
            raw = raw_by_key[frame_key]
            target = target_by_key[frame_key] if require_target else None
            records.append(
                RgbdRecord(
                    sample_id=legacy_sample_id(spec.dataset_id, rgb),
                    rgb_path=rgb,
                    raw_depth_path=raw,
                    target_depth_path=target,
                    metadata=_row_metadata(row_index, item),
                )
            )
    return records


def _depth_range(
    rows: list[dict[str, Any]], spec: DatasetSpec
) -> tuple[float | None, float | None]:
    if spec.dataset_id == "kitti":
        return spec.min_valid, spec.max_valid
    declared = [row.get("depth-range") for row in rows if row.get("depth-range") is not None]
    if not declared:
        return spec.min_valid, spec.max_valid
    normalized: list[tuple[float | None, float | None]] = []
    for raw in declared:
        if not isinstance(raw, list) or len(raw) != 2:
            raise ContractError("depth-range must contain [min, max]")
        normalized.append(
            (
                None if raw[0] is None else float(raw[0]),
                None if raw[1] is None else float(raw[1]),
            )
        )
    if any(value != normalized[0] for value in normalized[1:]):
        raise ContractError(f"JSONL rows declare inconsistent depth-range values: {normalized}")
    minimum, maximum = normalized[0]
    return minimum, maximum


def _with_dataset_range(
    spec: DatasetSpec, minimum: float | None, maximum: float | None
) -> DatasetSpec:
    previous_default = DepthSpec.metric(min_valid=spec.min_valid, max_valid=spec.max_valid)
    raw_depth = (
        DepthSpec.metric(min_valid=minimum, max_valid=maximum)
        if spec.raw_depth == previous_default
        else spec.raw_depth
    )
    target_depth = (
        DepthSpec.metric(min_valid=minimum, max_valid=maximum)
        if spec.target_depth == previous_default
        else spec.target_depth
    )
    return DatasetSpec(
        dataset_id=spec.dataset_id,
        dataset_version=spec.dataset_version,
        layout=spec.layout,
        raw_type=spec.raw_type,
        depth_scale=spec.depth_scale,
        min_valid=minimum,
        max_valid=maximum,
        raw_depth=raw_depth,
        target_depth=target_depth,
        metadata=spec.metadata,
    )


@dataclass(frozen=True, slots=True)
class JsonlRecordSet:
    source: Path
    spec: DatasetSpec
    records: tuple[RgbdRecord, ...]


def parse_jsonl_records(
    jsonl_path: str | Path,
    spec: DatasetSpec,
    *,
    max_length_each_sequence: int | None = None,
    require_target: bool = True,
) -> JsonlRecordSet:
    """解析 JSONL；仅显式 ``require_target=False`` 时允许 RGB/raw-only 记录。"""

    path = Path(jsonl_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    rows = _read_jsonl(path)
    minimum, maximum = _depth_range(rows, spec)
    if minimum != spec.min_valid or maximum != spec.max_valid:
        spec = _with_dataset_range(spec, minimum, maximum)

    if spec.layout == "sequence_glob":
        records = _sequence_records(
            path.parent,
            rows,
            spec,
            max_length_each_sequence=max_length_each_sequence,
            require_target=require_target,
        )
    else:
        records = _direct_records(
            path.parent,
            rows,
            spec,
            require_target=require_target,
        )
    return JsonlRecordSet(source=path, spec=spec, records=tuple(records))
