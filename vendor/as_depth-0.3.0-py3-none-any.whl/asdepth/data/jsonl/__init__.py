"""JSONL record 解析。"""

from .parser import JsonlRecordSet, parse_jsonl_records

__all__ = ["JsonlRecordSet", "parse_jsonl_records"]
