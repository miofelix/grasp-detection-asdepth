"""`RgbdSample` 到固定字段 `RgbdBatch` 的 collate。"""

from __future__ import annotations

from collections.abc import Sequence
from types import MappingProxyType
from typing import Any

import numpy as np
import torch

from asdepth.core import ContractError, DepthMap, DepthSpec, RgbdBatch, RgbdSample


def _rgb_chw(value: np.ndarray) -> torch.Tensor:
    array = np.array(value, copy=True, order="C")
    if array.ndim != 3:
        raise ContractError(f"rgb must have three dimensions, got {array.shape}")
    if array.shape[-1] in {3, 4}:
        array = np.moveaxis(array, -1, 0)
    elif array.shape[0] not in {3, 4}:
        raise ContractError(f"rgb must be HWC or CHW, got {array.shape}")
    return torch.from_numpy(np.ascontiguousarray(array))


def _depth_chw(value: DepthMap) -> torch.Tensor:
    array = np.array(value.values, copy=True, order="C")
    if array.ndim == 2:
        array = array[None, ...]
    return torch.from_numpy(array)


def _same_spec(values: Sequence[DepthSpec], *, name: str) -> DepthSpec:
    first = values[0]
    if any(value != first for value in values[1:]):
        raise ContractError(f"cannot collate mixed {name} values")
    return first


def collate_rgbd_samples(samples: Sequence[RgbdSample]) -> RgbdBatch:
    if not samples:
        raise ContractError("cannot collate an empty sample sequence")
    raw_spec = _same_spec([sample.raw_depth.spec for sample in samples], name="raw DepthSpec")

    targets = [sample.target_depth for sample in samples]
    if any(value is None for value in targets) and not all(value is None for value in targets):
        raise ContractError("cannot collate a mixture of samples with and without target depth")
    target_tensor: torch.Tensor | None = None
    target_spec: DepthSpec | None = None
    if all(value is not None for value in targets):
        concrete_targets = [value for value in targets if value is not None]
        target_spec = _same_spec(
            [value.spec for value in concrete_targets],
            name="target DepthSpec",
        )
        target_tensor = torch.stack([_depth_chw(value) for value in concrete_targets])

    intrinsics_values = [sample.intrinsics for sample in samples]
    if any(value is None for value in intrinsics_values) and not all(
        value is None for value in intrinsics_values
    ):
        raise ContractError("cannot collate mixed intrinsics availability")
    intrinsics: torch.Tensor | None = None
    if all(value is not None for value in intrinsics_values):
        intrinsics = torch.stack(
            [
                torch.from_numpy(np.array(value, copy=True))
                for value in intrinsics_values
                if value is not None
            ]
        )

    metadata: tuple[MappingProxyType[str, Any], ...] = tuple(sample.metadata for sample in samples)
    return RgbdBatch(
        sample_ids=tuple(sample.sample_id for sample in samples),
        rgb=torch.stack([_rgb_chw(sample.rgb) for sample in samples]),
        raw_depth=torch.stack([_depth_chw(sample.raw_depth) for sample in samples]),
        depth_spec=raw_spec,
        target_depth=target_tensor,
        target_depth_spec=target_spec,
        intrinsics=intrinsics,
        metadata=metadata,
    )
