"""深度文件的覆盖安全写入。"""

from __future__ import annotations

import importlib
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from asdepth.artifacts import atomic_write_bytes
from asdepth.core import ContractError


def _single_channel_depth(value: NDArray[Any]) -> NDArray[np.float32]:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim == 3 and array.shape[0] == 1:
        array = array[0]
    elif array.ndim == 3 and array.shape[-1] == 1:
        array = array[..., 0]
    if array.ndim != 2:
        raise ContractError(f"depth must be single-channel 2D, got {array.shape}")
    result = np.ascontiguousarray(array, dtype=np.float32)
    result[~np.isfinite(result)] = 0.0
    return result


def write_depth_exr(
    path: str | Path,
    depth: NDArray[Any],
    *,
    overwrite: bool = False,
) -> Path:
    """原子写入 float32 单通道 ``Z`` EXR；需要 ``train`` extra。"""

    target = Path(path).expanduser().resolve()
    if target.suffix.lower() != ".exr":
        raise ContractError(f"EXR target must use .exr suffix: {target}")
    values = _single_channel_depth(depth)
    try:
        pyexr = importlib.import_module("pyexr")
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise ContractError(
            "EXR writing requires the 'train' extra: pip install 'as-depth[train]'"
        ) from exc

    with tempfile.TemporaryDirectory(prefix="asdepth-exr-") as directory:
        temporary = Path(directory) / "depth.exr"
        pyexr.write(str(temporary), values)
        payload = temporary.read_bytes()
    return atomic_write_bytes(target, payload, overwrite=overwrite)


__all__ = ["write_depth_exr"]
