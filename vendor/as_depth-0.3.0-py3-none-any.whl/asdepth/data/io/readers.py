"""设备无关、单位显式的 RGB-D 文件读取。"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

os.environ.setdefault("OPENCV_IO_ENABLE_OPENEXR", "1")

import cv2
import numpy as np
from numpy.typing import NDArray

from asdepth.core import (
    ContractError,
    DepthMap,
    DepthRepresentation,
    DepthSpec,
    DepthUnit,
)


def read_rgb(path: str | Path) -> NDArray[np.uint8]:
    image_path = Path(path)
    bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(f"cannot read RGB image: {image_path}")
    return np.ascontiguousarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))


def _read_depth_array(path: Path) -> NDArray[Any]:
    if path.suffix.lower() == ".npy":
        array = np.load(path, allow_pickle=False)
    else:
        array = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
        if array is None:
            raise FileNotFoundError(f"cannot read depth image: {path}")
    values = np.asarray(array)
    if values.ndim == 3 and values.shape[-1] == 1:
        values = values[..., 0]
    if values.ndim != 2:
        raise ContractError(f"depth image must be single-channel 2D, got {values.shape}: {path}")
    return values


def read_metric_depth(
    path: str | Path,
    *,
    depth_scale: float,
    min_valid: float | None,
    max_valid: float | None,
) -> DepthMap:
    if depth_scale <= 0:
        raise ContractError("depth_scale must be positive")
    values = np.asarray(_read_depth_array(Path(path)), dtype=np.float32)
    scaled = values / np.float32(depth_scale)
    return DepthMap.from_metric_array(
        scaled,
        unit=DepthUnit.METER,
        min_valid=min_valid,
        max_valid=max_valid,
    )


def read_depth_png(
    path: str | Path,
    depth_scale: float,
    missing_ok: bool = False,
) -> NDArray[np.float32] | None:
    """读取单通道 PNG 并转换为 meter；非有限值固定为零。"""

    if depth_scale <= 0:
        raise ContractError("depth_scale must be positive")
    image_path = Path(path)
    raw = cv2.imread(str(image_path), cv2.IMREAD_UNCHANGED)
    if raw is None:
        if missing_ok:
            return None
        raise FileNotFoundError(f"cannot read depth image: {image_path}")
    values = np.asarray(raw, dtype=np.float32)
    if values.ndim == 3 and values.shape[-1] == 1:
        values = values[..., 0]
    if values.ndim != 2:
        raise ContractError(f"depth image must be single-channel 2D, got {values.shape}")
    depth = np.ascontiguousarray(values / np.float32(depth_scale))
    depth[~np.isfinite(depth)] = 0.0
    return depth


def read_ground_truth_depth(
    path: str | Path,
    *,
    depth_scale: float,
    min_depth: float = 0.0,
    max_depth: float,
) -> tuple[NDArray[np.float32], NDArray[np.bool_]]:
    """读取 GT metric depth，并返回范围内有效 mask。"""

    if max_depth <= min_depth:
        raise ContractError("max_depth must be greater than min_depth")
    depth = read_depth_png(path, depth_scale)
    assert depth is not None
    valid = np.isfinite(depth) & (depth >= np.float32(min_depth)) & (depth <= np.float32(max_depth))
    values = np.where(valid, depth, np.float32(min_depth)).astype(np.float32, copy=False)
    return values, valid


def normalize_prediction_depth(
    prediction: NDArray[Any],
    *,
    source: str | Path | None = None,
) -> NDArray[np.float32]:
    """把单样本预测规范化为 finite float32 二维 metric depth。"""

    squeezed = np.squeeze(np.asarray(prediction, dtype=np.float32))
    if squeezed.ndim != 2:
        location = f"{source}: " if source is not None else ""
        raise ContractError(
            f"{location}prediction must be single-channel 2D after squeeze, got {squeezed.shape}"
        )
    depth = np.ascontiguousarray(squeezed, dtype=np.float32)
    depth[~np.isfinite(depth)] = 0.0
    return depth


def read_depth_npy(path: str | Path) -> NDArray[np.float32]:
    """安全读取单样本 ``.npy`` metric depth。"""

    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(source)
    return normalize_prediction_depth(np.load(source, allow_pickle=False), source=source)


def read_prediction_depth(
    path: str | Path,
    max_depth: float,
) -> NDArray[np.float32]:
    """读取渲染用 metric depth，并把 ``(0, max_depth]`` 外的值置零。"""

    if max_depth <= 0:
        raise ContractError("max_depth must be positive")
    depth = read_depth_npy(path)
    valid = (depth > 0.0) & (depth <= max_depth)
    return np.where(valid, depth, 0.0).astype(np.float32, copy=False)


def convert_metric_depth(metric: DepthMap, requested: DepthSpec) -> DepthMap:
    """把 meter metric depth 转成 Dataset 明确请求的表示。"""

    if metric.spec.representation is not DepthRepresentation.METRIC_DEPTH:
        raise ContractError("convert_metric_depth requires metric source values")
    if requested.representation is DepthRepresentation.METRIC_DEPTH:
        return DepthMap(metric.values, requested)
    if requested.representation is DepthRepresentation.INVERSE_DEPTH:
        values = np.zeros_like(metric.values)
        np.divide(1.0, metric.values, out=values, where=metric.valid_mask)
        return DepthMap(values, requested)
    raise ContractError("datasets cannot produce raw log_depth_3ch from metric files")


def read_intrinsics(path: str | Path) -> NDArray[np.float32]:
    intrinsics_path = Path(path)
    if not intrinsics_path.is_file():
        raise FileNotFoundError(intrinsics_path)
    values = np.asarray(np.loadtxt(intrinsics_path), dtype=np.float32)
    if values.size != 9:
        raise ContractError(f"intrinsics must contain 9 values, got {values.shape}: {path}")
    matrix = np.ascontiguousarray(values.reshape(3, 3))
    fx, fy = float(matrix[0, 0]), float(matrix[1, 1])
    if not np.isfinite(fx) or not np.isfinite(fy) or fx == 0.0 or fy == 0.0:
        raise ContractError(f"intrinsics fx/fy must be finite and non-zero: {path}")
    return matrix
