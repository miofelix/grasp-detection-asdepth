"""不加载像素的规范化 RGB-D record。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any

from asdepth.core import ContractError
from asdepth.core.serialization import frozen_mapping


@dataclass(frozen=True, slots=True)
class RgbdRecord:
    sample_id: str
    rgb_path: Path
    raw_depth_path: Path
    target_depth_path: Path | None
    intrinsics_path: Path | None = None
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.sample_id:
            raise ContractError("RgbdRecord sample_id cannot be empty")
        for name in ("rgb_path", "raw_depth_path", "target_depth_path", "intrinsics_path"):
            value = getattr(self, name)
            if value is not None and not isinstance(value, Path):
                object.__setattr__(self, name, Path(value))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))


def legacy_sample_id(dataset_id: str, rgb_path: str | Path) -> str:
    """逐字符保持旧推理输出 basename 规则。"""

    parts = str(rgb_path).replace("\\", "/").split("/")
    stem = parts[-1].split(".")[0]
    if dataset_id == "hammer":
        if len(parts) < 4:
            raise ContractError(f"HAMMER rgb path is too short for legacy name: {rgb_path}")
        return f"{parts[-4]}#{stem}"
    if dataset_id in {"clearpose", "dreds"}:
        if len(parts) < 3:
            raise ContractError(f"{dataset_id} rgb path is too short for legacy name: {rgb_path}")
        return "#".join((*parts[-3:-1], stem))
    if dataset_id == "transcg":
        if len(parts) >= 3:
            return "_".join(parts[-3:-1])
        return stem
    if dataset_id == "transpose":
        if len(parts) >= 4:
            return f"{parts[-4]}_{stem}"
        return stem
    if dataset_id == "kitti":
        return stem
    raise ContractError(f"unsupported dataset_id for sample naming: {dataset_id!r}")
