"""可审计、可选择内容校验的数据集 fingerprint。"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from asdepth.artifacts import sha256_file
from asdepth.core.serialization import to_primitive

from .records import RgbdRecord
from .specs import DatasetSpec


class FingerprintableDataset(Protocol):
    source: Path
    spec: DatasetSpec
    records: tuple[RgbdRecord, ...]


@dataclass(frozen=True, slots=True)
class DatasetFingerprint:
    value: str
    source_sha256: str
    spec_hash: str
    records_hash: str
    record_count: int
    content_verified: bool


def _relative(path: Path | None, root: Path) -> str | None:
    if path is None:
        return None
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def _record_payload(record: RgbdRecord, root: Path, *, include_content: bool) -> dict[str, Any]:
    paths = {
        "rgb": record.rgb_path,
        "raw_depth": record.raw_depth_path,
        "target_depth": record.target_depth_path,
        "intrinsics": record.intrinsics_path,
    }
    serialized: dict[str, Any] = {"sample_id": record.sample_id, "paths": {}}
    for role, path in paths.items():
        if path is None:
            serialized["paths"][role] = None
            continue
        item: dict[str, Any] = {"path": _relative(path, root)}
        if path.is_file():
            item["size"] = path.stat().st_size
            if include_content:
                item["sha256"] = sha256_file(path)
        else:
            item["missing"] = True
        serialized["paths"][role] = item
    return serialized


def _hash(value: Any) -> str:
    payload = json.dumps(
        to_primitive(value),
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def fingerprint_dataset(
    dataset: FingerprintableDataset,
    *,
    include_content: bool = False,
) -> DatasetFingerprint:
    root = dataset.source.parent
    source_sha256 = sha256_file(dataset.source)
    record_payload = [
        _record_payload(record, root, include_content=include_content) for record in dataset.records
    ]
    records_hash = _hash(record_payload)
    value = _hash(
        {
            "source_sha256": source_sha256,
            "spec_hash": dataset.spec.config_hash,
            "records_hash": records_hash,
            "record_count": len(dataset.records),
            "content_verified": include_content,
        }
    )
    return DatasetFingerprint(
        value=value,
        source_sha256=source_sha256,
        spec_hash=dataset.spec.config_hash,
        records_hash=records_hash,
        record_count=len(dataset.records),
        content_verified=include_content,
    )
