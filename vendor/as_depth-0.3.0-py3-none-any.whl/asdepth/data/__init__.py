"""统一 RGB-D sample、batch、dataset 与 dataloader API。"""

from .catalog import DatasetCatalog, DatasetCatalogEntry, load_dataset_catalog
from .collate import collate_rgbd_samples
from .datasets import (
    JsonlRgbdDataset,
    LabRecord,
    LabRgbdDataset,
    create_lab_dataset,
    load_lab_records,
)
from .factory import create_dataloader, create_dataset
from .fingerprint import DatasetFingerprint, fingerprint_dataset
from .records import RgbdRecord, legacy_sample_id
from .specs import DatasetManifest, DatasetSpec
from .webdataset import (
    LegacyWdsDatasetAdapter,
    adapt_legacy_wds_dataset,
    create_webdataset,
    create_webdataset_dataloader,
)

__all__ = [
    "DatasetCatalog",
    "DatasetCatalogEntry",
    "DatasetFingerprint",
    "DatasetManifest",
    "DatasetSpec",
    "JsonlRgbdDataset",
    "LabRecord",
    "LabRgbdDataset",
    "LegacyWdsDatasetAdapter",
    "RgbdRecord",
    "adapt_legacy_wds_dataset",
    "collate_rgbd_samples",
    "create_dataloader",
    "create_dataset",
    "create_lab_dataset",
    "create_webdataset",
    "create_webdataset_dataloader",
    "fingerprint_dataset",
    "legacy_sample_id",
    "load_dataset_catalog",
    "load_lab_records",
]
