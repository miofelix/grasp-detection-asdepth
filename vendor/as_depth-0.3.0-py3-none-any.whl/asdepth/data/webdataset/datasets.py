"""活跃训练 WDS 的设备无关解码与 `RgbdSample` 输出。"""

from __future__ import annotations

import io
import logging
import os
import random
import tempfile
from collections.abc import Iterable, Iterator, Mapping, Sequence
from pathlib import Path
from typing import Any, Literal, cast

import cv2
import numpy as np
from numpy.typing import NDArray
from torch.utils.data import IterableDataset

from asdepth.core import ContractError, DepthMap, DepthRepresentation, DepthSpec, RgbdSample
from asdepth.core.serialization import frozen_mapping

from ..specs import DatasetSpec
from ..transforms import LegacyDptTransform

LOGGER = logging.getLogger(__name__)


def _optional_import(name: str, *, extra: str = "train") -> Any:
    try:
        return __import__(name)
    except ImportError as exc:
        raise RuntimeError(
            f"optional dependency {name!r} is required; install `as-depth[{extra}]`"
        ) from exc


def _sample_key(sample: Mapping[str, Any]) -> str:
    value = sample.get("__key__", "unknown")
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _not_none(value: Any) -> bool:
    """Pickle-safe WDS selector for the skip-on-error pipeline."""

    return value is not None


def _decode_png(data: bytes, *, color: bool) -> NDArray[Any]:
    flag = cv2.IMREAD_COLOR if color else cv2.IMREAD_UNCHANGED
    decoded = cv2.imdecode(np.frombuffer(data, np.uint8), flag)
    if decoded is None:
        raise ContractError("failed to decode PNG/JPEG bytes")
    if color:
        decoded = cv2.cvtColor(decoded, cv2.COLOR_BGR2RGB)
    return np.asarray(decoded)


def _decode_exr_pyexr(data: bytes) -> NDArray[np.float32]:
    pyexr = _optional_import("pyexr")
    file_descriptor, temp_path = tempfile.mkstemp(suffix=".exr")
    try:
        with os.fdopen(file_descriptor, "wb") as stream:
            stream.write(data)
        values = np.asarray(pyexr.open(temp_path).get(), dtype=np.float32)
    finally:
        Path(temp_path).unlink(missing_ok=True)
    if values.ndim == 3:
        values = values[..., 0]
    if values.ndim != 2:
        raise ContractError(f"EXR depth must be 2D, got {values.shape}")
    return values


def _decode_hdf5(data: bytes, *, dataset_key: str = "dataset") -> NDArray[np.float32]:
    h5py = _optional_import("h5py")
    with h5py.File(io.BytesIO(data), "r") as stream:
        return np.asarray(stream[dataset_key], dtype=np.float32)


def _decode_openexr(data: bytes) -> NDArray[np.float32]:
    openexr = _optional_import("OpenEXR")
    imath = _optional_import("Imath")
    file_descriptor, temp_path = tempfile.mkstemp(suffix=".exr")
    try:
        with os.fdopen(file_descriptor, "wb") as stream:
            stream.write(data)
        source = openexr.InputFile(temp_path)
        header = source.header()
        bounds = header["dataWindow"]
        width = bounds.max.x - bounds.min.x + 1
        height = bounds.max.y - bounds.min.y + 1
        channels = list(header["channels"])
        if not channels:
            raise ContractError("EXR contains no channels")
        pixel_type = imath.PixelType(imath.PixelType.FLOAT)
        values = np.frombuffer(source.channel(channels[0], pixel_type), dtype=np.float32)
        source.close()
    finally:
        Path(temp_path).unlink(missing_ok=True)
    return np.asarray(values.reshape(height, width), dtype=np.float32)


def _metric_depth(
    values: NDArray[Any],
    *,
    scale: float,
    depth_range: tuple[float, float],
) -> NDArray[np.float32]:
    if scale <= 0:
        raise ContractError("WDS depth scale must be positive")
    metric = np.asarray(values, dtype=np.float32) / np.float32(scale)
    valid = (
        np.isfinite(metric)
        & (metric >= np.float32(depth_range[0]))
        & (metric <= np.float32(depth_range[1]))
    )
    result = np.zeros_like(metric, dtype=np.float32)
    result[valid] = metric[valid]
    return result


def _depth_from_metric(values: NDArray[np.float32], spec: DepthSpec) -> DepthMap:
    metric = DepthMap(values, DepthSpec.metric())
    if spec.representation is DepthRepresentation.METRIC_DEPTH:
        return DepthMap(metric.values, spec)
    if spec.representation is DepthRepresentation.INVERSE_DEPTH:
        inverse = np.zeros_like(metric.values)
        np.divide(1.0, metric.values, out=inverse, where=metric.valid_mask)
        return DepthMap(inverse, spec)
    raise ContractError("WDS datasets cannot emit log_depth_3ch")


def _sparse_mask(valid: NDArray[np.bool_], remove_ratio: float) -> NDArray[np.bool_]:
    if not 0.0 <= remove_ratio <= 1.0:
        raise ContractError("raw_depth_remove_ratio must be in [0, 1]")
    result = cast(NDArray[np.bool_], valid.copy())
    rows, columns = np.where(result)
    remove_count = int(len(rows) * remove_ratio)
    if len(rows) > remove_count and remove_count > 0:
        selected = np.random.choice(len(rows), size=remove_count, replace=False)
        result[rows[selected], columns[selected]] = False
    return result


class RgbdWebDataset(IterableDataset[RgbdSample]):
    """WDS 基类；依赖在构造真实 tar pipeline 时才导入。"""

    def __init__(
        self,
        source: str,
        *,
        dataset_id: str,
        depth_scale: float,
        depth_range: tuple[float, float],
        raw_depth_spec: DepthSpec,
        target_depth_spec: DepthSpec,
        image_size: int = 518,
        shuffle: int = 0,
        num_samples: int | None = None,
        error_policy: Literal["raise", "skip"] = "raise",
        build_pipeline: bool = True,
    ) -> None:
        super().__init__()
        if not source or not dataset_id:
            raise ContractError("WDS source and dataset_id are required")
        if depth_scale <= 0 or depth_range[0] <= 0 or depth_range[0] >= depth_range[1]:
            raise ContractError("WDS depth scale/range is invalid")
        if shuffle < 0 or (num_samples is not None and num_samples <= 0):
            raise ContractError("WDS shuffle and num_samples must be non-negative/positive")
        if error_policy not in {"raise", "skip"}:
            raise ContractError(f"unsupported WDS error policy {error_policy!r}")
        for spec in (raw_depth_spec, target_depth_spec):
            if spec.representation is DepthRepresentation.LOG_DEPTH_3CH:
                raise ContractError("WDS datasets cannot emit log_depth_3ch")

        self.source = source
        self.dataset_id = dataset_id
        self.depth_scale = float(depth_scale)
        self.depth_range = (float(depth_range[0]), float(depth_range[1]))
        self.raw_depth_spec = raw_depth_spec
        self.target_depth_spec = target_depth_spec
        self.image_size = image_size
        self.shuffle = shuffle
        self.num_samples = num_samples
        self.error_policy = error_policy
        self.transform = LegacyDptTransform(image_size=image_size)
        self.spec = DatasetSpec(
            dataset_id=dataset_id,
            dataset_version="source-00ec5dc",
            layout="webdataset",
            raw_type=None,
            depth_scale=depth_scale,
            min_valid=depth_range[0],
            max_valid=depth_range[1],
            raw_depth=raw_depth_spec,
            target_depth=target_depth_spec,
            metadata=frozen_mapping({"image_size": image_size, "shuffle": shuffle}),
        )
        self.pipeline = self._build_pipeline() if build_pipeline else None

    def _build_pipeline(self) -> Any:
        wds = _optional_import("webdataset")
        pipeline = wds.WebDataset(
            self.source,
            nodesplitter=wds.split_by_node,
            workersplitter=wds.split_by_worker,
            shardshuffle=self.shuffle > 0,
            empty_check=False,
        )
        if self.shuffle > 0:
            pipeline = pipeline.shuffle(self.shuffle)
        pipeline = pipeline.map(self._pipeline_process)
        if self.error_policy == "skip":
            pipeline = pipeline.select(_not_none)
        if self.num_samples is not None:
            pipeline = pipeline.with_length(self.num_samples)
        return pipeline

    def _pipeline_process(self, sample: Mapping[str, Any]) -> RgbdSample | None:
        if self.error_policy == "raise":
            return self.process_sample(sample)
        try:
            return self.process_sample(sample)
        except Exception as exc:
            LOGGER.warning(
                "skipping malformed WDS sample %s from %s: %s",
                _sample_key(sample),
                self.dataset_id,
                exc,
            )
            return None

    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        raise NotImplementedError

    def process_sample(self, sample: Mapping[str, Any]) -> RgbdSample:
        rgb, raw_metric, target_metric, metadata = self.decode_metric(sample)
        rgb_tensor, raw_tensor, target_tensor = self.transform(rgb, raw_metric, target_metric)
        rgb_tensor, raw_tensor, target_tensor = self.postprocess_transformed(
            rgb_tensor,
            raw_tensor,
            target_tensor,
        )
        key = _sample_key(sample)
        return RgbdSample(
            sample_id=f"{self.dataset_id}:{key}",
            rgb=rgb_tensor,
            raw_depth=_depth_from_metric(raw_tensor, self.raw_depth_spec),
            target_depth=_depth_from_metric(target_tensor, self.target_depth_spec),
            metadata=frozen_mapping(
                {
                    **metadata,
                    "dataset_id": self.dataset_id,
                    "dataset_identity": self.spec.identity,
                    "sample_key": key,
                    "preprocessed": True,
                    "source": self.source,
                    "depth_scale": self.depth_scale,
                    "depth_range": self.depth_range,
                    "image_size": self.image_size,
                }
            ),
        )

    def postprocess_transformed(
        self,
        rgb: NDArray[np.float32],
        raw_depth: NDArray[np.float32],
        target_depth: NDArray[np.float32],
    ) -> tuple[NDArray[np.float32], NDArray[np.float32], NDArray[np.float32]]:
        return rgb, raw_depth, target_depth

    def __iter__(self) -> Iterator[RgbdSample]:
        if self.pipeline is None:
            raise RuntimeError("WDS pipeline was disabled for direct decoder testing")
        return iter(self.pipeline)

    def __len__(self) -> int:
        if self.num_samples is None:
            raise TypeError(f"{type(self).__name__} has no len(); pass num_samples")
        return self.num_samples


class HissWebDataset(RgbdWebDataset):
    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        rgb = _decode_png(sample["rgb.png"], color=True)
        raw = _metric_depth(
            _decode_exr_pyexr(sample["raw_depth.exr"]),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        target = _metric_depth(
            _decode_exr_pyexr(sample["depth.exr"]),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        return rgb, raw, target, {}


class DredsWebDataset(HissWebDataset):
    pass


class HammerWebDataset(RgbdWebDataset):
    VALID_DEPTH_TYPES = frozenset({"d435", "l515", "tof"})

    def __init__(self, *args: Any, depth_type: str = "d435", **kwargs: Any) -> None:
        selected = depth_type.lower()
        if selected not in self.VALID_DEPTH_TYPES:
            raise ContractError(
                f"HAMMER depth_type must be one of {sorted(self.VALID_DEPTH_TYPES)}"
            )
        self.depth_type = selected
        super().__init__(*args, **kwargs)

    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        raw_key = f"depth_{self.depth_type}.png"
        rgb = _decode_png(sample["rgb.png"], color=True)
        raw = _metric_depth(
            _decode_png(sample[raw_key], color=False),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        target = _metric_depth(
            _decode_png(sample["gt.png"], color=False),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        return rgb, raw, target, {"raw_type": self.depth_type}


def hypersim_distance_to_depth(distance: NDArray[np.float32]) -> NDArray[np.float32]:
    height, width = distance.shape
    if (height, width) != (768, 1024):
        raise ContractError(f"Hypersim distance must be 768x1024, got {distance.shape}")
    focal = np.float32(886.81)
    plane_x = np.linspace(-511.5, 511.5, width, dtype=np.float32)[None, :, None]
    plane_y = np.linspace(-383.5, 383.5, height, dtype=np.float32)[:, None, None]
    plane_x = np.repeat(plane_x, height, axis=0)
    plane_y = np.repeat(plane_y, width, axis=1)
    plane_z = np.full((height, width, 1), focal, dtype=np.float32)
    image_plane = np.concatenate((plane_x, plane_y, plane_z), axis=2)
    return np.asarray(
        distance / np.linalg.norm(image_plane, ord=2, axis=2) * focal,
        dtype=np.float32,
    )


class HypersimWebDataset(RgbdWebDataset):
    def __init__(self, *args: Any, raw_depth_remove_ratio: float = 0.5, **kwargs: Any) -> None:
        self.raw_depth_remove_ratio = raw_depth_remove_ratio
        super().__init__(*args, **kwargs)

    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        rgb = _decode_png(sample["rgb.jpg"], color=True)
        target = _metric_depth(
            hypersim_distance_to_depth(_decode_hdf5(sample["depth.hdf5"])),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        valid = target > 0
        raw_valid = _sparse_mask(valid, self.raw_depth_remove_ratio)
        raw = target.copy()
        raw[~raw_valid] = 0.0
        return rgb, raw, target, {"raw_depth_remove_ratio": self.raw_depth_remove_ratio}

    def postprocess_transformed(
        self,
        rgb: NDArray[np.float32],
        raw_depth: NDArray[np.float32],
        target_depth: NDArray[np.float32],
    ) -> tuple[NDArray[np.float32], NDArray[np.float32], NDArray[np.float32]]:
        height, width = target_depth.shape
        if height == self.image_size:
            target_height = self.image_size
            target_width = int(np.ceil(self.image_size * 16 / 9 / 14) * 14)
        elif width == self.image_size:
            target_height = int(np.ceil(self.image_size * 3 / 4 / 14) * 14)
            target_width = self.image_size
        else:
            return rgb, raw_depth, target_depth

        if rgb.shape[1] > target_height:
            offset = (rgb.shape[1] - target_height) // 2
            rgb = rgb[:, offset : offset + target_height, :]
            raw_depth = raw_depth[offset : offset + target_height, :]
            target_depth = target_depth[offset : offset + target_height, :]
        if rgb.shape[2] > target_width:
            offset = (rgb.shape[2] - target_width) // 2
            rgb = rgb[:, :, offset : offset + target_width]
            raw_depth = raw_depth[:, offset : offset + target_width]
            target_depth = target_depth[:, offset : offset + target_width]

        pad_height = max(0, target_height - rgb.shape[1])
        pad_width = max(0, target_width - rgb.shape[2])
        if pad_height or pad_width:
            rgb = np.pad(rgb, ((0, 0), (0, pad_height), (0, pad_width)))
            raw_depth = np.pad(raw_depth, ((0, pad_height), (0, pad_width)))
            target_depth = np.pad(target_depth, ((0, pad_height), (0, pad_width)))
        return (
            np.ascontiguousarray(rgb, dtype=np.float32),
            np.ascontiguousarray(raw_depth, dtype=np.float32),
            np.ascontiguousarray(target_depth, dtype=np.float32),
        )


class VirtualKitti2WebDataset(RgbdWebDataset):
    def __init__(self, *args: Any, raw_depth_remove_ratio: float = 0.5, **kwargs: Any) -> None:
        self.raw_depth_remove_ratio = raw_depth_remove_ratio
        super().__init__(*args, **kwargs)

    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        rgb = _decode_png(sample["rgb.jpg"], color=True)
        target = _metric_depth(
            _decode_png(sample["depth.png"], color=False),
            scale=self.depth_scale,
            depth_range=self.depth_range,
        )
        valid = target > 0
        raw_valid = _sparse_mask(valid, self.raw_depth_remove_ratio)
        raw = target.copy()
        raw[~raw_valid] = 0.0
        return rgb, raw, target, {"raw_depth_remove_ratio": self.raw_depth_remove_ratio}


class IrsWebDataset(RgbdWebDataset):
    LEGACY_DISPARITY_SCALE = 48.0

    def __init__(self, *args: Any, raw_depth_remove_ratio: float = 0.5, **kwargs: Any) -> None:
        self.raw_depth_remove_ratio = raw_depth_remove_ratio
        super().__init__(*args, **kwargs)

    def decode_metric(
        self, sample: Mapping[str, Any]
    ) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32], dict[str, Any]]:
        rgb = _decode_png(sample["rgb.png"], color=True)
        disparity = np.asarray(_decode_openexr(sample["depth.exr"]), dtype=np.float32)
        metric = np.zeros_like(disparity)
        positive = np.isfinite(disparity) & (disparity > 0)
        metric[positive] = np.float32(self.LEGACY_DISPARITY_SCALE) / disparity[positive]
        target = _metric_depth(metric, scale=1.0, depth_range=self.depth_range)
        valid = target > 0
        raw_valid = _sparse_mask(valid, self.raw_depth_remove_ratio)
        raw = target.copy()
        raw[~raw_valid] = 0.0
        return (
            rgb,
            raw,
            target,
            {
                "raw_depth_remove_ratio": self.raw_depth_remove_ratio,
                "legacy_disparity_scale": self.LEGACY_DISPARITY_SCALE,
            },
        )


class InterleavedRgbdDataset(IterableDataset[RgbdSample]):
    def __init__(self, datasets: Sequence[Iterable[RgbdSample]], *, seed: int = 42) -> None:
        super().__init__()
        if not datasets:
            raise ContractError("at least one WDS dataset is required")
        self.datasets = tuple(datasets)
        self.seed = seed

    def __iter__(self) -> Iterator[RgbdSample]:
        randomizer = random.Random(self.seed)
        iterators = [iter(dataset) for dataset in self.datasets]
        while iterators:
            index = randomizer.randrange(len(iterators))
            try:
                yield next(iterators[index])
            except StopIteration:
                iterators.pop(index)
