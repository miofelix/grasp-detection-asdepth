"""把旧 WDS `(4CH tensor, target)` 适配为 `RgbdSample`。"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import Any

import numpy as np
import torch
from torch.utils.data import IterableDataset

from asdepth.core import ContractError, DepthMap, DepthSpec, RgbdSample
from asdepth.core.serialization import frozen_mapping


class LegacyWdsDatasetAdapter(IterableDataset[RgbdSample]):
    """兼容过渡层；输入 tensor 已完成旧 transform，不重复预处理。"""

    def __init__(
        self,
        dataset: Iterable[tuple[Any, Any]],
        *,
        dataset_id: str,
        depth_spec: DepthSpec,
        sample_id_prefix: str | None = None,
    ) -> None:
        super().__init__()
        self.dataset = dataset
        self.dataset_id = dataset_id
        self.depth_spec = depth_spec
        self.sample_id_prefix = sample_id_prefix or dataset_id

    def __iter__(self) -> Iterator[RgbdSample]:
        for index, item in enumerate(self.dataset):
            if not isinstance(item, tuple) or len(item) != 2:
                raise ContractError("legacy WDS samples must be (rgbd_input, target) tuples")
            inputs, target = item
            input_array = np.asarray(
                inputs.detach().cpu().numpy() if isinstance(inputs, torch.Tensor) else inputs,
                dtype=np.float32,
            )
            target_array = np.asarray(
                target.detach().cpu().numpy() if isinstance(target, torch.Tensor) else target,
                dtype=np.float32,
            )
            if input_array.ndim != 3 or input_array.shape[0] != 4:
                raise ContractError(f"legacy WDS input must be 4CHW, got {input_array.shape}")
            if target_array.ndim == 3 and target_array.shape[0] == 1:
                target_array = target_array[0]
            if target_array.ndim != 2:
                raise ContractError(
                    f"legacy WDS target must be 1HW or HW, got {target_array.shape}"
                )
            yield RgbdSample(
                sample_id=f"{self.sample_id_prefix}-{index:08d}",
                rgb=np.moveaxis(input_array[:3], 0, -1),
                raw_depth=DepthMap(input_array[3], self.depth_spec),
                target_depth=DepthMap(target_array, self.depth_spec),
                metadata=frozen_mapping(
                    {
                        "dataset_id": self.dataset_id,
                        "legacy_wds": True,
                        "preprocessed": True,
                    }
                ),
            )

    def __len__(self) -> int:
        if not hasattr(self.dataset, "__len__"):
            raise TypeError(f"{type(self.dataset).__name__} has no len()")
        return len(self.dataset)  # type: ignore[arg-type]


def adapt_legacy_wds_dataset(
    dataset: Iterable[tuple[Any, Any]],
    *,
    dataset_id: str,
    depth_spec: DepthSpec,
    sample_id_prefix: str | None = None,
) -> LegacyWdsDatasetAdapter:
    return LegacyWdsDatasetAdapter(
        dataset,
        dataset_id=dataset_id,
        depth_spec=depth_spec,
        sample_id_prefix=sample_id_prefix,
    )
