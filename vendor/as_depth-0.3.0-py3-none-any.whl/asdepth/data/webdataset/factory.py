"""活跃 WDS preset 的正式构建 API。"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

from torch.utils.data import DataLoader, IterableDataset

from asdepth.core import ContractError, DepthSpec, RgbdSample

from ..collate import collate_rgbd_samples
from .datasets import (
    DredsWebDataset,
    HammerWebDataset,
    HissWebDataset,
    HypersimWebDataset,
    InterleavedRgbdDataset,
    IrsWebDataset,
    RgbdWebDataset,
    VirtualKitti2WebDataset,
)


@dataclass(frozen=True, slots=True)
class _WebDatasetPreset:
    dataset_class: type[RgbdWebDataset]
    depth_scale: float
    depth_range: tuple[float, float]


_PRESETS: dict[str, _WebDatasetPreset] = {
    "hiss": _WebDatasetPreset(HissWebDataset, 1.0, (0.01, 6.0)),
    "dreds": _WebDatasetPreset(DredsWebDataset, 1.0, (0.01, 6.0)),
    "dreds_novel": _WebDatasetPreset(DredsWebDataset, 1.0, (0.01, 6.0)),
    "dreds_train": _WebDatasetPreset(DredsWebDataset, 1.0, (0.01, 6.0)),
    "hammer": _WebDatasetPreset(HammerWebDataset, 1000.0, (0.01, 6.0)),
    "hypersim": _WebDatasetPreset(HypersimWebDataset, 1.0, (0.01, 6.0)),
    "irs": _WebDatasetPreset(IrsWebDataset, 1.0, (0.01, 6.0)),
    "virtualkitti2": _WebDatasetPreset(VirtualKitti2WebDataset, 100.0, (0.01, 80.0)),
    "vkitti2": _WebDatasetPreset(VirtualKitti2WebDataset, 100.0, (0.01, 80.0)),
}


def create_webdataset(
    source: str,
    *,
    dataset_id: str,
    raw_depth: DepthSpec | None = None,
    target_depth: DepthSpec | None = None,
    depth_scale: float | None = None,
    depth_range: tuple[float, float] | None = None,
    image_size: int = 518,
    shuffle: int = 0,
    num_samples: int | None = None,
    error_policy: Literal["raise", "skip"] = "raise",
    build_pipeline: bool = True,
    **dataset_options: Any,
) -> RgbdWebDataset:
    normalized = dataset_id.lower()
    try:
        preset = _PRESETS[normalized]
    except KeyError as exc:
        raise ContractError(
            f"unknown WDS dataset {dataset_id!r}; available IDs: {sorted(_PRESETS)}"
        ) from exc
    selected_range = depth_range or preset.depth_range
    return preset.dataset_class(
        source,
        dataset_id=normalized,
        depth_scale=preset.depth_scale if depth_scale is None else depth_scale,
        depth_range=selected_range,
        raw_depth_spec=raw_depth or DepthSpec.metric(),
        target_depth_spec=target_depth or DepthSpec.metric(),
        image_size=image_size,
        shuffle=shuffle,
        num_samples=num_samples,
        error_policy=error_policy,
        build_pipeline=build_pipeline,
        **dataset_options,
    )


def create_webdataset_dataloader(
    sources: Sequence[str],
    dataset_ids: Sequence[str],
    *,
    raw_depth: DepthSpec | None = None,
    target_depth: DepthSpec | None = None,
    image_size: int = 518,
    batch_size: int = 1,
    shuffle: int = 1000,
    num_workers: int = 4,
    pin_memory: bool = True,
    drop_last: bool = False,
    error_policy: Literal["raise", "skip"] = "raise",
    multiprocessing_context: str | None = None,
    dataset_options: Sequence[Mapping[str, Any]] | None = None,
) -> DataLoader[Any]:
    if not sources or len(sources) != len(dataset_ids):
        raise ContractError("WDS sources and dataset_ids must have the same non-zero length")
    if batch_size <= 0 or num_workers < 0 or shuffle < 0:
        raise ContractError("WDS batch_size/shuffle must be positive and workers non-negative")
    if dataset_options is not None and len(dataset_options) != len(sources):
        raise ContractError("WDS dataset_options length must match sources")
    options = dataset_options or ({},) * len(sources)
    datasets = [
        create_webdataset(
            source,
            dataset_id=dataset_id,
            raw_depth=raw_depth,
            target_depth=target_depth,
            image_size=image_size,
            shuffle=shuffle,
            error_policy=error_policy,
            **dict(dataset_option),
        )
        for source, dataset_id, dataset_option in zip(
            sources,
            dataset_ids,
            options,
            strict=True,
        )
    ]
    combined: IterableDataset[RgbdSample]
    combined = datasets[0] if len(datasets) == 1 else InterleavedRgbdDataset(datasets)
    return DataLoader(
        combined,
        batch_size=batch_size,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        collate_fn=collate_rgbd_samples,
        persistent_workers=num_workers > 0,
        multiprocessing_context=multiprocessing_context,
    )
