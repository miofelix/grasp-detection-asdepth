"""WebDataset 解码、canonical sample 与旧 tensor tuple 适配。"""

from .adapter import LegacyWdsDatasetAdapter, adapt_legacy_wds_dataset
from .datasets import (
    DredsWebDataset,
    HammerWebDataset,
    HissWebDataset,
    HypersimWebDataset,
    InterleavedRgbdDataset,
    IrsWebDataset,
    RgbdWebDataset,
    VirtualKitti2WebDataset,
    hypersim_distance_to_depth,
)
from .factory import create_webdataset, create_webdataset_dataloader

__all__ = [
    "DredsWebDataset",
    "HammerWebDataset",
    "HissWebDataset",
    "HypersimWebDataset",
    "InterleavedRgbdDataset",
    "IrsWebDataset",
    "LegacyWdsDatasetAdapter",
    "RgbdWebDataset",
    "VirtualKitti2WebDataset",
    "adapt_legacy_wds_dataset",
    "create_webdataset",
    "create_webdataset_dataloader",
    "hypersim_distance_to_depth",
]
