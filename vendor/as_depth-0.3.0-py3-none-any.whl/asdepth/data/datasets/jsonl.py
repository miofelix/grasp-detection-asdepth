"""统一返回 `RgbdSample` 的 JSONL Dataset。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from torch.utils.data import Dataset

from asdepth.core import DepthMap, RgbdSample
from asdepth.core.serialization import frozen_mapping

from ..io import convert_metric_depth, read_intrinsics, read_metric_depth, read_rgb
from ..jsonl import JsonlRecordSet
from ..records import RgbdRecord


class JsonlRgbdDataset(Dataset[RgbdSample]):
    """HAMMER、ClearPose、DREDS、TransCG、TRansPose、KITTI 的统一 Dataset。"""

    def __init__(self, record_set: JsonlRecordSet) -> None:
        self.source = record_set.source
        self.spec = record_set.spec
        self.records = record_set.records
        self.dataset_id = self.spec.dataset_id
        self.dataset_name = self.dataset_id
        self.raw_type = self.spec.raw_type
        self.depth_scale = self.spec.depth_scale
        self.depth_range = [self.spec.min_valid, self.spec.max_valid]

    def __len__(self) -> int:
        return len(self.records)

    def _load_depth(self, path: Path, *, target: bool) -> DepthMap:
        metric = read_metric_depth(
            path,
            depth_scale=self.spec.depth_scale,
            min_valid=self.spec.min_valid,
            max_valid=self.spec.max_valid,
        )
        requested = self.spec.target_depth if target else self.spec.raw_depth
        return convert_metric_depth(metric, requested)

    def _metadata(self, record: RgbdRecord) -> dict[str, Any]:
        return {
            **dict(record.metadata),
            "dataset_id": self.dataset_id,
            "dataset_identity": self.spec.identity,
            "raw_type": self.raw_type,
            "depth_scale": self.depth_scale,
            "depth_range": tuple(self.depth_range),
            "rgb_path": str(record.rgb_path),
            "raw_depth_path": str(record.raw_depth_path),
            "target_depth_path": (
                "" if record.target_depth_path is None else str(record.target_depth_path)
            ),
            "intrinsics_path": (
                "" if record.intrinsics_path is None else str(record.intrinsics_path)
            ),
        }

    def __getitem__(self, index: int) -> RgbdSample:
        record = self.records[index]
        target = (
            None
            if record.target_depth_path is None
            else self._load_depth(record.target_depth_path, target=True)
        )
        intrinsics = (
            None if record.intrinsics_path is None else read_intrinsics(record.intrinsics_path)
        )
        return RgbdSample(
            sample_id=record.sample_id,
            rgb=read_rgb(record.rgb_path),
            raw_depth=self._load_depth(record.raw_depth_path, target=False),
            target_depth=target,
            intrinsics=intrinsics,
            metadata=frozen_mapping(self._metadata(record)),
        )
