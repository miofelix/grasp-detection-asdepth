"""实验室采集 JSONL 到统一 ``RgbdSample`` 的 Dataset。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from torch.utils.data import Dataset

from asdepth.core import ContractError, DepthSpec, RgbdSample
from asdepth.core.serialization import frozen_mapping

from ..io import convert_metric_depth, read_metric_depth, read_rgb


@dataclass(frozen=True, slots=True)
class LabRecord:
    """只解析路径、不加载像素的实验室录制记录。"""

    sample_id: str
    rgb_path: Path
    raw_depth_path: Path
    raw_depth_u16_path: Path | None
    meta_path: Path | None
    depth_scale_meters: float
    width: int
    height: int
    aligned_to: str
    metadata: MappingProxyType[str, Any]


def _resolve_path(root: Path, value: object, *, field: str, sample_id: str) -> Path:
    path = Path(str(value)).expanduser()
    resolved = path if path.is_absolute() else root / path
    if not resolved.exists():
        raise FileNotFoundError(
            f"Lab dataset sample {sample_id} references missing {field} file: {resolved}"
        )
    return resolved


def _optional_path(
    root: Path,
    value: object,
    *,
    field: str,
    sample_id: str,
) -> Path | None:
    if value is None or str(value) == "":
        return None
    return _resolve_path(root, value, field=field, sample_id=sample_id)


def load_lab_records(jsonl_path: str | Path) -> tuple[LabRecord, ...]:
    """保持源 ``LabDataset`` 的字段校验、相对路径和可选字段语义。"""

    source = Path(jsonl_path).expanduser()
    if not source.is_file():
        raise FileNotFoundError(source)
    root = source.parent
    records: list[LabRecord] = []
    with source.open(encoding="utf-8") as stream:
        for line_number, raw_line in enumerate(stream, start=1):
            line = raw_line.strip()
            if not line:
                continue
            payload = json.loads(line)
            if not isinstance(payload, dict):
                raise ContractError(f"Lab JSONL row must be an object: {source}:{line_number}")
            missing = [
                field for field in ("sample_id", "rgb", "raw_depth") if not payload.get(field)
            ]
            if missing:
                raise ContractError(f"Missing required fields at {source}:{line_number}: {missing}")
            sample_id = str(payload["sample_id"])
            scale = float(payload.get("depth_scale_meters", 0.001))
            if scale <= 0:
                raise ContractError(
                    f"Lab dataset sample {sample_id} depth_scale_meters must be positive"
                )
            width = int(payload.get("width", 0))
            height = int(payload.get("height", 0))
            if width < 0 or height < 0:
                raise ContractError(
                    f"Lab dataset sample {sample_id} width/height cannot be negative"
                )
            records.append(
                LabRecord(
                    sample_id=sample_id,
                    rgb_path=_resolve_path(
                        root,
                        payload["rgb"],
                        field="rgb",
                        sample_id=sample_id,
                    ),
                    raw_depth_path=_resolve_path(
                        root,
                        payload["raw_depth"],
                        field="raw_depth",
                        sample_id=sample_id,
                    ),
                    raw_depth_u16_path=_optional_path(
                        root,
                        payload.get("raw_depth_u16"),
                        field="raw_depth_u16",
                        sample_id=sample_id,
                    ),
                    meta_path=_optional_path(
                        root,
                        payload.get("meta"),
                        field="meta",
                        sample_id=sample_id,
                    ),
                    depth_scale_meters=scale,
                    width=width,
                    height=height,
                    aligned_to=str(payload.get("aligned_to", "")),
                    metadata=frozen_mapping(
                        {
                            "jsonl_row": line_number,
                            "source_fields": tuple(sorted(str(key) for key in payload)),
                        }
                    ),
                )
            )
    if not records:
        raise ContractError(f"Lab dataset index is empty: {source}")
    return tuple(records)


class LabRgbdDataset(Dataset[RgbdSample]):
    """实验室 RGB-D 输入；raw depth 进入内部后固定使用显式 ``DepthSpec``。"""

    dataset_id = "lab"
    dataset_name = "lab"

    def __init__(
        self,
        jsonl_path: str | Path,
        *,
        raw_depth: DepthSpec | None = None,
        min_depth_m: float | None = None,
        max_depth_m: float | None = 6.0,
    ) -> None:
        self.source = Path(jsonl_path).expanduser()
        self.records = load_lab_records(self.source)
        self.raw_depth_spec = raw_depth or DepthSpec.metric(
            min_valid=min_depth_m,
            max_valid=max_depth_m,
        )
        self.min_depth_m = min_depth_m
        self.max_depth_m = max_depth_m

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> RgbdSample:
        record = self.records[index]
        metric = read_metric_depth(
            record.raw_depth_path,
            depth_scale=1.0 / record.depth_scale_meters,
            min_valid=self.min_depth_m,
            max_valid=self.max_depth_m,
        )
        metadata = {
            **dict(record.metadata),
            "dataset_id": self.dataset_id,
            "rgb_path": str(record.rgb_path),
            "raw_depth_path": str(record.raw_depth_path),
            "raw_depth_u16_path": (
                "" if record.raw_depth_u16_path is None else str(record.raw_depth_u16_path)
            ),
            "meta_path": "" if record.meta_path is None else str(record.meta_path),
            "depth_scale_meters": record.depth_scale_meters,
            "width": record.width,
            "height": record.height,
            "aligned_to": record.aligned_to,
        }
        return RgbdSample(
            sample_id=record.sample_id,
            rgb=read_rgb(record.rgb_path),
            raw_depth=convert_metric_depth(metric, self.raw_depth_spec),
            metadata=frozen_mapping(metadata),
        )


def create_lab_dataset(
    source: str | Path,
    *,
    raw_depth: DepthSpec | None = None,
    min_depth_m: float | None = None,
    max_depth_m: float | None = 6.0,
) -> LabRgbdDataset:
    """构建实验室采集 Dataset 的正式 API。"""

    return LabRgbdDataset(
        source,
        raw_depth=raw_depth,
        min_depth_m=min_depth_m,
        max_depth_m=max_depth_m,
    )
