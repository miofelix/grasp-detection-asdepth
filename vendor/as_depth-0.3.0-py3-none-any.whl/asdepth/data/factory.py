"""Dataset 与 DataLoader 的正式构建 API。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from torch.utils.data import DataLoader, Dataset, IterableDataset

from asdepth.core import ContractError, DepthSpec, RgbdSample

from .catalog import DatasetCatalog
from .collate import collate_rgbd_samples
from .datasets import JsonlRgbdDataset
from .jsonl import parse_jsonl_records


def create_dataset(
    source: str | Path,
    *,
    dataset_id: str,
    raw_type: str | None = None,
    raw_depth: DepthSpec | None = None,
    target_depth: DepthSpec | None = None,
    max_length_each_sequence: int | None = None,
    require_target: bool = True,
    catalog: DatasetCatalog | None = None,
) -> JsonlRgbdDataset:
    """构建显式 dataset_id 的 JSONL Dataset；默认要求每条记录包含 target。"""

    active_catalog = catalog or DatasetCatalog.from_package()
    spec = active_catalog.resolve(
        dataset_id,
        raw_type=raw_type,
        raw_depth=raw_depth,
        target_depth=target_depth,
    )
    record_set = parse_jsonl_records(
        source,
        spec,
        max_length_each_sequence=max_length_each_sequence,
        require_target=require_target,
    )
    return JsonlRgbdDataset(record_set)


def create_dataloader(
    dataset: Dataset[RgbdSample] | IterableDataset[RgbdSample],
    *,
    batch_size: int = 1,
    shuffle: bool = False,
    num_workers: int = 0,
    pin_memory: bool = False,
    drop_last: bool = False,
    **kwargs: Any,
) -> DataLoader[Any]:
    if batch_size <= 0 or num_workers < 0:
        raise ContractError("batch_size must be positive and num_workers cannot be negative")
    if isinstance(dataset, IterableDataset) and shuffle:
        raise ContractError("IterableDataset cannot be shuffled by DataLoader")
    if "collate_fn" in kwargs:
        raise ContractError("create_dataloader owns collate_fn for the RgbdBatch contract")
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle if not isinstance(dataset, IterableDataset) else False,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=drop_last,
        collate_fn=collate_rgbd_samples,
        persistent_workers=num_workers > 0,
        **kwargs,
    )
