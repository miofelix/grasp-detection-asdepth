"""Dataset 配置、manifest 与深度语义。"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, ClassVar, cast

from asdepth.core import ContractError, DepthSpec
from asdepth.core.serialization import (
    frozen_mapping,
    require_exact_keys,
    require_schema_version,
    to_primitive,
)


def _sha256_payload(value: Any) -> str:
    payload = json.dumps(
        to_primitive(value),
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass(frozen=True, slots=True)
class DatasetSpec:
    """构建 Dataset 所需的稳定身份、IO 比例和输出深度语义。"""

    dataset_id: str
    dataset_version: str
    layout: str
    raw_type: str | None
    depth_scale: float
    min_valid: float | None
    max_valid: float | None
    raw_depth: DepthSpec
    target_depth: DepthSpec
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.dataset_id or not self.dataset_version:
            raise ContractError("dataset_id and dataset_version are required")
        if self.layout not in {"direct", "sequence_glob", "webdataset"}:
            raise ContractError(f"unsupported dataset layout {self.layout!r}")
        if self.depth_scale <= 0:
            raise ContractError("depth_scale must be positive")
        if self.min_valid is not None and self.min_valid <= 0:
            raise ContractError("min_valid must be positive when set")
        if self.max_valid is not None and self.max_valid <= 0:
            raise ContractError("max_valid must be positive when set")
        if (
            self.min_valid is not None
            and self.max_valid is not None
            and self.min_valid >= self.max_valid
        ):
            raise ContractError("dataset min_valid must be smaller than max_valid")
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    @property
    def config_hash(self) -> str:
        return _sha256_payload(self.to_dict())

    @property
    def identity(self) -> str:
        return f"{self.dataset_id}@{self.dataset_version}+{self.config_hash[:12]}"

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))


@dataclass(frozen=True, slots=True)
class DatasetManifest:
    """与 `dataset-v1.schema.json` 对齐的可归档数据集 manifest。"""

    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    dataset_id: str
    dataset_version: str
    depth: DepthSpec
    samples_file: str
    sample_count: int
    fingerprint: str
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"DatasetManifest requires schema {self.SCHEMA_VERSION}")
        if not self.dataset_id or not self.dataset_version or not self.samples_file:
            raise ContractError("dataset identity and samples_file are required")
        if self.sample_count < 0:
            raise ContractError("sample_count cannot be negative")
        if len(self.fingerprint) != 64 or any(
            char not in "0123456789abcdef" for char in self.fingerprint
        ):
            raise ContractError("dataset fingerprint must be a lowercase SHA-256 digest")
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> DatasetManifest:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "dataset_id",
                "dataset_version",
                "depth",
                "samples_file",
                "sample_count",
                "fingerprint",
                "metadata",
            },
            context="DatasetManifest",
        )
        require_schema_version(payload, context="DatasetManifest")
        values = dict(payload)
        values["depth"] = DepthSpec.from_dict(payload["depth"])
        values["metadata"] = frozen_mapping(payload["metadata"])
        return cls(**values)
