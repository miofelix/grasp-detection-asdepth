"""随包发布的 dataset catalog。"""

from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

from asdepth.core import ContractError, DepthRepresentation, DepthSpec
from asdepth.core.serialization import frozen_mapping

from .specs import DatasetSpec


@dataclass(frozen=True, slots=True)
class DatasetCatalogEntry:
    dataset_id: str
    dataset_version: str
    layout: str
    supported_raw_types: tuple[str, ...]
    default_raw_type: str | None
    depth_scale: float
    min_valid: float | None
    max_valid: float | None
    max_length_each_sequence: int | None = None

    def resolve(
        self,
        *,
        raw_type: str | None = None,
        raw_depth: DepthSpec | None = None,
        target_depth: DepthSpec | None = None,
    ) -> DatasetSpec:
        selected_raw_type = self.default_raw_type if raw_type is None else raw_type.lower()
        if self.supported_raw_types:
            if selected_raw_type not in self.supported_raw_types:
                raise ContractError(
                    f"dataset {self.dataset_id!r} supports raw types "
                    f"{list(self.supported_raw_types)}, got {selected_raw_type!r}"
                )
        else:
            selected_raw_type = None

        raw_spec = raw_depth or DepthSpec.metric(
            min_valid=self.min_valid,
            max_valid=self.max_valid,
        )
        target_spec = target_depth or DepthSpec.metric(
            min_valid=self.min_valid,
            max_valid=self.max_valid,
        )
        for name, spec in (("raw_depth", raw_spec), ("target_depth", target_spec)):
            if spec.representation is DepthRepresentation.LOG_DEPTH_3CH:
                raise ContractError(f"dataset {name} cannot be log_depth_3ch")

        return DatasetSpec(
            dataset_id=self.dataset_id,
            dataset_version=self.dataset_version,
            layout=self.layout,
            raw_type=selected_raw_type,
            depth_scale=self.depth_scale,
            min_valid=self.min_valid,
            max_valid=self.max_valid,
            raw_depth=raw_spec,
            target_depth=target_spec,
            metadata=frozen_mapping(
                {
                    "supported_raw_types": self.supported_raw_types,
                    "max_length_each_sequence": self.max_length_each_sequence,
                }
            ),
        )


def _optional_float(value: Any) -> float | None:
    return None if value is None else float(value)


class DatasetCatalog:
    def __init__(self, entries: tuple[DatasetCatalogEntry, ...]) -> None:
        self._entries = entries
        self._by_id = {entry.dataset_id: entry for entry in entries}
        if len(self._by_id) != len(entries):
            raise ContractError("dataset catalog contains duplicate dataset_id values")

    @classmethod
    def from_package(cls) -> DatasetCatalog:
        resource = resources.files("asdepth.resources").joinpath("catalog/datasets.yaml")
        payload = yaml.safe_load(resource.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("schema_version") != "1.0.0":
            raise ContractError("unsupported or malformed dataset catalog")
        raw_entries = payload.get("datasets")
        if not isinstance(raw_entries, list):
            raise ContractError("dataset catalog datasets must be a list")
        dataset_version = str(payload["dataset_version"])
        entries: list[DatasetCatalogEntry] = []
        for raw in raw_entries:
            if not isinstance(raw, dict):
                raise ContractError("dataset catalog entries must be mappings")
            depth_range = raw.get("default_depth_range")
            if not isinstance(depth_range, list) or len(depth_range) != 2:
                raise ContractError("dataset default_depth_range must contain two values")
            entries.append(
                DatasetCatalogEntry(
                    dataset_id=str(raw["dataset_id"]),
                    dataset_version=dataset_version,
                    layout=str(raw["layout"]),
                    supported_raw_types=tuple(str(value) for value in raw["supported_raw_types"]),
                    default_raw_type=(
                        None
                        if raw.get("default_raw_type") is None
                        else str(raw["default_raw_type"])
                    ),
                    depth_scale=float(raw["depth_scale"]),
                    min_valid=_optional_float(depth_range[0]),
                    max_valid=_optional_float(depth_range[1]),
                    max_length_each_sequence=(
                        None
                        if raw.get("max_length_each_sequence") is None
                        else int(raw["max_length_each_sequence"])
                    ),
                )
            )
        return cls(tuple(entries))

    @property
    def entries(self) -> tuple[DatasetCatalogEntry, ...]:
        return self._entries

    def get(self, dataset_id: str) -> DatasetCatalogEntry:
        try:
            return self._by_id[dataset_id.lower()]
        except KeyError as exc:
            raise ContractError(
                f"unknown dataset {dataset_id!r}; available IDs: {sorted(self._by_id)}"
            ) from exc

    def resolve(
        self,
        dataset_id: str,
        *,
        raw_type: str | None = None,
        raw_depth: DepthSpec | None = None,
        target_depth: DepthSpec | None = None,
    ) -> DatasetSpec:
        return self.get(dataset_id).resolve(
            raw_type=raw_type,
            raw_depth=raw_depth,
            target_depth=target_depth,
        )


def load_dataset_catalog(path: str | Path | None = None) -> DatasetCatalog:
    """当前只暴露包内 catalog；`path` 为未来显式扩展保留。"""

    if path is not None:
        raise ContractError("external dataset catalogs are not supported in schema v1")
    return DatasetCatalog.from_package()
