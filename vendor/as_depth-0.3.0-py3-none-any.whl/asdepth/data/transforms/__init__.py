"""数据侧确定性 transform。"""

from .legacy_dpt import LegacyDptTransform

__all__ = ["LegacyDptTransform"]
