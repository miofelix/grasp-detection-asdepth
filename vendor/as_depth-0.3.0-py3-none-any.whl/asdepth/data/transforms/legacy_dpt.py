"""保持源 WDS 的 DPT resize、ImageNet normalize 与 CHW 布局。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import cv2
import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError


@dataclass(frozen=True, slots=True)
class LegacyDptTransform:
    image_size: int = 518
    ensure_multiple_of: int = 14
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound"
    mean: tuple[float, float, float] = (0.485, 0.456, 0.406)
    std: tuple[float, float, float] = (0.229, 0.224, 0.225)

    def __post_init__(self) -> None:
        if self.image_size <= 0 or self.ensure_multiple_of <= 0:
            raise ContractError("transform dimensions must be positive")
        if self.resize_method not in {"lower_bound", "upper_bound"}:
            raise ContractError(f"unsupported resize_method {self.resize_method!r}")
        if any(value <= 0 for value in self.std):
            raise ContractError("transform std values must be positive")

    def _constrain(
        self,
        value: float,
        *,
        minimum: int | None = None,
        maximum: int | None = None,
    ) -> int:
        multiple = self.ensure_multiple_of
        result = int(np.round(value / multiple) * multiple)
        if maximum is not None and result > maximum:
            result = int(np.floor(value / multiple) * multiple)
        if minimum is not None and result < minimum:
            result = int(np.ceil(value / multiple) * multiple)
        if result <= 0:
            raise ContractError(f"resize produced a non-positive dimension from {value}")
        return result

    def output_size(self, width: int, height: int) -> tuple[int, int]:
        if width <= 0 or height <= 0:
            raise ContractError("transform input dimensions must be positive")
        scales = (self.image_size / height, self.image_size / width)
        scale = max(scales) if self.resize_method == "lower_bound" else min(scales)
        constraint = (
            {"minimum": self.image_size}
            if self.resize_method == "lower_bound"
            else {"maximum": self.image_size}
        )
        return (
            self._constrain(scale * width, **constraint),
            self._constrain(scale * height, **constraint),
        )

    def prepare_input(
        self,
        rgb: NDArray[np.uint8],
        raw_depth: NDArray[np.float32],
    ) -> tuple[NDArray[np.float32], NDArray[np.float32]]:
        """复用源批量推理的 RGB normalize、nearest depth resize 和 CHW 布局。"""

        image = np.asarray(rgb)
        raw = np.asarray(raw_depth, dtype=np.float32)
        if raw.shape != image.shape[:2]:
            raise ContractError(f"RGB/raw depth shapes differ: rgb={image.shape}, raw={raw.shape}")

        chw = self.prepare_rgb(image)
        size = self.output_size(image.shape[1], image.shape[0])
        resized_raw = cv2.resize(raw, size, interpolation=cv2.INTER_NEAREST)
        return chw, np.ascontiguousarray(resized_raw, dtype=np.float32)

    def prepare_rgb(self, rgb: NDArray[np.uint8]) -> NDArray[np.float32]:
        """按同一 DPT 契约预处理 RGB-only 模型输入。"""

        image = np.asarray(rgb)
        if image.ndim != 3 or image.shape[-1] != 3:
            raise ContractError(f"RGB must be HWC with three channels, got {image.shape}")
        if not np.issubdtype(image.dtype, np.integer):
            raise ContractError("RGB must use integer 0-255 values")

        size = self.output_size(image.shape[1], image.shape[0])
        image_float = image.astype(np.float32, copy=False) / np.float32(255.0)
        resized_rgb = cv2.resize(image_float, size, interpolation=cv2.INTER_CUBIC)
        normalized = (resized_rgb - np.asarray(self.mean, dtype=np.float32)) / np.asarray(
            self.std, dtype=np.float32
        )
        chw = np.ascontiguousarray(np.transpose(normalized, (2, 0, 1))).astype(np.float32)
        return chw

    def __call__(
        self,
        rgb: NDArray[np.uint8],
        raw_depth: NDArray[np.float32],
        target_depth: NDArray[np.float32],
    ) -> tuple[NDArray[np.float32], NDArray[np.float32], NDArray[np.float32]]:
        image = np.asarray(rgb)
        target = np.asarray(target_depth, dtype=np.float32)
        if target.shape != image.shape[:2]:
            raise ContractError(
                f"WDS RGB/target shapes differ: rgb={image.shape}, target={target.shape}"
            )

        chw, resized_raw = self.prepare_input(rgb, raw_depth)
        size = self.output_size(image.shape[1], image.shape[0])
        resized_target = cv2.resize(target, size, interpolation=cv2.INTER_NEAREST)
        return (
            chw,
            resized_raw,
            np.ascontiguousarray(resized_target, dtype=np.float32),
        )
