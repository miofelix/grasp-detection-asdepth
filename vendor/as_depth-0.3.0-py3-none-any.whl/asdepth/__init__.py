"""AS-Depth 的稳定公共包。"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("as-depth")
except PackageNotFoundError:  # pragma: no cover - source tree without installation
    __version__ = "0.3.0"


__all__ = ["__version__"]
