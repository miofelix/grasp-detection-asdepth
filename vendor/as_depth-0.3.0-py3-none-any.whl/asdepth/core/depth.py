"""深度表示、单位和不可变 DepthMap。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, ClassVar, cast

import numpy as np
from numpy.typing import NDArray

from .errors import ContractError
from .serialization import require_exact_keys, require_schema_version, to_primitive


class DepthRepresentation(str, Enum):
    """公共 API 支持的深度表示。"""

    METRIC_DEPTH = "metric_depth"
    INVERSE_DEPTH = "inverse_depth"
    LOG_DEPTH_3CH = "log_depth_3ch"


class DepthUnit(str, Enum):
    """深度数组的显式单位。"""

    METER = "meter"
    MILLIMETER = "millimeter"
    UNITLESS = "unitless"


@dataclass(frozen=True, slots=True)
class DepthSpec:
    """深度张量的表示、单位、有效范围和通道契约。"""

    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    representation: DepthRepresentation
    unit: DepthUnit
    invalid_value: float = 0.0
    min_valid: float | None = None
    max_valid: float | None = None
    channels: int = 1
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.representation, DepthRepresentation):
            object.__setattr__(self, "representation", DepthRepresentation(self.representation))
        if not isinstance(self.unit, DepthUnit):
            object.__setattr__(self, "unit", DepthUnit(self.unit))
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(
                f"DepthSpec schema_version must be {self.SCHEMA_VERSION!r}, "
                f"got {self.schema_version!r}"
            )
        if self.invalid_value != 0.0:
            raise ContractError("depth invalid_value must be exactly 0.0")
        if self.channels < 1:
            raise ContractError("depth channels must be positive")
        if self.min_valid is not None and self.min_valid <= 0:
            raise ContractError("min_valid must be positive when set")
        if (
            self.min_valid is not None
            and self.max_valid is not None
            and self.min_valid >= self.max_valid
        ):
            raise ContractError("min_valid must be smaller than max_valid")

        if self.representation is DepthRepresentation.METRIC_DEPTH:
            if self.unit is not DepthUnit.METER:
                raise ContractError("internal metric_depth must use meter")
            if self.channels != 1:
                raise ContractError("metric_depth must have one channel")
        elif self.representation is DepthRepresentation.INVERSE_DEPTH:
            if self.unit is not DepthUnit.UNITLESS:
                raise ContractError("inverse_depth must use unitless values")
            if self.channels != 1:
                raise ContractError("inverse_depth must have one channel")
        elif self.representation is DepthRepresentation.LOG_DEPTH_3CH:
            if self.unit is not DepthUnit.UNITLESS or self.channels != 3:
                raise ContractError("log_depth_3ch must be unitless with three channels")

    @classmethod
    def metric(cls, *, min_valid: float | None = None, max_valid: float | None = None) -> DepthSpec:
        return cls(
            representation=DepthRepresentation.METRIC_DEPTH,
            unit=DepthUnit.METER,
            min_valid=min_valid,
            max_valid=max_valid,
        )

    @classmethod
    def inverse(cls) -> DepthSpec:
        return cls(
            representation=DepthRepresentation.INVERSE_DEPTH,
            unit=DepthUnit.UNITLESS,
        )

    @classmethod
    def log_depth_3ch(cls) -> DepthSpec:
        return cls(
            representation=DepthRepresentation.LOG_DEPTH_3CH,
            unit=DepthUnit.UNITLESS,
            channels=3,
        )

    @classmethod
    def from_is_disp(cls, is_disp: bool) -> DepthSpec:
        """只在兼容入口把旧 `is_disp` 转为正式语义。"""

        return cls.inverse() if is_disp else cls.metric()

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> DepthSpec:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "representation",
                "unit",
                "invalid_value",
                "min_valid",
                "max_valid",
                "channels",
            },
            context="DepthSpec",
        )
        require_schema_version(payload, context="DepthSpec")
        return cls(**payload)


@dataclass(frozen=True, slots=True)
class DepthMap:
    """携带 DepthSpec 的只读 float32 数组。"""

    values: NDArray[np.float32]
    spec: DepthSpec

    def __post_init__(self) -> None:
        values = np.array(self.values, dtype=np.float32, copy=True, order="C")
        expected_ndim = 2 if self.spec.channels == 1 else 3
        if values.ndim != expected_ndim:
            raise ContractError(
                f"{self.spec.representation.value} expects {expected_ndim} dimensions, "
                f"got shape {values.shape}"
            )
        if self.spec.channels > 1 and values.shape[0] != self.spec.channels:
            raise ContractError(
                f"expected channel-first shape ({self.spec.channels}, H, W), got {values.shape}"
            )

        values[~np.isfinite(values)] = self.spec.invalid_value
        if self.spec.representation is not DepthRepresentation.LOG_DEPTH_3CH:
            values[values < 0] = self.spec.invalid_value
            valid = values > self.spec.invalid_value
            if self.spec.min_valid is not None:
                values[valid & (values < self.spec.min_valid)] = self.spec.invalid_value
            if self.spec.max_valid is not None:
                values[valid & (values > self.spec.max_valid)] = self.spec.invalid_value
        values.setflags(write=False)
        object.__setattr__(self, "values", values)

    def __reduce__(self) -> tuple[type[DepthMap], tuple[NDArray[np.float32], DepthSpec]]:
        """Re-run validation so pickle round-trips preserve array immutability."""

        return type(self), (self.values, self.spec)

    @property
    def shape(self) -> tuple[int, ...]:
        return self.values.shape

    @property
    def valid_mask(self) -> NDArray[np.bool_]:
        if self.spec.representation is DepthRepresentation.LOG_DEPTH_3CH:
            raise ContractError("raw log_depth_3ch has no implicit metric valid mask")
        return self.values > self.spec.invalid_value

    def to_metric(self) -> DepthMap:
        if self.spec.representation is DepthRepresentation.METRIC_DEPTH:
            return self
        if self.spec.representation is DepthRepresentation.LOG_DEPTH_3CH:
            raise ContractError("log_depth_3ch requires an explicit compatibility decoder")
        result = np.zeros_like(self.values)
        valid = self.valid_mask
        np.divide(1.0, self.values, out=result, where=valid)
        return DepthMap(result, DepthSpec.metric())

    def to_inverse(self) -> DepthMap:
        if self.spec.representation is DepthRepresentation.INVERSE_DEPTH:
            return self
        if self.spec.representation is DepthRepresentation.LOG_DEPTH_3CH:
            raise ContractError("log_depth_3ch requires an explicit compatibility decoder")
        result = np.zeros_like(self.values)
        valid = self.valid_mask
        np.divide(1.0, self.values, out=result, where=valid)
        return DepthMap(result, DepthSpec.inverse())

    @classmethod
    def from_metric_array(
        cls,
        values: NDArray[Any],
        *,
        unit: DepthUnit = DepthUnit.METER,
        min_valid: float | None = None,
        max_valid: float | None = None,
    ) -> DepthMap:
        metric = np.asarray(values, dtype=np.float32)
        if unit is DepthUnit.MILLIMETER:
            metric = metric / np.float32(1000.0)
        elif unit is not DepthUnit.METER:
            raise ContractError(f"metric array cannot use unit {unit.value}")
        return cls(metric, DepthSpec.metric(min_valid=min_valid, max_valid=max_valid))
