"""dataclass、Enum、Path 与 NumPy 值的确定性 JSON 转换。"""

from __future__ import annotations

import copyreg
from dataclasses import fields, is_dataclass
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any, cast

import numpy as np

from .errors import ContractError, UnsupportedSchemaVersionError


def _restore_mapping_proxy(value: dict[Any, Any]) -> MappingProxyType[Any, Any]:
    """Restore a read-only mapping after crossing a pickle boundary."""

    return MappingProxyType(value)


def _reduce_mapping_proxy(
    value: MappingProxyType[Any, Any],
) -> tuple[Any, tuple[dict[Any, Any]]]:
    return _restore_mapping_proxy, (dict(value),)


# ``mappingproxy`` has no built-in pickle reducer. Canonical metadata uses it
# deliberately, so register a process-wide reducer before DataLoader workers
# serialize Dataset/Sample/Batch objects under the ``spawn`` start method.
copyreg.pickle(type(MappingProxyType({})), cast(Any, _reduce_mapping_proxy))


def to_primitive(value: Any) -> Any:
    """递归转换为 JSON/YAML 可序列化且不共享可变容器的值。"""

    if value is None or isinstance(value, bool | int | float | str):
        return value
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, np.generic):
        return value.item()
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: to_primitive(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, dict | MappingProxyType):
        return {str(key): to_primitive(item) for key, item in value.items()}
    if isinstance(value, tuple | list):
        return [to_primitive(item) for item in value]
    raise TypeError(f"cannot serialize {type(value).__name__}")


def frozen_mapping(value: dict[str, Any] | None = None) -> MappingProxyType[str, Any]:
    """复制并冻结一层 metadata mapping，避免调用方后续修改。"""

    return MappingProxyType(dict(value or {}))


def require_exact_keys(
    payload: dict[str, Any],
    *,
    required: set[str],
    optional: set[str] | None = None,
    context: str,
) -> None:
    """以清晰错误拒绝缺失字段和未知字段。"""

    optional = optional or set()
    missing = required - payload.keys()
    unknown = payload.keys() - required - optional
    if missing:
        raise ContractError(f"{context} is missing required fields: {sorted(missing)}")
    if unknown:
        raise ContractError(f"{context} contains unknown fields: {sorted(unknown)}")


def require_schema_version(
    payload: dict[str, Any], expected: str = "1.0.0", *, context: str
) -> None:
    """当前只接受精确版本，避免静默读取未知 schema。"""

    actual = payload.get("schema_version")
    if actual != expected:
        raise UnsupportedSchemaVersionError(
            f"unsupported {context} schema_version {actual!r}; expected {expected!r}"
        )
