"""TensorSpec 与 ModelSpec。"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, ClassVar, cast

from .depth import DepthSpec
from .errors import ContractError
from .serialization import (
    frozen_mapping,
    require_exact_keys,
    require_schema_version,
    to_primitive,
)

Dimension = int | str | None
_HEX_SHA256 = re.compile(r"^[0-9a-f]{64}$")


@dataclass(frozen=True, slots=True)
class TensorSpec:
    """runtime 边界上的名称、dtype、shape、layout 和语义。"""

    name: str
    dtype: str
    shape: tuple[Dimension, ...]
    layout: str | None = None
    semantic: str | None = None
    optional: bool = False

    def __post_init__(self) -> None:
        if not self.name:
            raise ContractError("TensorSpec name cannot be empty")
        if not self.dtype:
            raise ContractError("TensorSpec dtype cannot be empty")
        shape = tuple(self.shape)
        if not shape:
            raise ContractError("TensorSpec shape cannot be empty")
        for dimension in shape:
            if isinstance(dimension, int) and dimension <= 0:
                raise ContractError("fixed tensor dimensions must be positive")
            if isinstance(dimension, str) and not dimension:
                raise ContractError("symbolic tensor dimensions cannot be empty")
            if dimension is not None and not isinstance(dimension, int | str):
                raise ContractError(f"invalid tensor dimension {dimension!r}")
        object.__setattr__(self, "shape", shape)

    def matches(self, value: Any) -> bool:
        actual_shape = tuple(int(item) for item in value.shape)
        if len(actual_shape) != len(self.shape):
            return False
        symbols: dict[str, int] = {}
        for expected, actual in zip(self.shape, actual_shape, strict=True):
            if isinstance(expected, int) and expected != actual:
                return False
            if isinstance(expected, str):
                previous = symbols.setdefault(expected, actual)
                if previous != actual:
                    return False
        actual_dtype = str(value.dtype).removeprefix("torch.")
        return actual_dtype == self.dtype.removeprefix("torch.")

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> TensorSpec:
        require_exact_keys(
            payload,
            required={"name", "dtype", "shape", "layout", "semantic", "optional"},
            context="TensorSpec",
        )
        return cls(**payload)


@dataclass(frozen=True, slots=True)
class ModelSpec:
    """不依赖 checkpoint 路径的模型身份和 IO 契约。"""

    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    model_id: str
    model_version: str
    config_hash: str
    entrypoint: str
    inputs: tuple[TensorSpec, ...]
    outputs: tuple[TensorSpec, ...]
    depth: DepthSpec
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(
                f"ModelSpec schema_version must be {self.SCHEMA_VERSION!r}, got {self.schema_version!r}"
            )
        if not self.model_id or not self.model_version or not self.entrypoint:
            raise ContractError("model_id, model_version, and entrypoint are required")
        if not _HEX_SHA256.fullmatch(self.config_hash):
            raise ContractError("ModelSpec config_hash must be a lowercase SHA-256 digest")
        if not self.inputs or not self.outputs:
            raise ContractError("ModelSpec requires at least one input and one output")
        object.__setattr__(self, "inputs", tuple(self.inputs))
        object.__setattr__(self, "outputs", tuple(self.outputs))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    @property
    def identity(self) -> str:
        return f"{self.model_id}@{self.model_version}+{self.config_hash[:12]}"

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> ModelSpec:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "model_id",
                "model_version",
                "config_hash",
                "entrypoint",
                "inputs",
                "outputs",
                "depth",
                "metadata",
            },
            context="ModelSpec",
        )
        require_schema_version(payload, context="ModelSpec")
        values = dict(payload)
        values["inputs"] = tuple(TensorSpec.from_dict(item) for item in payload["inputs"])
        values["outputs"] = tuple(TensorSpec.from_dict(item) for item in payload["outputs"])
        values["depth"] = DepthSpec.from_dict(payload["depth"])
        values["metadata"] = frozen_mapping(payload["metadata"])
        return cls(**values)
