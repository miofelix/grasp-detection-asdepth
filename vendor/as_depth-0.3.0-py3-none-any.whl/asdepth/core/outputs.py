"""模型与推理输出的稳定容器。"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .depth import DepthMap
from .errors import ContractError
from .serialization import frozen_mapping
from .specs import ModelSpec


@dataclass(frozen=True, slots=True)
class ModelOutput:
    """模型 forward 的 canonical 语义输出。"""

    depth: DepthMap
    auxiliary: MappingProxyType[str, NDArray[Any]] = field(
        default_factory=lambda: MappingProxyType({})
    )

    def __post_init__(self) -> None:
        frozen: dict[str, NDArray[Any]] = {}
        for name, value in self.auxiliary.items():
            if not name:
                raise ContractError("auxiliary output names cannot be empty")
            array = np.array(value, copy=True, order="C")
            array.setflags(write=False)
            frozen[name] = array
        object.__setattr__(self, "auxiliary", MappingProxyType(frozen))


@dataclass(frozen=True, slots=True)
class InferenceOutput:
    """单样本 runtime 输出及可审计元数据。"""

    sample_id: str
    model: ModelSpec
    output: ModelOutput
    timings_ms: MappingProxyType[str, float] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.sample_id:
            raise ContractError("InferenceOutput sample_id cannot be empty")
        timings = {str(name): float(value) for name, value in self.timings_ms.items()}
        if any(value < 0 for value in timings.values()):
            raise ContractError("inference timings cannot be negative")
        object.__setattr__(self, "timings_ms", MappingProxyType(timings))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))
