"""与框架外层无关的核心类型。"""

from .cli import parse_bool
from .depth import DepthMap, DepthRepresentation, DepthSpec, DepthUnit
from .errors import (
    ArtifactExistsError,
    AsDepthError,
    ContractError,
    UnsafePathError,
    UnsupportedSchemaVersionError,
)
from .outputs import InferenceOutput, ModelOutput
from .samples import RgbdBatch, RgbdSample
from .specs import ModelSpec, TensorSpec

__all__ = [
    "ArtifactExistsError",
    "AsDepthError",
    "ContractError",
    "DepthMap",
    "DepthRepresentation",
    "DepthSpec",
    "DepthUnit",
    "InferenceOutput",
    "ModelOutput",
    "ModelSpec",
    "RgbdBatch",
    "RgbdSample",
    "TensorSpec",
    "UnsafePathError",
    "UnsupportedSchemaVersionError",
    "parse_bool",
]
