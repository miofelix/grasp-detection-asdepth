"""统一 RgbdSample 与 RgbdBatch。"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .depth import DepthMap, DepthSpec
from .errors import ContractError
from .serialization import frozen_mapping


def _readonly_array(value: NDArray[Any]) -> NDArray[Any]:
    result = np.array(value, copy=True, order="C")
    result.setflags(write=False)
    return result


def _rgb_spatial_shape(rgb: NDArray[Any]) -> tuple[int, int]:
    if rgb.ndim != 3:
        raise ContractError(f"rgb must have three dimensions, got {rgb.shape}")
    if rgb.shape[-1] in {3, 4}:
        return int(rgb.shape[0]), int(rgb.shape[1])
    if rgb.shape[0] in {3, 4}:
        return int(rgb.shape[1]), int(rgb.shape[2])
    raise ContractError(f"rgb must be HWC or CHW with 3/4 channels, got {rgb.shape}")


@dataclass(frozen=True, slots=True)
class RgbdSample:
    """所有活跃 Dataset 返回的单一样本类型。"""

    sample_id: str
    rgb: NDArray[Any]
    raw_depth: DepthMap
    target_depth: DepthMap | None = None
    intrinsics: NDArray[np.float32] | None = None
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.sample_id:
            raise ContractError("sample_id cannot be empty")
        rgb = _readonly_array(self.rgb)
        if _rgb_spatial_shape(rgb) != self.raw_depth.shape[-2:]:
            raise ContractError(
                f"rgb/raw depth spatial mismatch: {_rgb_spatial_shape(rgb)} vs "
                f"{self.raw_depth.shape[-2:]}"
            )
        if (
            self.target_depth is not None
            and self.target_depth.shape[-2:] != self.raw_depth.shape[-2:]
        ):
            raise ContractError(
                f"raw/target depth spatial mismatch: {self.raw_depth.shape[-2:]} vs "
                f"{self.target_depth.shape[-2:]}"
            )
        object.__setattr__(self, "rgb", rgb)
        if self.intrinsics is not None:
            intrinsics = np.array(self.intrinsics, dtype=np.float32, copy=True)
            if intrinsics.shape != (3, 3):
                raise ContractError(f"intrinsics must be 3x3, got {intrinsics.shape}")
            intrinsics.setflags(write=False)
            object.__setattr__(self, "intrinsics", intrinsics)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def __reduce__(self) -> tuple[type[RgbdSample], tuple[Any, ...]]:
        """Re-run canonical validation after crossing a pickle boundary."""

        return type(self), (
            self.sample_id,
            self.rgb,
            self.raw_depth,
            self.target_depth,
            self.intrinsics,
            self.metadata,
        )


@dataclass(frozen=True, slots=True)
class RgbdBatch:
    """collate 后的固定字段 batch，不使用不定长 tuple。"""

    sample_ids: tuple[str, ...]
    rgb: Any
    raw_depth: Any
    depth_spec: DepthSpec
    target_depth: Any | None = None
    target_depth_spec: DepthSpec | None = None
    intrinsics: Any | None = None
    metadata: tuple[MappingProxyType[str, Any], ...] = ()

    def __post_init__(self) -> None:
        sample_ids = tuple(self.sample_ids)
        if not sample_ids or any(not value for value in sample_ids):
            raise ContractError("RgbdBatch requires non-empty sample_ids")
        object.__setattr__(self, "sample_ids", sample_ids)
        batch_size = len(sample_ids)
        for name in ("rgb", "raw_depth", "target_depth", "intrinsics"):
            value = getattr(self, name)
            if value is not None and hasattr(value, "shape") and int(value.shape[0]) != batch_size:
                raise ContractError(
                    f"{name} batch dimension {int(value.shape[0])} does not match {batch_size} IDs"
                )
        if self.target_depth is None and self.target_depth_spec is not None:
            raise ContractError("target_depth_spec requires target_depth")
        if self.target_depth is not None and self.target_depth_spec is None:
            object.__setattr__(self, "target_depth_spec", self.depth_spec)
        metadata = tuple(
            value if isinstance(value, MappingProxyType) else frozen_mapping(dict(value))
            for value in self.metadata
        )
        if metadata and len(metadata) != batch_size:
            raise ContractError("metadata length must match sample_ids")
        object.__setattr__(self, "metadata", metadata)

    def __reduce__(self) -> tuple[type[RgbdBatch], tuple[Any, ...]]:
        """Re-run fixed-field validation after crossing a pickle boundary."""

        return type(self), (
            self.sample_ids,
            self.rgb,
            self.raw_depth,
            self.depth_spec,
            self.target_depth,
            self.target_depth_spec,
            self.intrinsics,
            self.metadata,
        )

    @property
    def batch_size(self) -> int:
        return len(self.sample_ids)

    @property
    def raw_depth_spec(self) -> DepthSpec:
        """`depth_spec` 的语义化别名，保留 Phase 2 字段兼容。"""

        return self.depth_spec
