"""稳定公共契约使用的异常类型。"""


class AsDepthError(Exception):
    """所有可预期 AS-Depth 领域错误的基类。"""


class ContractError(AsDepthError, ValueError):
    """输入不满足版本化公共契约。"""


class UnsupportedSchemaVersionError(ContractError):
    """manifest 的 schema version 不受当前安装支持。"""


class UnsafePathError(AsDepthError, ValueError):
    """路径越过声明的 artifact 根目录或不是安全相对路径。"""


class ArtifactExistsError(AsDepthError, FileExistsError):
    """写入会覆盖未明确允许覆盖的现有 artifact。"""
