"""CLI 边界的轻量解析工具。"""

from __future__ import annotations

import argparse


def parse_bool(value: bool | str) -> bool:
    """解析 argparse 常见布尔文本，拒绝含混值。"""

    if isinstance(value, bool):
        return value
    lowered = value.lower()
    if lowered in {"yes", "true", "t", "y", "1"}:
        return True
    if lowered in {"no", "false", "f", "n", "0"}:
        return False
    raise argparse.ArgumentTypeError("Boolean value expected.")
