"""旧 `is_disp` 与 3ch log-depth 的显式兼容边界。"""

from __future__ import annotations

import math
from enum import Enum
from typing import Any

import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError, DepthMap, DepthRepresentation, DepthSpec


class LogDepthDecodeMode(str, Enum):
    C1_METRIC = "c1_metric"
    C2_METRIC = "c2_metric"


_MAX_DEPTH = {
    LogDepthDecodeMode.C1_METRIC: 100.0,
    LogDepthDecodeMode.C2_METRIC: 9.0,
}
_CHANNEL_INDEX = {
    LogDepthDecodeMode.C1_METRIC: 0,
    LogDepthDecodeMode.C2_METRIC: 1,
}


def depth_spec_from_is_disp(is_disp: bool) -> DepthSpec:
    """兼容 CLI 解析后立即消除 boolean 语义。"""

    return DepthSpec.from_is_disp(is_disp)


def legacy_prediction_to_metric(values: NDArray[Any], *, is_disp: bool) -> DepthMap:
    """把旧推理输出解读为显式 metric DepthMap。"""

    depth = DepthMap(np.asarray(values, dtype=np.float32), DepthSpec.from_is_disp(is_disp))
    return depth.to_metric()


def metric_to_legacy_prediction(depth: DepthMap, *, is_disp: bool) -> NDArray[np.float32]:
    """只为旧 `.npy` writer 返回兼容数组副本。"""

    canonical = depth.to_inverse() if is_disp else depth.to_metric()
    return np.array(canonical.values, dtype=np.float32, copy=True)


def decode_log_depth_3ch(
    raw: DepthMap,
    mode: LogDepthDecodeMode | str = LogDepthDecodeMode.C1_METRIC,
) -> DepthMap:
    """复刻旧 C1/C2 `log1p` 解码并单独返回 metric depth。"""

    if raw.spec.representation is not DepthRepresentation.LOG_DEPTH_3CH:
        raise ContractError("3ch decoder requires a log_depth_3ch DepthMap")
    decode_mode = mode if isinstance(mode, LogDepthDecodeMode) else LogDepthDecodeMode(mode)
    channel = np.clip(raw.values[_CHANNEL_INDEX[decode_mode]], 0.0, 1.0)
    metric = np.expm1(channel * np.float32(math.log1p(_MAX_DEPTH[decode_mode]))).astype(np.float32)
    return DepthMap(metric, DepthSpec.metric())
