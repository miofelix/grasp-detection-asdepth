"""历史 Dataset 路径、tuple 与 WDS tensor 的显式适配器。"""

from __future__ import annotations

from collections.abc import Sized
from pathlib import Path
from typing import Any, Literal, cast

import numpy as np
import torch
from numpy.typing import NDArray
from torch.utils.data import Dataset

from asdepth.core import ContractError, DepthMap, DepthRepresentation, RgbdSample
from asdepth.data import load_lab_records

LegacyDatasetKind = Literal["hammer", "clearpose", "dreds", "transcg", "transpose", "kitti"]


def detect_legacy_dataset_kind(jsonl_path: str | Path) -> LegacyDatasetKind:
    """只在兼容 CLI 边界复刻旧 JSONL 路径判别优先级。"""

    value = str(jsonl_path).lower()
    if (
        "kitti_depth_completion" in value
        or "opendatalab___kitti_depth_completion" in value
        or "val_selection_cropped" in value
    ):
        return "kitti"
    if "clearpose" in value:
        return "clearpose"
    if "hammer" in value:
        return "hammer"
    if "transcg" in value:
        return "transcg"
    if "transpose" in value:
        return "transpose"
    if "std_cat" in value or "dreds" in value:
        return "dreds"
    raise ContractError(f"legacy dataset kind cannot be inferred from path: {jsonl_path}")


def sample_to_legacy_tuple(
    sample: RgbdSample,
    *,
    dataset_id: str | None = None,
) -> tuple[str, ...]:
    """把 canonical sample 显式转换为历史 3/4/5 路径 tuple。"""

    kind = dataset_id or str(sample.metadata.get("dataset_id", ""))
    rgb = str(sample.metadata.get("rgb_path", ""))
    raw = str(sample.metadata.get("raw_depth_path", ""))
    target = str(sample.metadata.get("target_depth_path", ""))
    if not kind or not rgb or not raw or not target:
        raise ContractError("RgbdSample lacks legacy path metadata")
    if kind in {"hammer", "clearpose", "dreds"}:
        return rgb, raw, target
    if kind in {"transcg", "transpose"}:
        return rgb, raw, target, sample.sample_id
    if kind == "kitti":
        intrinsics = str(sample.metadata.get("intrinsics_path", ""))
        return rgb, raw, target, sample.sample_id, intrinsics
    raise ContractError(f"unsupported legacy tuple dataset {kind!r}")


class LegacyTupleDatasetAdapter(Dataset[tuple[str, ...]]):
    """为显式兼容调用把 canonical Dataset 映射为路径 tuple。"""

    def __init__(self, dataset: Dataset[RgbdSample], *, dataset_id: str | None = None) -> None:
        self.dataset = dataset
        self.dataset_id = dataset_id

    def __len__(self) -> int:
        return len(cast(Sized, self.dataset))

    def __getitem__(self, index: int) -> tuple[str, ...]:
        return sample_to_legacy_tuple(self.dataset[index], dataset_id=self.dataset_id)


class LegacyLabDatasetAdapter(Dataset[dict[str, Any]]):
    """把 canonical Lab 索引记录适配为实验工具使用的路径字典。"""

    def __init__(self, jsonl_path: str | Path) -> None:
        self.jsonl_path = Path(jsonl_path)
        self.records = load_lab_records(self.jsonl_path)

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        return {
            "sample_id": record.sample_id,
            "rgb": str(record.rgb_path),
            "raw_depth": str(record.raw_depth_path),
            "raw_depth_u16": (
                "" if record.raw_depth_u16_path is None else str(record.raw_depth_u16_path)
            ),
            "meta": "" if record.meta_path is None else str(record.meta_path),
            "depth_scale_meters": record.depth_scale_meters,
            "width": record.width,
            "height": record.height,
            "aligned_to": record.aligned_to,
        }


def _metric_values(depth: DepthMap) -> NDArray[np.float32]:
    if depth.spec.representation is DepthRepresentation.METRIC_DEPTH:
        return depth.values
    if depth.spec.representation is DepthRepresentation.INVERSE_DEPTH:
        return depth.to_metric().values
    raise ContractError("legacy WDS tuples cannot consume log_depth_3ch")


def sample_to_legacy_wds_tuple(
    sample: RgbdSample,
    *,
    is_disp: bool,
) -> tuple[torch.Tensor, torch.Tensor]:
    """把已预处理 WDS sample 显式转换为历史 ``(4CH, 1HW)`` tensor tuple。"""

    if not bool(sample.metadata.get("preprocessed", False)):
        raise ContractError("legacy WDS tuple conversion requires a preprocessed WDS sample")
    if sample.target_depth is None:
        raise ContractError("legacy WDS tuple conversion requires target depth")

    rgb = np.asarray(sample.rgb, dtype=np.float32)
    if rgb.ndim != 3:
        raise ContractError(f"legacy WDS RGB must be CHW or HWC, got {rgb.shape}")
    if rgb.shape[0] in {3, 4}:
        rgb_chw = rgb[:3]
    elif rgb.shape[-1] in {3, 4}:
        rgb_chw = np.moveaxis(rgb[..., :3], -1, 0)
    else:
        raise ContractError(f"legacy WDS RGB must have three channels, got {rgb.shape}")

    raw_metric = _metric_values(sample.raw_depth)
    target_metric = _metric_values(sample.target_depth)
    raw_values = raw_metric
    target_values = target_metric
    if is_disp:
        raw_values = np.zeros_like(raw_metric)
        target_values = np.zeros_like(target_metric)
        np.divide(1.0, raw_metric, out=raw_values, where=raw_metric > 0)
        np.divide(1.0, target_metric, out=target_values, where=target_metric > 0)
        legacy_scale = float(sample.metadata.get("legacy_disparity_scale", 1.0))
        raw_values *= np.float32(legacy_scale)
        target_values *= np.float32(legacy_scale)

    rgb_tensor = torch.from_numpy(np.array(rgb_chw, dtype=np.float32, copy=True, order="C"))
    raw_tensor = torch.from_numpy(
        np.array(raw_values[None], dtype=np.float32, copy=True, order="C")
    )
    target_tensor = torch.from_numpy(
        np.array(target_values[None], dtype=np.float32, copy=True, order="C")
    )
    return torch.cat((rgb_tensor, raw_tensor), dim=0), target_tensor
