"""历史参数与格式的显式兼容边界；不提供旧顶层 import 命名空间。"""

from .data import (
    LegacyLabDatasetAdapter,
    LegacyTupleDatasetAdapter,
    detect_legacy_dataset_kind,
    sample_to_legacy_tuple,
    sample_to_legacy_wds_tuple,
)
from .depth import (
    LogDepthDecodeMode,
    decode_log_depth_3ch,
    depth_spec_from_is_disp,
    legacy_prediction_to_metric,
    metric_to_legacy_prediction,
)

__all__ = [
    "LegacyLabDatasetAdapter",
    "LegacyTupleDatasetAdapter",
    "LogDepthDecodeMode",
    "decode_log_depth_3ch",
    "depth_spec_from_is_disp",
    "detect_legacy_dataset_kind",
    "legacy_prediction_to_metric",
    "metric_to_legacy_prediction",
    "sample_to_legacy_tuple",
    "sample_to_legacy_wds_tuple",
]
