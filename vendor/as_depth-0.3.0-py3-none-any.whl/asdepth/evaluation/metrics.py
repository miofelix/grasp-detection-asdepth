"""与源 `utils.metric` 数值语义一致的设备无关深度指标。"""

from __future__ import annotations

from types import MappingProxyType
from typing import Any

import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError

METRIC_NAMES = (
    "L1",
    "rmse_linear",
    "abs_relative_difference",
    "delta4_acc_105",
    "delta5_acc110",
    "delta1_acc",
)


def compute_depth_metrics(
    prediction: NDArray[Any],
    target: NDArray[Any],
    valid_mask: NDArray[Any] | None = None,
) -> MappingProxyType[str, float]:
    """计算源 eval.py/eval_mp.py 固定的六项逐样本指标。"""

    pred = np.asarray(prediction, dtype=np.float32)
    gt = np.asarray(target, dtype=np.float32)
    if pred.shape != gt.shape or pred.ndim != 2:
        raise ContractError(
            f"evaluation expects matching HxW arrays, got {pred.shape} and {gt.shape}"
        )
    mask = gt > 0 if valid_mask is None else np.asarray(valid_mask, dtype=bool)
    if mask.shape != gt.shape:
        raise ContractError("evaluation valid_mask must match target shape")
    mask = mask & np.isfinite(pred) & np.isfinite(gt) & (gt > 0)
    if not np.any(mask):
        raise ContractError("evaluation sample has no valid finite target pixels")

    selected_pred = pred[mask]
    selected_gt = gt[mask]
    difference = selected_pred - selected_gt
    absolute = np.abs(difference)
    ratio = np.maximum(
        np.divide(selected_pred, selected_gt),
        np.divide(
            selected_gt,
            selected_pred,
            out=np.full_like(selected_gt, np.inf),
            where=selected_pred != 0,
        ),
    )
    values = {
        "L1": float(np.mean(absolute, dtype=np.float32)),
        "rmse_linear": float(np.sqrt(np.mean(np.square(difference), dtype=np.float32))),
        "abs_relative_difference": float(
            np.mean(np.divide(absolute, selected_gt), dtype=np.float32)
        ),
        "delta4_acc_105": float(np.mean(ratio < np.float32(1.05), dtype=np.float32)),
        "delta5_acc110": float(np.mean(ratio < np.float32(1.10), dtype=np.float32)),
        "delta1_acc": float(np.mean(ratio < np.float32(1.25), dtype=np.float32)),
    }
    return MappingProxyType(values)
