"""EvaluationReport、逐样本记录和 canonical metrics writer。"""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from types import MappingProxyType
from typing import Any, ClassVar, cast

from asdepth.artifacts import atomic_write_json, atomic_write_text, utc_now
from asdepth.core import ContractError
from asdepth.core.serialization import (
    frozen_mapping,
    require_exact_keys,
    require_schema_version,
    to_primitive,
)

from .metrics import METRIC_NAMES


def _metrics(
    value: dict[str, float] | MappingProxyType[str, float],
) -> MappingProxyType[str, float]:
    result = MappingProxyType({str(name): float(item) for name, item in value.items()})
    if set(result) != set(METRIC_NAMES):
        raise ContractError(
            f"evaluation metrics must be exactly {list(METRIC_NAMES)}, got {sorted(result)}"
        )
    return result


@dataclass(frozen=True, slots=True)
class SampleEvaluation:
    sample_id: str
    metrics: MappingProxyType[str, float]
    valid_pixels: int
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.sample_id or self.valid_pixels <= 0:
            raise ContractError("sample evaluation requires sample_id and positive valid_pixels")
        object.__setattr__(self, "metrics", _metrics(self.metrics))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> SampleEvaluation:
        require_exact_keys(
            payload,
            required={"sample_id", "metrics", "valid_pixels", "metadata"},
            context="SampleEvaluation",
        )
        values = dict(payload)
        values["metrics"] = MappingProxyType(dict(payload["metrics"]))
        values["metadata"] = frozen_mapping(dict(payload["metadata"]))
        return cls(**values)


@dataclass(frozen=True, slots=True)
class EvaluationReport:
    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    evaluation_id: str
    created_at: str
    dataset_id: str
    prediction_artifact_id: str | None
    samples: tuple[SampleEvaluation, ...]
    summary: MappingProxyType[str, float]
    aligned: bool = False
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"EvaluationReport requires schema {self.SCHEMA_VERSION}")
        if not self.evaluation_id or not self.dataset_id:
            raise ContractError("evaluation_id and dataset_id are required")
        samples = tuple(self.samples)
        if not samples:
            raise ContractError("EvaluationReport requires at least one sample")
        if len({sample.sample_id for sample in samples}) != len(samples):
            raise ContractError("EvaluationReport sample IDs must be unique")
        object.__setattr__(self, "samples", samples)
        object.__setattr__(self, "summary", _metrics(self.summary))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    @property
    def sample_count(self) -> int:
        return len(self.samples)

    def to_dict(self) -> dict[str, Any]:
        payload = cast(dict[str, Any], to_primitive(self))
        payload["sample_count"] = self.sample_count
        return payload

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> EvaluationReport:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "evaluation_id",
                "created_at",
                "dataset_id",
                "prediction_artifact_id",
                "samples",
                "sample_count",
                "summary",
                "aligned",
                "metadata",
            },
            context="EvaluationReport",
        )
        require_schema_version(payload, context="EvaluationReport")
        values = dict(payload)
        declared_count = int(values.pop("sample_count"))
        values["samples"] = tuple(SampleEvaluation.from_dict(item) for item in payload["samples"])
        if declared_count != len(values["samples"]):
            raise ContractError("EvaluationReport sample_count does not match samples")
        values["summary"] = MappingProxyType(dict(payload["summary"]))
        values["metadata"] = frozen_mapping(dict(payload["metadata"]))
        return cls(**values)


def write_evaluation_report(
    output_root: str | Path,
    report: EvaluationReport,
    *,
    overwrite: bool = False,
) -> Path:
    metrics_root = Path(output_root).expanduser().resolve() / "metrics"
    metrics_root.mkdir(parents=True, exist_ok=True)
    samples = "".join(
        json.dumps(sample.to_dict(), ensure_ascii=False, sort_keys=True) + "\n"
        for sample in report.samples
    )
    atomic_write_text(metrics_root / "samples.jsonl", samples, overwrite=overwrite)
    return atomic_write_json(
        metrics_root / "evaluation.json",
        report.to_dict(),
        overwrite=overwrite,
    )


def new_report_timestamp() -> str:
    return utc_now()


def write_legacy_evaluation_files(
    output_root: str | Path,
    report: EvaluationReport,
    *,
    decode_mode: str | None = None,
    overwrite: bool = False,
) -> tuple[Path, Path]:
    """写旧 CSV/JSON 文件名和字段，供现有汇总 wrapper 继续读取。"""

    root = Path(output_root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    suffix = f"False{f'_{decode_mode}' if decode_mode else ''}"
    csv_path = root / f"all_metrics_{timestamp}_{suffix}.csv"
    summary_path = root / f"mean_metrics_{timestamp}_{suffix}.json"

    fieldnames = ["name"]
    if decode_mode is not None:
        fieldnames.append("decode_mode")
    fieldnames.extend(METRIC_NAMES)
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    for sample in report.samples:
        row: dict[str, Any] = {"name": sample.sample_id, **dict(sample.metrics)}
        if decode_mode is not None:
            row["decode_mode"] = decode_mode
        writer.writerow(row)
    atomic_write_text(csv_path, stream.getvalue(), overwrite=overwrite)

    summary: dict[str, Any] = dict(report.summary)
    if decode_mode is not None:
        summary["decode_mode"] = decode_mode
    atomic_write_text(
        summary_path,
        json.dumps(summary, ensure_ascii=False, separators=(",", ":")) + "\n",
        overwrite=overwrite,
    )
    return csv_path, summary_path
