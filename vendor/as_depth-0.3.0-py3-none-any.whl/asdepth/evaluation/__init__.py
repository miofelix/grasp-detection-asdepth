"""预测读取、指标计算与 EvaluationReport。"""

from .metrics import METRIC_NAMES, compute_depth_metrics
from .report import (
    EvaluationReport,
    SampleEvaluation,
    write_evaluation_report,
    write_legacy_evaluation_files,
)
from .service import align_prediction_shape, evaluate

__all__ = [
    "METRIC_NAMES",
    "EvaluationReport",
    "SampleEvaluation",
    "align_prediction_shape",
    "compute_depth_metrics",
    "evaluate",
    "write_evaluation_report",
    "write_legacy_evaluation_files",
]
