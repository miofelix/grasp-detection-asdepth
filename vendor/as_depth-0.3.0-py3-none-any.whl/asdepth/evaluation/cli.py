"""脚本说明：
作用：读取 PredictionArtifact 并输出 canonical EvaluationReport。

典型用法：
    asdepth evaluate --dataset data/HAMMER/test.jsonl --dataset-id hammer \
        --predictions runs/demo

参数说明：
    - --predictions：包含 predictions/manifest.json 的 run 根目录或 predictions 目录。
    - --align：启用源 evaluator 的逐样本 scale/shift 对齐；默认关闭。

环境变量/外部依赖：
    - 纯 NumPy/OpenCV 指标链路，不要求 CUDA。

运行注意：
    - 非 DREDS 的 prediction/GT shape 不一致会显式报错。
    - canonical 指标名称和源 eval.py/eval_mp.py 保持一致。
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable, Sequence
from typing import cast

from asdepth.core import RgbdSample
from asdepth.data import create_dataset

from .report import EvaluationReport
from .service import evaluate


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth evaluate",
        description="评估 PredictionArtifact 并写逐样本和 summary 指标",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--dataset", required=True)
    parser.add_argument(
        "--dataset-id",
        required=True,
        choices=["hammer", "clearpose", "dreds", "transcg", "transpose", "kitti"],
    )
    parser.add_argument("--predictions", "--output", dest="predictions", required=True)
    parser.add_argument("--report-output", dest="report_output")
    parser.add_argument("--raw-type", default="d435")
    parser.add_argument("--align", action="store_true")
    parser.add_argument("--decode-mode", choices=["c1_metric", "c2_metric"])
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--no-verify-checksums", action="store_true")
    return parser


def _run(args: argparse.Namespace) -> EvaluationReport:
    dataset = create_dataset(
        args.dataset,
        dataset_id=args.dataset_id,
        raw_type=args.raw_type,
    )
    report = evaluate(
        cast(Iterable[RgbdSample], dataset),
        args.predictions,
        output=args.report_output or args.predictions,
        dataset_id=args.dataset_id,
        align=args.align,
        overwrite=args.overwrite,
        verify_checksums=not args.no_verify_checksums,
        decode_mode=args.decode_mode,
    )
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    report = _run(args)
    print(json.dumps(dict(report.summary), ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
