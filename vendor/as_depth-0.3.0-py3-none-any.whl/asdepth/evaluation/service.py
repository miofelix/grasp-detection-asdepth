"""PredictionArtifact 到逐样本/summary EvaluationReport 的 evaluate() 服务。"""

from __future__ import annotations

import uuid
from collections.abc import Iterable
from pathlib import Path
from types import MappingProxyType
from typing import cast

import cv2
import numpy as np
from numpy.typing import NDArray

from asdepth.compat import LogDepthDecodeMode
from asdepth.core import ContractError, RgbdSample
from asdepth.core.serialization import frozen_mapping
from asdepth.inference import PredictionReader

from .metrics import METRIC_NAMES, compute_depth_metrics
from .report import (
    EvaluationReport,
    SampleEvaluation,
    new_report_timestamp,
    write_evaluation_report,
)


def align_prediction_shape(
    prediction: NDArray[np.float32],
    target_shape: tuple[int, int],
    *,
    dataset_id: str,
    sample_id: str,
) -> NDArray[np.float32]:
    """仅 DREDS 允许源 eval_mp.py 的 nearest shape 对齐。"""

    if prediction.shape == target_shape:
        return prediction
    if dataset_id != "dreds":
        raise ContractError(
            f"prediction/GT shape mismatch for {sample_id}: dataset_id={dataset_id}, "
            f"prediction={prediction.shape}, target={target_shape}"
        )
    if prediction.ndim != 2 or len(target_shape) != 2:
        raise ContractError(
            f"DREDS evaluation expects 2D depth maps for {sample_id}: {prediction.shape}"
        )
    height, width = target_shape
    return cast(
        NDArray[np.float32],
        cv2.resize(
            prediction.astype(np.float32, copy=False),
            (width, height),
            interpolation=cv2.INTER_NEAREST,
        ),
    )


def _scale_shift_align(
    prediction: NDArray[np.float32],
    target: NDArray[np.float32],
    mask: NDArray[np.bool_],
    *,
    min_depth: float,
) -> NDArray[np.float32]:
    selected_prediction = prediction[mask].reshape((-1, 1))
    selected_target = target[mask].reshape((-1, 1))
    matrix = np.concatenate((selected_prediction, np.ones_like(selected_prediction)), axis=-1)
    scale, shift = np.linalg.lstsq(matrix, selected_target, rcond=None)[0]
    aligned = scale * prediction + shift
    return np.asarray(np.clip(aligned, a_min=min_depth, a_max=None), dtype=np.float32)


def evaluate(
    dataset: Iterable[RgbdSample],
    predictions: str | Path | PredictionReader,
    *,
    output: str | Path | None = None,
    dataset_id: str | None = None,
    align: bool = False,
    overwrite: bool = False,
    verify_checksums: bool = True,
    decode_mode: LogDepthDecodeMode | str | None = None,
) -> EvaluationReport:
    """读取预测文件边界并计算与源 evaluator 同名的六项指标。"""

    reader = (
        predictions
        if isinstance(predictions, PredictionReader)
        else PredictionReader(predictions, verify_checksums=verify_checksums)
    )
    sample_results: list[SampleEvaluation] = []
    resolved_dataset_id = dataset_id
    for sample in dataset:
        current_dataset_id = str(sample.metadata.get("dataset_id", ""))
        if resolved_dataset_id is None:
            resolved_dataset_id = current_dataset_id
        if not resolved_dataset_id or current_dataset_id != resolved_dataset_id:
            raise ContractError("evaluation dataset must have one explicit dataset_id")
        if sample.target_depth is None:
            raise ContractError(f"sample {sample.sample_id!r} has no target depth")

        loaded = reader.load(sample.sample_id, decode_mode=decode_mode)
        prediction = align_prediction_shape(
            np.asarray(loaded.depth.values, dtype=np.float32),
            cast_shape(sample.target_depth.shape),
            dataset_id=resolved_dataset_id,
            sample_id=sample.sample_id,
        )
        target = np.asarray(sample.target_depth.to_metric().values, dtype=np.float32)
        finite = align_prediction_shape(
            np.asarray(loaded.finite_mask, dtype=np.float32),
            cast_shape(sample.target_depth.shape),
            dataset_id=resolved_dataset_id,
            sample_id=sample.sample_id,
        ).astype(bool)
        mask = sample.target_depth.to_metric().valid_mask & finite
        if align:
            minimum = sample.target_depth.spec.min_valid or float(np.min(target[mask]))
            prediction = _scale_shift_align(prediction, target, mask, min_depth=minimum)
        metrics = compute_depth_metrics(prediction, target, mask)
        sample_results.append(
            SampleEvaluation(
                sample_id=sample.sample_id,
                metrics=metrics,
                valid_pixels=int(mask.sum()),
                metadata=frozen_mapping({"prediction_path": str(loaded.path)}),
            )
        )
    if resolved_dataset_id is None:
        raise ContractError("cannot evaluate an empty dataset")

    summary = MappingProxyType(
        {
            name: float(
                np.mean([sample.metrics[name] for sample in sample_results], dtype=np.float64)
            )
            for name in METRIC_NAMES
        }
    )
    report = EvaluationReport(
        evaluation_id=f"evaluation-{uuid.uuid4().hex}",
        created_at=new_report_timestamp(),
        dataset_id=resolved_dataset_id,
        prediction_artifact_id=(
            reader.artifact.artifact_id if reader.artifact is not None else None
        ),
        samples=tuple(sample_results),
        summary=summary,
        aligned=align,
        metadata=frozen_mapping(
            {
                "prediction_layout": reader.layout,
                "decode_mode": (
                    decode_mode.value
                    if isinstance(decode_mode, LogDepthDecodeMode)
                    else decode_mode
                ),
            }
        ),
    )
    if output is not None:
        write_evaluation_report(output, report, overwrite=overwrite)
    return report


def cast_shape(value: tuple[int, ...]) -> tuple[int, int]:
    if len(value) != 2:
        raise ContractError(f"evaluation target depth must be HxW, got {value}")
    return int(value[0]), int(value[1])
