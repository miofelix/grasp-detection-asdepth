"""轻量 Native viewer 与 Web packet publisher。"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

import cv2
import numpy as np

from .packets import PredictionPacket


class NativeViewer:
    """最小 OpenCV viewer；大型点云/UI 实现仍留在应用/legacy 边界。"""

    def __init__(self, *, window_name: str = "AS-Depth Realtime") -> None:
        self.window_name = window_name
        self.quit_requested = False

    def publish(self, packet: PredictionPacket) -> None:
        depth = packet.depth_m
        valid = depth > 0
        display = np.zeros_like(depth, dtype=np.uint8)
        if np.any(valid):
            minimum = float(np.percentile(depth[valid], 2))
            maximum = float(np.percentile(depth[valid], 98))
            if maximum <= minimum:
                maximum = minimum + 1e-6
            scaled = (depth - minimum) * (255.0 / (maximum - minimum))
            np.clip(scaled, 0, 255, out=scaled)
            display = scaled.astype(np.uint8)
            display[~valid] = 0
        colored = cv2.applyColorMap(display, cv2.COLORMAP_TURBO)
        frame = np.concatenate((packet.frame.color_bgr, colored), axis=1)
        cv2.imshow(self.window_name, frame)
        self.quit_requested = (cv2.waitKey(1) & 0xFF) == ord("q")

    def close(self) -> None:
        cv2.destroyWindow(self.window_name)


@dataclass(frozen=True, slots=True)
class WebFrame:
    header: MappingProxyType[str, Any]
    payload: bytes


class WebPublisher:
    """单帧 ACK 流控由 app transport 实现；publisher 固化 frame wire contract。"""

    PROTOCOL = "asdepth.realtime.webgl.v2"
    FLOW_CONTROL = "frame_ack"

    def __init__(
        self,
        sink: Callable[[WebFrame], Any],
        *,
        max_depth_m: float = 10.0,
    ) -> None:
        if max_depth_m <= 0.0:
            raise ValueError("max_depth_m must be positive")
        self.sink = sink
        self.max_depth_m = float(max_depth_m)

    @staticmethod
    def _effective_stride(
        shape: tuple[int, int],
        requested: int,
        point_budget: int,
    ) -> int:
        stride = max(1, int(requested))
        if point_budget <= 0:
            return stride
        height, width = shape
        while ((height + stride - 1) // stride) * ((width + stride - 1) // stride) > point_budget:
            stride += 1
        return stride

    def build_frame(
        self,
        packet: PredictionPacket,
        *,
        include_color: bool = True,
        include_raw: bool = True,
        include_pred: bool = True,
        include_raw_cloud: bool = False,
        include_pred_cloud: bool = False,
        cloud_stride: int = 2,
        cloud_point_budget: int = 180_000,
        header_fields: dict[str, Any] | None = None,
    ) -> WebFrame:
        color = np.ascontiguousarray(packet.frame.color_bgr, dtype=np.uint8)
        raw = np.ascontiguousarray(packet.frame.raw_depth_mm, dtype=np.uint16)
        metric = np.nan_to_num(
            packet.depth_m,
            copy=True,
            nan=0.0,
            posinf=0.0,
            neginf=0.0,
        )
        prediction = np.rint(metric * np.float32(1000.0))
        invalid = (
            (metric <= 0.0) | (metric > self.max_depth_m) | (prediction > np.iinfo(np.uint16).max)
        )
        prediction[invalid] = 0
        pred_u16 = np.ascontiguousarray(prediction, dtype=np.uint16)
        segments: list[tuple[str, np.ndarray, dict[str, Any]]] = []
        streams = {
            "color": bool(include_color),
            "raw_depth": bool(include_raw),
            "pred_depth": bool(include_pred),
            "raw_cloud_depth": bool(include_raw_cloud),
            "pred_cloud_depth": bool(include_pred_cloud),
        }
        if include_color:
            segments.append(
                (
                    "color",
                    color,
                    {"shape": list(color.shape), "dtype": "uint8", "layout": "BGR"},
                )
            )
        if include_raw:
            segments.append(
                (
                    "raw_depth",
                    raw,
                    {"shape": list(raw.shape), "dtype": "uint16", "unit": "millimeter"},
                )
            )
        if include_pred:
            segments.append(
                (
                    "pred_depth",
                    pred_u16,
                    {
                        "shape": list(pred_u16.shape),
                        "dtype": "uint16",
                        "unit": "millimeter",
                        "source_dtype": "float32_meter",
                        "max_depth_m": self.max_depth_m,
                    },
                )
            )
        if include_raw_cloud:
            stride = self._effective_stride(raw.shape, cloud_stride, cloud_point_budget)
            cloud = np.ascontiguousarray(raw[::stride, ::stride])
            segments.append(
                (
                    "raw_cloud_depth",
                    cloud,
                    {
                        "shape": list(cloud.shape),
                        "dtype": "uint16",
                        "unit": "millimeter",
                        "source": "raw_depth",
                        "requested_stride": max(1, int(cloud_stride)),
                        "stride": stride,
                        "point_budget": max(0, int(cloud_point_budget)),
                    },
                )
            )
        if include_pred_cloud:
            stride = self._effective_stride(pred_u16.shape, cloud_stride, cloud_point_budget)
            cloud = np.ascontiguousarray(pred_u16[::stride, ::stride])
            segments.append(
                (
                    "pred_cloud_depth",
                    cloud,
                    {
                        "shape": list(cloud.shape),
                        "dtype": "uint16",
                        "unit": "millimeter",
                        "source": "pred_depth",
                        "source_dtype": "float32_meter",
                        "requested_stride": max(1, int(cloud_stride)),
                        "stride": stride,
                        "point_budget": max(0, int(cloud_point_budget)),
                    },
                )
            )
        payload = bytearray(sum(value.nbytes for _, value, _ in segments))
        view = memoryview(payload)
        offset = 0
        layout: dict[str, Any] = {}
        for name, value, metadata in segments:
            length = value.nbytes
            view[offset : offset + length] = value.tobytes()
            layout[name] = {**metadata, "offset": offset, "bytes": length}
            offset += length
        header = MappingProxyType(
            {
                "type": "frame",
                "protocol": self.PROTOCOL,
                "flow_control": self.FLOW_CONTROL,
                "frame_id": packet.frame.frame_id,
                "timestamp_ns": packet.frame.timestamp_ns,
                "streams": streams,
                "cloud_stride": max(1, int(cloud_stride)),
                "cloud_point_budget": max(0, int(cloud_point_budget)),
                **dict(header_fields or {}),
                **layout,
                "payload_bytes": len(payload),
            }
        )
        return WebFrame(header=header, payload=bytes(payload))

    def publish(self, packet: PredictionPacket) -> None:
        self.sink(self.build_frame(packet))

    def close(self) -> None:
        return None
