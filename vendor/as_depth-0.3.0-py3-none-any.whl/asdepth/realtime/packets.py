"""Realtime 相机帧、预测帧和可选消费者协议。"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Protocol

import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError
from asdepth.core.serialization import frozen_mapping


@dataclass(frozen=True, slots=True)
class FramePacket:
    """相机源输出：BGR uint8 与对齐的 uint16 毫米 raw depth。"""

    frame_id: int
    timestamp_ns: int
    color_bgr: NDArray[np.uint8]
    raw_depth_mm: NDArray[np.uint16]
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if self.frame_id < 0 or self.timestamp_ns < 0:
            raise ContractError("realtime frame id and timestamp cannot be negative")
        color = np.array(self.color_bgr, dtype=np.uint8, copy=True, order="C")
        raw = np.array(self.raw_depth_mm, dtype=np.uint16, copy=True, order="C")
        if color.ndim != 3 or color.shape[2] != 3:
            raise ContractError(f"color_bgr must be HxWx3, got {color.shape}")
        if raw.ndim != 2 or raw.shape != color.shape[:2]:
            raise ContractError(
                f"raw_depth_mm must align with color: color={color.shape}, depth={raw.shape}"
            )
        color.setflags(write=False)
        raw.setflags(write=False)
        object.__setattr__(self, "color_bgr", color)
        object.__setattr__(self, "raw_depth_mm", raw)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))


@dataclass(frozen=True, slots=True)
class PredictionPacket:
    """RealtimePipeline 的 metric meter 预测及可审计计时。"""

    frame: FramePacket
    depth_m: NDArray[np.float32]
    timings_ms: MappingProxyType[str, float] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        depth = np.array(self.depth_m, dtype=np.float32, copy=True, order="C")
        if depth.ndim != 2:
            raise ContractError(f"realtime metric depth must be HxW, got {depth.shape}")
        depth[~np.isfinite(depth)] = 0.0
        depth[depth < 0.0] = 0.0
        depth.setflags(write=False)
        object.__setattr__(self, "depth_m", depth)
        timings = {str(name): float(value) for name, value in self.timings_ms.items()}
        if any(value < 0 for value in timings.values()):
            raise ContractError("realtime timings cannot be negative")
        object.__setattr__(self, "timings_ms", MappingProxyType(timings))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))


class CameraSource(Protocol):
    def start(self) -> None: ...

    def read(self) -> FramePacket | None: ...

    def close(self) -> None: ...


class PredictionConsumer(Protocol):
    def publish(self, packet: PredictionPacket) -> None: ...

    def close(self) -> None: ...


class RealtimePreprocessor(Protocol):
    def prepare(self, frame: FramePacket) -> Any: ...


class RealtimePostprocessor(Protocol):
    def process(self, values: Any, frame: FramePacket) -> NDArray[np.float32]: ...
