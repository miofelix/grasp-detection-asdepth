"""D435/HAMMER 的 canonical host-preprocess TensorRT adapter。"""

from __future__ import annotations

from pathlib import Path
from types import MappingProxyType
from typing import Any

import numpy as np

from asdepth.core import ContractError, DepthSpec, ModelSpec, TensorSpec
from asdepth.deployment import INPUT_NAME, OUTPUT_NAME, Resolution
from asdepth.runtime import RuntimeBackend, TensorRTBackend

from .packets import FramePacket
from .pipeline import MetricDepthPostprocessor
from .preprocess import D435HostPreprocessor


def d435_runtime_model_spec(
    resolution: Resolution | None = None,
    *,
    model_id: str = "defm_stackconv_depth",
    model_version: str = "source-00ec5dc",
    config_hash: str = "0" * 64,
) -> ModelSpec:
    """为已构建 engine 声明显式单输入 metric-depth runtime 契约。"""

    input_shape: tuple[int | str, ...]
    output_shape: tuple[int | str, ...]
    if resolution is None:
        input_shape = (1, 4, "H", "W")
        output_shape = (1, "H", "W")
        resolution_label = "engine"
    else:
        input_shape = resolution.input_shape
        output_shape = resolution.output_shape
        resolution_label = resolution.label
    return ModelSpec(
        model_id=model_id,
        model_version=model_version,
        config_hash=config_hash,
        entrypoint="asdepth.runtime:TensorRTBackend",
        inputs=(
            TensorSpec(
                INPUT_NAME,
                "float32",
                input_shape,
                layout="NCHW",
                semantic="normalized_rgb_plus_metric_depth",
            ),
        ),
        outputs=(
            TensorSpec(
                OUTPUT_NAME,
                "float32",
                output_shape,
                layout="NHW",
                semantic="metric_depth_meter",
            ),
        ),
        depth=DepthSpec.metric(),
        metadata=MappingProxyType({"resolution": resolution_label}),
    )


class D435TensorRTAdapter:
    """组合 D435 host preprocess、统一 runtime 和 metric postprocess。"""

    def __init__(
        self,
        engine_path: str | Path,
        *,
        resolution: Resolution | None = None,
        depth_scale: float = 1000.0,
        max_depth_m: float = 10.0,
        device: str = "cuda",
        model_spec: ModelSpec | None = None,
        runtime: RuntimeBackend | None = None,
    ) -> None:
        if not str(device).startswith("cuda"):
            raise ContractError(f"D435 TensorRT adapter requires CUDA, got {device!r}")
        self.model_spec = model_spec or d435_runtime_model_spec(resolution)
        self.runtime = runtime or TensorRTBackend(
            engine_path,
            self.model_spec,
            device=device,
        )
        if self.runtime.model_spec.depth.representation.value != "metric_depth":
            raise ContractError("D435 TensorRT adapter requires metric-depth runtime output")
        runtime_shape = getattr(self.runtime, "input_shape", None)
        if resolution is None:
            if runtime_shape is None:
                raise ContractError(
                    "D435 TensorRT adapter requires resolution when runtime input_shape is unavailable"
                )
            shape = tuple(int(item) for item in runtime_shape)
            if len(shape) != 4 or shape[1] != 4:
                raise ContractError(f"invalid D435 TensorRT input shape: {shape}")
            resolution = Resolution(shape[2], shape[3])
        elif runtime_shape is not None:
            shape = tuple(int(item) for item in runtime_shape)
            if shape[2:] != (resolution.height, resolution.width):
                raise ContractError(
                    "D435 TensorRT adapter resolution does not match runtime input: "
                    f"resolution={resolution.input_shape}, runtime={shape}"
                )
        expected_input = self.model_spec.inputs[0]
        if not (
            len(expected_input.shape) == 4
            and expected_input.shape[1] == 4
            and expected_input.shape[2] in {resolution.height, "H", None}
            and expected_input.shape[3] in {resolution.width, "W", None}
        ):
            raise ContractError(
                "D435 TensorRT adapter resolution does not match ModelSpec input: "
                f"resolution={resolution.input_shape}, spec={expected_input.shape}"
            )
        self.resolution = resolution
        self.preprocessor = D435HostPreprocessor(
            resolution,
            depth_scale=depth_scale,
            max_depth_m=max_depth_m,
        )
        self.postprocessor = MetricDepthPostprocessor(restore_camera_shape=False)

    @property
    def target_size(self) -> tuple[int, int]:
        return self.resolution.height, self.resolution.width

    def infer(self, color_bgr: np.ndarray, raw_depth: np.ndarray) -> np.ndarray:
        frame = FramePacket(
            frame_id=0,
            timestamp_ns=0,
            color_bgr=color_bgr,
            raw_depth_mm=raw_depth,
        )
        inputs = self.preprocessor.prepare(frame)
        output = self.runtime.infer(inputs)
        return self.postprocessor.process(output.values, frame)

    def infer_d435_host_pred_only(
        self,
        color_bgr: np.ndarray,
        raw_depth: np.ndarray,
        *,
        depth_scale: float | None = None,
        max_depth: float | None = None,
    ) -> np.ndarray:
        """兼容旧部署脚本命名；显式覆盖值必须与构造配置一致。"""

        if depth_scale is not None and depth_scale != self.preprocessor.depth_scale:
            raise ContractError("per-call depth_scale cannot differ from adapter configuration")
        if max_depth is not None and max_depth != self.preprocessor.max_depth_m:
            raise ContractError("per-call max_depth cannot differ from adapter configuration")
        return self.infer(color_bgr, raw_depth)

    def close(self) -> None:
        close_runtime = getattr(self.runtime, "close", None)
        if callable(close_runtime):
            close_runtime()

    def __enter__(self) -> D435TensorRTAdapter:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()
