"""D435 host preprocess：BGR/raw millimeter → 单输入 rgbd_input。"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from asdepth.core import ContractError
from asdepth.deployment import Resolution

from .packets import FramePacket

IMAGENET_MEAN = np.asarray((0.485, 0.456, 0.406), dtype=np.float32)
IMAGENET_STD = np.asarray((0.229, 0.224, 0.225), dtype=np.float32)


@dataclass(frozen=True, slots=True)
class D435HostPreprocessor:
    """保持源 realtime 主线的 host resize/normalize/concat 行为。"""

    resolution: Resolution
    depth_scale: float = 1000.0
    max_depth_m: float = 10.0

    def __post_init__(self) -> None:
        if self.depth_scale <= 0 or self.max_depth_m <= 0:
            raise ContractError("depth_scale and max_depth_m must be positive")

    def raw_depth_m(self, frame: FramePacket) -> np.ndarray:
        values: np.ndarray = frame.raw_depth_mm.astype(np.float32) / np.float32(self.depth_scale)
        invalid = (frame.raw_depth_mm == 0) | (values >= self.max_depth_m)
        np.clip(values, 0.0, self.max_depth_m, out=values)
        values[invalid] = 0.0
        return values

    def prepare(self, frame: FramePacket) -> np.ndarray:
        rgb: np.ndarray = cv2.cvtColor(frame.color_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)
        rgb *= np.float32(1.0 / 255.0)
        rgb = np.asarray(
            cv2.resize(
                rgb,
                (self.resolution.width, self.resolution.height),
                interpolation=cv2.INTER_CUBIC,
            ),
            dtype=np.float32,
        )
        rgb = (rgb - IMAGENET_MEAN) / IMAGENET_STD
        rgb_chw = np.ascontiguousarray(rgb.transpose(2, 0, 1), dtype=np.float32)
        raw = np.asarray(
            cv2.resize(
                self.raw_depth_m(frame),
                (self.resolution.width, self.resolution.height),
                interpolation=cv2.INTER_NEAREST,
            ),
            dtype=np.float32,
        )
        return np.asarray(
            np.concatenate(
                (rgb_chw, np.ascontiguousarray(raw[None], dtype=np.float32)),
                axis=0,
            )[None],
            dtype=np.float32,
        )
