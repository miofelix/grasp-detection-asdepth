"""Mock 与 RealSense D435 camera source。"""

from __future__ import annotations

import logging
import time
from collections.abc import Iterable
from contextlib import suppress
from types import MappingProxyType
from typing import Any

import numpy as np

from asdepth.core import ContractError

from .packets import FramePacket

logger = logging.getLogger(__name__)


class MockCameraSource:
    """纯内存 camera source，用于本地闭环、CI 和应用 dry-run。"""

    def __init__(self, frames: Iterable[FramePacket]) -> None:
        self._frames = iter(frames)
        self._started = False
        self._closed = False

    def start(self) -> None:
        if self._closed:
            raise RuntimeError("mock camera is closed")
        self._started = True

    def read(self) -> FramePacket | None:
        if not self._started or self._closed:
            raise RuntimeError("mock camera must be started before read")
        return next(self._frames, None)

    def close(self) -> None:
        self._closed = True

    def __enter__(self) -> MockCameraSource:
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


class RealSenseD435Source:
    """D435 color/depth 对齐源；pyrealsense2 仅在 ``start`` 时导入。"""

    def __init__(
        self,
        *,
        width: int = 640,
        height: int = 480,
        fps: int = 30,
        serial: str | None = None,
        timeout_ms: int = 5000,
        reset_on_close: bool = False,
        reset_wait_sec: float = 0.0,
    ) -> None:
        if width <= 0 or height <= 0 or fps <= 0 or timeout_ms <= 0:
            raise ContractError("D435 width, height, fps and timeout must be positive")
        if reset_wait_sec < 0.0:
            raise ContractError("D435 reset wait must be non-negative")
        self.width = width
        self.height = height
        self.fps = fps
        self.serial = serial
        self.timeout_ms = timeout_ms
        self.reset_on_close = reset_on_close
        self.reset_wait_sec = float(reset_wait_sec)
        self._pipeline: Any | None = None
        self._align: Any | None = None
        self._device: Any | None = None
        self._intrinsics: MappingProxyType[str, float] | None = None
        self._active_serial: str | None = None
        self._frame_id = 0

    def start(self) -> None:
        if self._pipeline is not None:
            return
        try:
            import pyrealsense2 as rs
        except ImportError as exc:
            raise RuntimeError(
                "RealSenseD435Source requires librealsense and the 'realsense' extra"
            ) from exc
        pipeline = rs.pipeline()
        config = rs.config()
        if self.serial:
            config.enable_device(self.serial)
        config.enable_stream(rs.stream.color, self.width, self.height, rs.format.bgr8, self.fps)
        config.enable_stream(rs.stream.depth, self.width, self.height, rs.format.z16, self.fps)
        try:
            profile = pipeline.start(config)
        except Exception:
            # librealsense can allocate native USB resources before start()
            # reports a UVC error. Release that partial pipeline so a Web
            # reconnect does not inherit a busy device handle.
            with suppress(Exception):
                pipeline.stop()
            raise
        device = profile.get_device()
        color_profile = profile.get_stream(rs.stream.color).as_video_stream_profile()
        intrinsics = color_profile.get_intrinsics()
        self._pipeline = pipeline
        self._align = rs.align(rs.stream.color)
        self._device = device
        self._intrinsics = MappingProxyType(
            {
                "width": float(intrinsics.width),
                "height": float(intrinsics.height),
                "fx": float(intrinsics.fx),
                "fy": float(intrinsics.fy),
                "ppx": float(intrinsics.ppx),
                "ppy": float(intrinsics.ppy),
            }
        )
        try:
            self._active_serial = str(device.get_info(rs.camera_info.serial_number))
        except Exception:
            self._active_serial = self.serial

    def read(self) -> FramePacket | None:
        if self._pipeline is None or self._align is None:
            raise RuntimeError("RealSense camera must be started before read")
        frames = self._pipeline.wait_for_frames(self.timeout_ms)
        aligned = self._align.process(frames)
        color_frame = aligned.get_color_frame()
        depth_frame = aligned.get_depth_frame()
        if not color_frame or not depth_frame:
            return None
        color = np.ascontiguousarray(np.asanyarray(color_frame.get_data()), dtype=np.uint8)
        depth = np.ascontiguousarray(np.asanyarray(depth_frame.get_data()), dtype=np.uint16)
        timestamp_ns = time.time_ns()
        packet = FramePacket(
            frame_id=self._frame_id,
            timestamp_ns=timestamp_ns,
            color_bgr=color,
            raw_depth_mm=depth,
            metadata=MappingProxyType(
                {
                    "camera": "realsense_d435",
                    "serial": self._active_serial,
                    "device_timestamp_ms": float(frames.get_timestamp()),
                    "intrinsics": dict(self._intrinsics or {}),
                }
            ),
        )
        self._frame_id += 1
        return packet

    def close(self) -> None:
        if self._pipeline is not None:
            pipeline = self._pipeline
            device = self._device
            self._pipeline = None
            self._align = None
            self._device = None
            self._intrinsics = None
            self._active_serial = None
            pipeline.stop()
            if self.reset_on_close and device is not None:
                try:
                    device.hardware_reset()
                    if self.reset_wait_sec > 0.0:
                        time.sleep(self.reset_wait_sec)
                except Exception as exc:
                    logger.warning("RealSense hardware reset failed during close: %s", exc)

    def __enter__(self) -> RealSenseD435Source:
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
