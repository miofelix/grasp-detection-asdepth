"""D435 realtime FastAPI/WebGL 服务。

本模块把 HTTP/WebSocket/control 装配建立在 canonical packet/runtime/recorder API
之上。FastAPI、Uvicorn 与 RealSense 都保持在实际启动 Web 服务时加载。
"""

from __future__ import annotations

import asyncio
import logging
import socket
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from importlib.resources import files
from types import MappingProxyType
from typing import Any, cast

import numpy as np

from asdepth.core import ModelSpec
from asdepth.deployment import Resolution
from asdepth.runtime import RuntimeBackend

from .camera import RealSenseD435Source
from .packets import CameraSource, PredictionPacket
from .pipeline import RealtimePipeline
from .preprocess import D435HostPreprocessor
from .publishers import WebPublisher
from .recorder import Recorder

logger = logging.getLogger(__name__)

REALTIME_PROTOCOL = "asdepth.realtime.webgl.v2"
REALTIME_FLOW_CONTROL = "frame_ack"
POINT_DTYPE = np.dtype([("xyz", "<f4", (3,)), ("rgba", "u1", (4,))])


@dataclass(frozen=True, slots=True)
class WebServerConfig:
    bind: str = "0.0.0.0"
    port: int = 8000
    stream_fps: float = 0.0
    send_timeout: float = 2.0
    frame_ack_timeout: float = 10.0
    auto_connect: bool = True
    reset_wait_sec: float = 8.0
    cloud_stride: int = 2
    cloud_point_budget: int = 180_000
    vis_min: float = 0.1
    vis_max: float = 5.0
    pred_vis_percentile_min: float | None = 1.0
    pred_vis_percentile_max: float | None = 99.0

    def __post_init__(self) -> None:
        if not 1 <= self.port <= 65535:
            raise ValueError("web port must be in [1, 65535]")
        if self.stream_fps < 0.0:
            raise ValueError("web stream_fps must be non-negative")
        if self.send_timeout <= 0.0 or self.frame_ack_timeout <= 0.0:
            raise ValueError("web send and frame ACK timeouts must be positive")
        if self.reset_wait_sec < 0.0:
            raise ValueError("RealSense reset wait must be non-negative")
        if self.cloud_stride <= 0 or self.cloud_point_budget < 0:
            raise ValueError("cloud stride must be positive and budget non-negative")
        if self.vis_max <= self.vis_min:
            raise ValueError("web vis_max must be greater than vis_min")
        percentiles = (self.pred_vis_percentile_min, self.pred_vis_percentile_max)
        if any(value is not None and not 0.0 <= value <= 100.0 for value in percentiles):
            raise ValueError("prediction visualization percentiles must be in [0, 100]")
        if (
            self.pred_vis_percentile_min is not None
            and self.pred_vis_percentile_max is not None
            and self.pred_vis_percentile_max <= self.pred_vis_percentile_min
        ):
            raise ValueError("prediction max percentile must be greater than min percentile")


@dataclass(slots=True)
class _FpsTracker:
    samples: list[float] = field(default_factory=list)
    total: float = 0.0
    count: int = 0

    def tick(self, seconds: float) -> tuple[float, float, float]:
        if seconds <= 0.0:
            return 0.0, 0.0, 0.0
        self.samples.append(seconds)
        self.total += seconds
        self.count += 1
        while sum(self.samples) > 1.0 and len(self.samples) > 1:
            self.samples.pop(0)
        instant = 1.0 / seconds
        average = len(self.samples) / sum(self.samples)
        lifetime = self.count / self.total
        return instant, lifetime, average

    def reset(self) -> None:
        self.samples.clear()
        self.total = 0.0
        self.count = 0


@dataclass(slots=True)
class WebServiceState:
    camera_status: str = "idle"
    camera_error: str | None = None
    camera_stop_requested: bool = False
    quit_requested: bool = False
    inference_enabled: bool = True
    inference_revision: int = 0
    record_on: bool = False
    frame: int = 0
    saved: int = 0
    frame_drops: int = 0
    last_error: str = ""
    inference_fps: float = 0.0
    inference_avg_fps: float = 0.0
    inference_window_fps: float = 0.0
    e2e_fps: float = 0.0
    e2e_avg_fps: float = 0.0
    e2e_window_fps: float = 0.0
    latest_packet: PredictionPacket | None = None
    latest_publication_id: int = 0
    camera_intrinsics: dict[str, float] | None = None
    started_at: float = field(default_factory=time.time)
    camera_started_at: float = 0.0
    worker: threading.Thread | None = None
    cloud_stream_active: bool = False
    condition: threading.Condition = field(default_factory=threading.Condition)


def _spectral_lut() -> list[int]:
    anchors = np.asarray(
        [
            (158, 1, 66),
            (213, 62, 79),
            (244, 109, 67),
            (253, 174, 97),
            (254, 224, 139),
            (255, 255, 191),
            (230, 245, 152),
            (171, 221, 164),
            (102, 194, 165),
            (50, 136, 189),
            (94, 79, 162),
        ],
        dtype=np.float32,
    )
    positions = np.linspace(0.0, 1.0, anchors.shape[0])
    target = np.linspace(0.0, 1.0, 256)
    channels = [np.interp(target, positions, anchors[:, index]) for index in range(3)]
    return cast(
        list[int],
        np.stack(channels, axis=1).round().astype(np.uint8).reshape(-1).tolist(),
    )


def build_access_urls(bind: str, port: int) -> list[dict[str, str]]:
    host = bind.strip() or "0.0.0.0"
    urls = [{"label": "local", "url": f"http://127.0.0.1:{port}/"}]
    formatted = f"[{host}]" if ":" in host and not host.startswith("[") else host
    urls.append({"label": "bind", "url": f"http://{formatted}:{port}/"})
    if host in {"0.0.0.0", "::"}:
        hostname = socket.gethostname()
        if hostname:
            urls.append({"label": "hostname", "url": f"http://{hostname}:{port}/"})
        urls.append({"label": "network", "url": f"http://<LAN-or-Tailscale-IP>:{port}/"})
    return urls


class RealtimeWebController:
    """管理可重连相机 worker，并向 FastAPI 暴露线程安全状态。"""

    def __init__(
        self,
        *,
        runtime: RuntimeBackend | None,
        model_spec: ModelSpec,
        resolution: Resolution,
        camera_factory: Callable[[], CameraSource],
        depth_scale: float,
        max_depth_m: float,
        recorder: Recorder | None,
        session_dir: str | None,
        max_frames: int,
        config: WebServerConfig,
        initial_inference_enabled: bool = True,
    ) -> None:
        self.runtime = runtime
        self.model_spec = model_spec
        self.resolution = resolution
        self.camera_factory = camera_factory
        self.depth_scale = float(depth_scale)
        self.max_depth_m = float(max_depth_m)
        self.recorder = recorder
        self.session_dir = session_dir
        self.max_frames = max(0, int(max_frames))
        self.config = config
        self.access_urls = build_access_urls(config.bind, config.port)
        self.publisher = WebPublisher(lambda _frame: None, max_depth_m=max_depth_m)
        self.state = WebServiceState(
            inference_enabled=runtime is not None and initial_inference_enabled
        )
        self._closed = False

    def status(self) -> dict[str, Any]:
        now = time.time()
        state = self.state
        with state.condition:
            return {
                "camera_status": state.camera_status,
                "camera_error": state.camera_error,
                "frame": state.frame,
                "saved": state.saved,
                "inference_fps": round(state.inference_fps, 2),
                "inference_avg_fps": round(state.inference_avg_fps, 2),
                "inference_window_fps": round(state.inference_window_fps, 2),
                "e2e_fps": round(state.e2e_fps, 2),
                "e2e_avg_fps": round(state.e2e_avg_fps, 2),
                "e2e_window_fps": round(state.e2e_window_fps, 2),
                "frame_drops": state.frame_drops,
                "last_error": state.last_error,
                "record_allowed": self.recorder is not None,
                "record_on": state.record_on,
                "is_disp": False,
                "inference_enabled": state.inference_enabled,
                "inference_revision": state.inference_revision,
                "session_dir": self.session_dir,
                "uptime_sec": round(now - state.started_at, 1),
                "camera_uptime_sec": round(
                    now - state.camera_started_at if state.camera_started_at else 0.0,
                    1,
                ),
                "quit_requested": state.quit_requested,
                "access_urls": self.access_urls,
                "stream_url": "/ws/realtime",
                "render_backend": "webgl",
            }

    def connect_camera(self, source: str = "web") -> None:
        state = self.state
        worker: threading.Thread | None = None
        with state.condition:
            if state.quit_requested:
                raise RuntimeError("Service is stopping")
            if state.cloud_stream_active:
                raise RuntimeError("D435 is busy serving /pointcloud")
            if state.camera_status in {"connecting", "running", "disconnecting"}:
                return
            if state.worker is not None and state.worker.is_alive():
                raise RuntimeError("D435 worker is still stopping")
            state.camera_status = "connecting"
            state.camera_error = None
            state.camera_stop_requested = False
            state.last_error = ""
            state.frame_drops = 0
            state.latest_packet = None
            worker = threading.Thread(target=self._camera_worker, daemon=True, name="d435_web")
            state.worker = worker
        worker.start()
        logger.info("Camera connect requested via %s", source)

    def disconnect_camera(self) -> None:
        state = self.state
        with state.condition:
            state.record_on = False
            state.latest_packet = None
            if state.camera_status in {"connecting", "running"}:
                state.camera_status = "disconnecting"
                state.camera_stop_requested = True
            elif state.camera_status in {"idle", "error", "stopped"}:
                state.camera_status = "idle" if not state.quit_requested else "stopped"
                state.camera_error = None
                state.camera_stop_requested = False
            state.condition.notify_all()

    def toggle_inference(self, enabled: bool) -> None:
        state = self.state
        with state.condition:
            if state.record_on:
                raise RuntimeError("Cannot switch inference while recording is active")
            if enabled and self.runtime is None:
                raise RuntimeError("No model runtime is loaded")
            if state.inference_enabled != enabled:
                state.inference_enabled = enabled
                state.inference_revision += 1
                state.latest_packet = None
                state.inference_fps = 0.0
                state.inference_avg_fps = 0.0
                state.inference_window_fps = 0.0
                state.condition.notify_all()

    def toggle_recording(self) -> bool:
        state = self.state
        if self.recorder is None:
            raise RuntimeError("Recording disabled at startup (--no-record)")
        with state.condition:
            if state.camera_status != "running":
                raise RuntimeError("Camera is not running")
            if not state.inference_enabled:
                raise RuntimeError("Inference must be enabled before recording")
            state.record_on = not state.record_on
            return state.record_on

    def request_quit(self) -> None:
        state = self.state
        with state.condition:
            state.quit_requested = True
            state.camera_stop_requested = True
            state.record_on = False
            state.camera_status = (
                "disconnecting" if state.camera_status in {"connecting", "running"} else "stopped"
            )
            state.condition.notify_all()

    def _make_packet_without_inference(self, frame: Any) -> PredictionPacket:
        depth = np.zeros(frame.raw_depth_mm.shape, dtype=np.float32)
        return PredictionPacket(
            frame,
            depth,
            metadata=MappingProxyType({"model_identity": self.model_spec.identity}),
        )

    def _camera_worker(self) -> None:
        state = self.state
        camera = self.camera_factory()
        pipeline = (
            RealtimePipeline(
                camera,
                self.runtime,
                D435HostPreprocessor(
                    self.resolution,
                    depth_scale=self.depth_scale,
                    max_depth_m=self.max_depth_m,
                ),
            )
            if self.runtime is not None
            else None
        )
        inference_tracker = _FpsTracker()
        e2e_tracker = _FpsTracker()
        error: str | None = None
        try:
            camera.start()
            with state.condition:
                if state.camera_stop_requested or state.quit_requested:
                    return
                state.camera_status = "running"
                state.camera_started_at = time.time()
                state.condition.notify_all()
            while True:
                with state.condition:
                    if state.camera_stop_requested or state.quit_requested:
                        break
                    inference_enabled = state.inference_enabled
                    revision = state.inference_revision
                started = time.perf_counter()
                try:
                    frame = camera.read()
                except RuntimeError as exc:
                    with state.condition:
                        state.frame_drops += 1
                        state.last_error = str(exc)
                    continue
                if frame is None:
                    break
                if inference_enabled:
                    if pipeline is None:
                        raise RuntimeError("Inference enabled without a runtime")
                    packet = pipeline.process(frame)
                    inference_seconds = sum(packet.timings_ms.values()) / 1000.0
                    inf_values = inference_tracker.tick(max(inference_seconds, 1e-9))
                else:
                    packet = self._make_packet_without_inference(frame)
                    inf_values = (0.0, 0.0, 0.0)
                e2e_values = e2e_tracker.tick(max(time.perf_counter() - started, 1e-9))
                with state.condition:
                    if revision != state.inference_revision:
                        continue
                    state.latest_packet = packet
                    state.latest_publication_id += 1
                    state.frame += 1
                    state.inference_fps, state.inference_avg_fps, state.inference_window_fps = (
                        inf_values
                    )
                    state.e2e_fps, state.e2e_avg_fps, state.e2e_window_fps = e2e_values
                    intrinsics = packet.frame.metadata.get("intrinsics")
                    state.camera_intrinsics = dict(intrinsics) if intrinsics else None
                    should_record = state.record_on and self.recorder is not None
                    state.condition.notify_all()
                if should_record and self.recorder is not None and inference_enabled:
                    self.recorder.publish(packet)
                    with state.condition:
                        state.saved = self.recorder.frames_written
                        if self.max_frames > 0 and state.saved >= self.max_frames:
                            state.record_on = False
                            state.camera_stop_requested = True
                            state.camera_status = "disconnecting"
                            state.condition.notify_all()
        except Exception as exc:
            error = str(exc) or exc.__class__.__name__
            logger.exception("D435 Web worker failed")
        finally:
            try:
                camera.close()
            except Exception as exc:
                error = error or str(exc) or exc.__class__.__name__
                logger.exception("D435 Web camera close failed")
            with state.condition:
                state.record_on = False
                state.camera_stop_requested = False
                state.latest_packet = None
                state.camera_started_at = 0.0
                state.camera_status = (
                    "stopped" if state.quit_requested else ("error" if error else "idle")
                )
                state.camera_error = error
                state.worker = None
                state.condition.notify_all()
            logger.info("D435 Web worker stopped")

    def wait_for_packet(
        self,
        last_publication_id: int,
        timeout: float,
    ) -> tuple[int, PredictionPacket, dict[str, Any]] | None:
        state = self.state
        with state.condition:
            state.condition.wait_for(
                lambda: (
                    state.quit_requested
                    or state.camera_stop_requested
                    or state.camera_status not in {"connecting", "running"}
                    or (
                        state.latest_packet is not None
                        and state.latest_publication_id != last_publication_id
                    )
                ),
                timeout=timeout,
            )
            if state.latest_packet is None or state.latest_publication_id == last_publication_id:
                return None
            fields = {
                "frame_id": state.latest_publication_id,
                "frame": state.frame,
                "timestamp": state.latest_packet.frame.timestamp_ns / 1_000_000_000.0,
                "inference_dt_sec": sum(state.latest_packet.timings_ms.values()) / 1000.0,
                "inference_fps": round(state.inference_fps, 2),
                "inference_avg_fps": round(state.inference_avg_fps, 2),
                "inference_window_fps": round(state.inference_window_fps, 2),
                "inference_enabled": state.inference_enabled,
                "inference_revision": state.inference_revision,
                "pred_depth_source": "model" if state.inference_enabled else None,
                "e2e_fps": round(state.e2e_fps, 2),
                "e2e_avg_fps": round(state.e2e_avg_fps, 2),
                "e2e_window_fps": round(state.e2e_window_fps, 2),
                "record_on": state.record_on,
                "saved": state.saved,
                "intrinsics": state.camera_intrinsics,
            }
            return state.latest_publication_id, state.latest_packet, fields

    def stream_should_end(self) -> bool:
        state = self.state
        with state.condition:
            return state.quit_requested or state.camera_status not in {"connecting", "running"}

    def acquire_cloud_camera(self) -> bool:
        state = self.state
        with state.condition:
            if state.quit_requested or state.cloud_stream_active:
                return False
            if state.camera_status in {"connecting", "running", "disconnecting"}:
                return False
            state.cloud_stream_active = True
            return True

    def release_cloud_camera(self) -> None:
        with self.state.condition:
            self.state.cloud_stream_active = False
            self.state.condition.notify_all()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self.request_quit()
        worker = self.state.worker
        if worker is not None and worker is not threading.current_thread():
            worker.join(timeout=self.config.reset_wait_sec + 10.0)
        if self.recorder is not None:
            self.recorder.close()
        if self.runtime is not None:
            close_runtime = getattr(self.runtime, "close", None)
            if callable(close_runtime):
                close_runtime()


def _resource_text(name: str) -> str:
    return files("asdepth.resources").joinpath("web").joinpath(name).read_text(encoding="utf-8")


async def _send_json(websocket: Any, value: dict[str, Any], timeout: float) -> None:
    await asyncio.wait_for(websocket.send_json(value), timeout=timeout)


async def _send_bytes(websocket: Any, value: bytes, timeout: float) -> None:
    await asyncio.wait_for(websocket.send_bytes(value), timeout=timeout)


async def _wait_for_ack(websocket: Any, frame_id: int, timeout: float) -> None:
    message = await asyncio.wait_for(websocket.receive_json(), timeout=timeout)
    if (
        not isinstance(message, dict)
        or message.get("type") != "frame_ack"
        or type(message.get("frame_id")) is not int
        or message["frame_id"] != frame_id
    ):
        raise RuntimeError(f"expected frame_ack for frame {frame_id}")


def _ready_message(controller: RealtimeWebController) -> dict[str, Any]:
    state = controller.state
    with state.condition:
        inference_enabled = state.inference_enabled
        revision = state.inference_revision
    config = controller.config
    return {
        "type": "ready",
        "protocol": REALTIME_PROTOCOL,
        "flow_control": REALTIME_FLOW_CONTROL,
        "max_in_flight_frames": 1,
        "frame_ack_timeout_sec": config.frame_ack_timeout,
        "color_layout": "BGR",
        "depth_unit": "millimeter",
        "depth_scale": controller.depth_scale,
        "max_depth": controller.max_depth_m,
        "vis_min": config.vis_min,
        "vis_max": config.vis_max,
        "pred_vis_percentile_min": config.pred_vis_percentile_min,
        "pred_vis_percentile_max": config.pred_vis_percentile_max,
        "inference_enabled": inference_enabled,
        "inference_revision": revision,
        "pred_depth_source": "model" if inference_enabled else None,
        "cloud_stride": config.cloud_stride,
        "cloud_point_budget": config.cloud_point_budget,
        "colormap": "Spectral",
        "colormap_lut_rgb": _spectral_lut(),
    }


async def _realtime_websocket(
    controller: RealtimeWebController,
    websocket: Any,
    *,
    ws_stream_fps: float,
    send_color: bool,
    send_raw: bool,
    send_pred: bool,
    send_raw_cloud: bool,
    send_pred_cloud: bool,
    cloud_stride: int,
    cloud_point_budget: int,
) -> None:
    await websocket.accept()
    await _send_json(websocket, _ready_message(controller), controller.config.send_timeout)
    last_publication_id = -1
    interval = 1.0 / ws_stream_fps if ws_stream_fps > 0.0 else 0.0
    next_frame_at = 0.0
    try:
        while True:
            if interval > 0.0 and time.perf_counter() < next_frame_at:
                await asyncio.sleep(min(0.005, next_frame_at - time.perf_counter()))
                continue
            item = await asyncio.to_thread(
                controller.wait_for_packet,
                last_publication_id,
                0.5,
            )
            if item is None:
                if controller.stream_should_end():
                    return
                continue
            publication_id, packet, fields = item
            inference_enabled = bool(fields["inference_enabled"])
            frame = await asyncio.to_thread(
                controller.publisher.build_frame,
                packet,
                include_color=send_color,
                include_raw=send_raw,
                include_pred=send_pred and inference_enabled,
                include_raw_cloud=send_raw_cloud,
                include_pred_cloud=send_pred_cloud and inference_enabled,
                cloud_stride=cloud_stride,
                cloud_point_budget=cloud_point_budget,
                header_fields=fields,
            )
            await _send_json(websocket, dict(frame.header), controller.config.send_timeout)
            await _send_bytes(websocket, frame.payload, controller.config.send_timeout)
            await _wait_for_ack(websocket, publication_id, controller.config.frame_ack_timeout)
            last_publication_id = publication_id
            if interval > 0.0:
                next_frame_at = max(next_frame_at + interval, time.perf_counter())
    except Exception as exc:  # WebSocketDisconnect is intentionally transport-local
        if exc.__class__.__name__ != "WebSocketDisconnect":
            logger.info("Realtime WebSocket closed: %s", exc)


def _point_payload(
    packet: PredictionPacket,
    *,
    depth_scale: float,
    max_depth: float,
    stride: int,
    point_budget: int,
) -> tuple[bytes, int]:
    intr = packet.frame.metadata.get("intrinsics")
    if not intr:
        raise RuntimeError("RealSense color intrinsics are unavailable")
    depth = packet.frame.raw_depth_mm[::stride, ::stride].astype(np.float32) / depth_scale
    valid = np.isfinite(depth) & (depth > 0.0) & (depth <= max_depth)
    count = int(valid.sum())
    if count == 0:
        return b"", 0
    rows = np.arange(0, packet.frame.raw_depth_mm.shape[0], stride, dtype=np.float32)
    cols = np.arange(0, packet.frame.raw_depth_mm.shape[1], stride, dtype=np.float32)
    uu, vv = np.meshgrid(cols, rows)
    z = depth[valid]
    x = (uu[valid] - float(intr["ppx"])) * z / float(intr["fx"])
    y = -(vv[valid] - float(intr["ppy"])) * z / float(intr["fy"])
    rgb = packet.frame.color_bgr[::stride, ::stride, ::-1][valid]
    if point_budget > 0 and count > point_budget:
        keep = np.linspace(0, count - 1, point_budget, dtype=np.int64)
        x, y, z, rgb = x[keep], y[keep], z[keep], rgb[keep]
        count = point_budget
    points = np.empty(count, dtype=POINT_DTYPE)
    points["xyz"][:, 0] = x
    points["xyz"][:, 1] = y
    points["xyz"][:, 2] = -z
    points["rgba"][:, :3] = rgb
    points["rgba"][:, 3] = 255
    return points.tobytes(), count


async def _pointcloud_websocket(
    controller: RealtimeWebController,
    websocket: Any,
    *,
    stride: int,
    max_depth: float,
    point_budget: int,
    stream_fps: float,
) -> None:
    await websocket.accept()
    if not controller.acquire_cloud_camera():
        await websocket.send_json({"type": "error", "message": "D435 is already in use"})
        await websocket.close(code=1013)
        return
    camera = controller.camera_factory()
    try:
        camera.start()
        frame_index = 0
        ready_sent = False
        interval = 1.0 / stream_fps if stream_fps > 0.0 else 0.0
        while not controller.state.quit_requested:
            started = time.perf_counter()
            frame = await asyncio.to_thread(camera.read)
            if frame is None:
                return
            packet = controller._make_packet_without_inference(frame)
            intr = frame.metadata.get("intrinsics")
            if not ready_sent:
                if not intr:
                    raise RuntimeError("RealSense color intrinsics are unavailable")
                await _send_json(
                    websocket,
                    {
                        "type": "ready",
                        **dict(intr),
                        "stride": stride,
                        "max_depth": max_depth,
                        "point_budget": point_budget,
                        "point_stride_bytes": POINT_DTYPE.itemsize,
                        "coordinate": "x_right_y_up_z_forward_negative",
                    },
                    controller.config.send_timeout,
                )
                ready_sent = True
            payload, count = await asyncio.to_thread(
                _point_payload,
                packet,
                depth_scale=controller.depth_scale,
                max_depth=max_depth,
                stride=stride,
                point_budget=point_budget,
            )
            elapsed = max(time.perf_counter() - started, 1e-9)
            await _send_json(
                websocket,
                {
                    "type": "frame",
                    "frame": frame_index,
                    "points": count,
                    "bytes": len(payload),
                    "fps": round(1.0 / elapsed, 2),
                    "stride": stride,
                    "max_depth": max_depth,
                    "point_budget": point_budget,
                    "timestamp": time.time(),
                },
                controller.config.send_timeout,
            )
            await _send_bytes(websocket, payload, controller.config.send_timeout)
            frame_index += 1
            if interval > elapsed:
                await asyncio.sleep(interval - elapsed)
    except Exception as exc:
        if exc.__class__.__name__ != "WebSocketDisconnect":
            logger.info("Point-cloud WebSocket closed: %s", exc)
    finally:
        await asyncio.to_thread(camera.close)
        controller.release_cloud_camera()


def build_web_app(controller: RealtimeWebController) -> Any:
    try:
        from fastapi import FastAPI, HTTPException, Query, WebSocket
        from fastapi.responses import HTMLResponse, JSONResponse
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise RuntimeError("Web realtime requires the 'realtime' extra") from exc
    # ``from __future__ import annotations`` resolves endpoint annotations from
    # module globals; publish the lazily imported optional type for FastAPI.
    globals()["WebSocket"] = WebSocket

    app = FastAPI(title="AS-Depth Realtime D435")
    index_html = _resource_text("index.html")
    pointcloud_html = _resource_text("pointcloud.html")

    @app.get("/", response_class=HTMLResponse)
    def index() -> str:
        return index_html

    @app.get("/pointcloud", response_class=HTMLResponse)
    def pointcloud() -> str:
        return pointcloud_html

    @app.get("/status")
    def status() -> JSONResponse:
        return JSONResponse(controller.status())

    @app.post("/camera/connect")
    def camera_connect() -> JSONResponse:
        try:
            controller.connect_camera()
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return JSONResponse(controller.status())

    @app.post("/camera/disconnect")
    def camera_disconnect() -> JSONResponse:
        controller.disconnect_camera()
        return JSONResponse(controller.status())

    @app.post("/inference")
    def inference(enabled: bool = Query(...)) -> JSONResponse:
        try:
            controller.toggle_inference(enabled)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return JSONResponse(controller.status())

    @app.post("/record/toggle")
    def record_toggle() -> JSONResponse:
        try:
            enabled = controller.toggle_recording()
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return JSONResponse({"record_on": enabled})

    @app.post("/quit")
    def quit_service() -> JSONResponse:
        controller.request_quit()
        return JSONResponse({"quit": True})

    @app.websocket("/ws/realtime")
    async def realtime_ws(
        websocket: WebSocket,
        ws_stream_fps: float = Query(controller.config.stream_fps, ge=0.0, le=120.0),
        send_color: bool = Query(True),
        send_raw: bool = Query(True),
        send_pred: bool = Query(True),
        send_raw_cloud: bool = Query(False),
        send_pred_cloud: bool = Query(True),
        cloud_stride: int = Query(controller.config.cloud_stride, ge=1, le=16),
        cloud_point_budget: int = Query(
            controller.config.cloud_point_budget,
            ge=0,
            le=500_000,
        ),
    ) -> None:
        await _realtime_websocket(
            controller,
            websocket,
            ws_stream_fps=ws_stream_fps,
            send_color=send_color,
            send_raw=send_raw,
            send_pred=send_pred,
            send_raw_cloud=send_raw_cloud,
            send_pred_cloud=send_pred_cloud,
            cloud_stride=cloud_stride,
            cloud_point_budget=cloud_point_budget,
        )

    @app.websocket("/ws/pointcloud")
    async def pointcloud_ws(
        websocket: WebSocket,
        stride: int = Query(controller.config.cloud_stride, ge=1, le=16),
        max_depth: float = Query(controller.max_depth_m, gt=0.0, le=20.0),
        point_budget: int = Query(
            controller.config.cloud_point_budget,
            ge=0,
            le=500_000,
        ),
        stream_fps: float = Query(controller.config.stream_fps, ge=0.0, le=60.0),
    ) -> None:
        await _pointcloud_websocket(
            controller,
            websocket,
            stride=stride,
            max_depth=max_depth,
            point_budget=point_budget,
            stream_fps=stream_fps,
        )

    return app


def run_web_server(controller: RealtimeWebController) -> int:
    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover - optional dependency boundary
        raise RuntimeError("Web realtime requires the 'realtime' extra") from exc

    app = build_web_app(controller)
    config = controller.config
    server = uvicorn.Server(
        uvicorn.Config(
            app,
            host=config.bind,
            port=config.port,
            log_level="info",
            access_log=False,
            ws="websockets-sansio",
            ws_ping_interval=None,
        )
    )

    def watch_quit() -> None:
        while not controller.state.quit_requested:
            time.sleep(0.25)
        server.should_exit = True

    threading.Thread(target=watch_quit, daemon=True, name="web_quit_watcher").start()
    if config.auto_connect:
        controller.connect_camera(source="startup")
    logger.info("Web UI local: http://127.0.0.1:%d/", config.port)
    logger.info("Web UI listener: http://%s:%d/", config.bind, config.port)
    if config.bind in {"0.0.0.0", "::"}:
        logger.info("LAN/Tailscale access: http://<hostname-or-ip>:%d/", config.port)
    try:
        server.run()
    finally:
        controller.close()
    return 0


def realsense_camera_factory(
    *,
    width: int,
    height: int,
    fps: int,
    serial: str | None,
    reset_wait_sec: float,
) -> Callable[[], CameraSource]:
    return lambda: RealSenseD435Source(
        width=width,
        height=height,
        fps=fps,
        serial=serial,
        reset_on_close=True,
        reset_wait_sec=reset_wait_sec,
    )
