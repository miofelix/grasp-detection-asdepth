"""脚本说明：
作用：启动 D435 realtime pipeline，或用 mock camera 验证完整 packet/recorder 闭环。

典型用法：
    asdepth realtime --checkpoint ckpts/asdepth2.ckpt --model defm_stackconv_depth
    asdepth realtime --engine runs/deploy/model.engine --model defm_stackconv_depth
    asdepth realtime --mock --max-frames 2 --record --output runs/realtime_d435
    asdepth realtime --engine runs/deploy/model.engine --device cuda --web --port 8000

参数说明：
    - --checkpoint 与 --engine 二选一；--mock 未指定模型产物时使用确定性 raw-depth runtime。
    - --record 保持 rgb.mp4/raw_depth.npy/pred_depth.npy/frames.jsonl/meta.json 契约。

环境变量/外部依赖：
    - 真实 D435 需要 librealsense/pyrealsense2；TensorRT engine 需要 TensorRT Python/CUDA。

运行注意：
    - canonical 主线固定 host preprocess + 单输入 rgbd_input + metric depth meter。
    - `--web` 同时支持 host 与 clean-wheel Docker，默认监听 0.0.0.0:8000。
    - embedded 双输入仍只在冻结 legacy 中保留。
"""

from __future__ import annotations

import argparse
import json
import time
from collections.abc import Callable, Sequence
from pathlib import Path

import numpy as np
import torch

from asdepth.core import ContractError, ModelSpec
from asdepth.deployment import DEFAULT_RESOLUTION_TEXT, Resolution
from asdepth.models import ModelCatalog, load_model_with_report
from asdepth.runtime import RuntimeBatchOutput, TensorRTBackend, TorchBackend

from .camera import MockCameraSource, RealSenseD435Source
from .packets import CameraSource, FramePacket, PredictionConsumer
from .pipeline import RealtimePipeline
from .preprocess import D435HostPreprocessor
from .publishers import NativeViewer
from .recorder import Recorder, make_session_paths


class _RawDepthRuntime:
    """Mock camera 的纯逻辑 runtime，不用于真实模型结果。"""

    def __init__(self, model_spec: ModelSpec) -> None:
        self.model_spec = model_spec

    def infer(self, inputs: object) -> RuntimeBatchOutput:
        value = np.asarray(inputs, dtype=np.float32)
        return RuntimeBatchOutput(value[:, 3])

    def close(self) -> None:
        return None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth realtime",
        description="运行 host-preprocess D435 realtime packet pipeline",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--checkpoint")
    source.add_argument("--engine")
    parser.add_argument("--model", dest="model_id", default="defm_stackconv_depth")
    parser.add_argument("--resolution", default=DEFAULT_RESOLUTION_TEXT)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--mock", action="store_true")
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--serial")
    parser.add_argument("--depth-scale", type=float, default=1000.0)
    parser.add_argument("--max-depth", type=float, default=10.0)
    parser.add_argument("--max-frames", type=int, default=0)
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--output", default="runs/realtime_d435")
    parser.add_argument("--session-id")
    parser.add_argument("--display", action="store_true")
    parser.add_argument("--web", action="store_true")
    parser.add_argument("--bind", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--stream-fps", type=float, default=0.0)
    parser.add_argument("--send-timeout", type=float, default=2.0)
    parser.add_argument("--frame-ack-timeout", type=float, default=10.0)
    parser.add_argument("--no-inference", action="store_true")
    parser.add_argument("--no-auto-connect", action="store_true")
    parser.add_argument("--realsense-reset-wait", type=float, default=8.0)
    parser.add_argument("--cloud-stride", type=int, default=2)
    parser.add_argument("--cloud-point-budget", type=int, default=180_000)
    parser.add_argument("--vis-min", type=float, default=0.1)
    parser.add_argument("--vis-max", type=float, default=5.0)
    parser.add_argument("--pred-vis-percentile-min", type=float, default=1.0)
    parser.add_argument("--pred-vis-percentile-max", type=float, default=99.0)
    parser.add_argument("--no-pred-vis-percentile", action="store_true")
    parser.add_argument("--no-record", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    return parser


def _device(value: str) -> torch.device:
    if value != "auto":
        return torch.device(value)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _mock_frames(width: int, height: int, count: int) -> list[FramePacket]:
    total = count if count > 0 else 1
    frames: list[FramePacket] = []
    for index in range(total):
        x = np.linspace(0, 255, width, dtype=np.uint8)
        color = np.zeros((height, width, 3), dtype=np.uint8)
        color[..., 0] = x[None]
        color[..., 1] = np.uint8((index * 17) % 255)
        color[..., 2] = x[::-1][None]
        raw = np.full((height, width), 1000 + index * 10, dtype=np.uint16)
        raw[:, ::17] = 0
        frames.append(
            FramePacket(
                frame_id=index,
                timestamp_ns=time.time_ns() + index,
                color_bgr=color,
                raw_depth_mm=raw,
            )
        )
    return frames


def _runtime(args: argparse.Namespace) -> tuple[object | None, ModelSpec]:
    catalog = ModelCatalog.from_package()
    if args.checkpoint:
        report = load_model_with_report(
            args.checkpoint,
            model_id=args.model_id,
            device=_device(args.device),
        )
        return TorchBackend(report.model, report.spec, device=_device(args.device)), report.spec
    spec = catalog.get(args.model_id).to_model_spec()
    if args.engine:
        device = str(_device(args.device))
        if not device.startswith("cuda"):
            raise ContractError("TensorRT realtime requires --device cuda[:index]")
        return TensorRTBackend(args.engine, spec, device=device), spec
    if args.mock:
        return _RawDepthRuntime(spec), spec
    if args.web:
        return None, spec
    raise ContractError("realtime requires --checkpoint or --engine; use --mock for CI smoke")


def _run_web(
    args: argparse.Namespace,
    resolution: Resolution,
    runtime: object | None,
    model_spec: ModelSpec,
) -> int:
    from .web import (
        RealtimeWebController,
        WebServerConfig,
        realsense_camera_factory,
        run_web_server,
    )

    if args.display:
        raise ContractError("--web and --display are mutually exclusive")
    pred_percentile_min = None if args.no_pred_vis_percentile else args.pred_vis_percentile_min
    pred_percentile_max = None if args.no_pred_vis_percentile else args.pred_vis_percentile_max
    web_config = WebServerConfig(
        bind=args.bind,
        port=args.port,
        stream_fps=args.stream_fps,
        send_timeout=args.send_timeout,
        frame_ack_timeout=args.frame_ack_timeout,
        auto_connect=not args.no_auto_connect,
        reset_wait_sec=args.realsense_reset_wait,
        cloud_stride=args.cloud_stride,
        cloud_point_budget=args.cloud_point_budget,
        vis_min=args.vis_min,
        vis_max=args.vis_max,
        pred_vis_percentile_min=pred_percentile_min,
        pred_vis_percentile_max=pred_percentile_max,
    )
    recorder: Recorder | None = None
    session_root: Path | None = None
    if runtime is not None and not args.no_record:
        paths = make_session_paths(
            args.output,
            session_id=args.session_id,
            overwrite=args.overwrite,
        )
        recorder = Recorder(
            paths,
            fps=args.fps,
            metadata={
                "model": model_spec.to_dict(),
                "resolution": resolution.label,
                "camera": "mock" if args.mock else "realsense_d435",
                "transport": "webgl.v2",
            },
            overwrite=args.overwrite,
        )
        session_root = paths.root
    camera_factory: Callable[[], CameraSource]
    if args.mock:
        mock_count = args.max_frames if args.max_frames > 0 else 300

        def camera_factory() -> MockCameraSource:
            return MockCameraSource(_mock_frames(args.width, args.height, mock_count))

    else:
        camera_factory = realsense_camera_factory(
            width=args.width,
            height=args.height,
            fps=args.fps,
            serial=args.serial,
            reset_wait_sec=args.realsense_reset_wait,
        )
    controller = RealtimeWebController(
        runtime=runtime,  # type: ignore[arg-type]
        model_spec=model_spec,
        resolution=resolution,
        camera_factory=camera_factory,
        depth_scale=args.depth_scale,
        max_depth_m=args.max_depth,
        recorder=recorder,
        session_dir=str(session_root) if session_root is not None else None,
        max_frames=args.max_frames,
        config=web_config,
        initial_inference_enabled=not args.no_inference,
    )
    return run_web_server(controller)


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    pipeline: RealtimePipeline | None = None
    try:
        resolution = Resolution.parse(args.resolution)
        runtime, model_spec = _runtime(args)
        if args.web:
            return _run_web(args, resolution, runtime, model_spec)
        if runtime is None:
            raise ContractError("realtime runtime is unavailable")
        camera = (
            MockCameraSource(_mock_frames(args.width, args.height, args.max_frames))
            if args.mock
            else RealSenseD435Source(
                width=args.width,
                height=args.height,
                fps=args.fps,
                serial=args.serial,
            )
        )
        consumers: list[PredictionConsumer] = []
        session_root: Path | None = None
        if args.record:
            paths = make_session_paths(
                args.output,
                session_id=args.session_id,
                overwrite=args.overwrite,
            )
            consumers.append(
                Recorder(
                    paths,
                    fps=args.fps,
                    metadata={
                        "model": model_spec.to_dict(),
                        "resolution": resolution.label,
                        "camera": "mock" if args.mock else "realsense_d435",
                    },
                    overwrite=args.overwrite,
                )
            )
            session_root = paths.root
        viewer: NativeViewer | None = None
        if args.display:
            viewer = NativeViewer()
            consumers.append(viewer)
        pipeline = RealtimePipeline(
            camera,
            runtime,  # type: ignore[arg-type]
            D435HostPreprocessor(
                resolution,
                depth_scale=args.depth_scale,
                max_depth_m=args.max_depth,
            ),
            consumers=consumers,
        )
        count = 0
        last_frame = None
        limit = args.max_frames if args.max_frames > 0 else None
        for packet in pipeline.run(max_frames=limit):
            count += 1
            last_frame = packet.frame.frame_id
            if viewer is not None and viewer.quit_requested:
                break
        print(
            json.dumps(
                {
                    "frames": count,
                    "last_frame_id": last_frame,
                    "session": str(session_root) if session_root else None,
                    "model_identity": model_spec.identity,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    except (ContractError, FileExistsError, FileNotFoundError, RuntimeError, ValueError) as exc:
        parser.error(str(exc))
    finally:
        if pipeline is not None:
            pipeline.close()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
