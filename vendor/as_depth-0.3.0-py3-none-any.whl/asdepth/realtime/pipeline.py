"""与相机、runtime 和 UI 解耦的 realtime packet pipeline。"""

from __future__ import annotations

import time
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

import cv2
import numpy as np
import torch

from asdepth.core import ContractError
from asdepth.runtime import RuntimeBackend

from .packets import (
    CameraSource,
    FramePacket,
    PredictionConsumer,
    PredictionPacket,
    RealtimePostprocessor,
    RealtimePreprocessor,
)


def _numpy(value: Any) -> np.ndarray:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


@dataclass(frozen=True, slots=True)
class MetricDepthPostprocessor:
    """单输出 NHW/N1HW → HxW meter，并按需恢复原相机尺寸。"""

    restore_camera_shape: bool = True

    def process(self, values: Any, frame: FramePacket) -> np.ndarray:
        if isinstance(values, dict):
            values = next(iter(values.values()))
        if isinstance(values, tuple | list):
            values = values[0]
        raw_depth = np.asarray(_numpy(values), dtype=np.float32)
        depth: np.ndarray
        depth = raw_depth
        if depth.ndim == 4 and depth.shape[0] == 1 and depth.shape[1] == 1:
            depth = depth[0, 0]
        elif depth.ndim == 3 and depth.shape[0] == 1:
            depth = depth[0]
        if depth.ndim != 2:
            raise ContractError(f"realtime runtime output must reduce to HxW, got {depth.shape}")
        if self.restore_camera_shape and depth.shape != frame.raw_depth_mm.shape:
            depth = np.asarray(
                cv2.resize(
                    depth,
                    (frame.raw_depth_mm.shape[1], frame.raw_depth_mm.shape[0]),
                    interpolation=cv2.INTER_NEAREST,
                ),
                dtype=np.float32,
            )
        result = np.ascontiguousarray(depth, dtype=np.float32)
        result[~np.isfinite(result)] = 0.0
        result[result < 0.0] = 0.0
        return result


class RealtimePipeline:
    """CameraSource → preprocess → RuntimeBackend → packet consumers。"""

    def __init__(
        self,
        camera: CameraSource,
        runtime: RuntimeBackend,
        preprocessor: RealtimePreprocessor,
        *,
        postprocessor: RealtimePostprocessor | None = None,
        consumers: Iterable[PredictionConsumer] = (),
    ) -> None:
        if runtime.model_spec.depth.representation.value != "metric_depth":
            raise ContractError("realtime canonical pipeline requires metric-depth runtime output")
        self.camera = camera
        self.runtime = runtime
        self.preprocessor = preprocessor
        self.postprocessor = postprocessor or MetricDepthPostprocessor()
        self.consumers = tuple(consumers)
        self._started = False

    def start(self) -> None:
        if not self._started:
            self.camera.start()
            self._started = True

    def process(self, frame: FramePacket) -> PredictionPacket:
        preprocess_started = time.perf_counter()
        inputs = self.preprocessor.prepare(frame)
        preprocess_ms = (time.perf_counter() - preprocess_started) * 1000.0
        runtime_output = self.runtime.infer(inputs)
        postprocess_started = time.perf_counter()
        depth = self.postprocessor.process(runtime_output.values, frame)
        postprocess_ms = (time.perf_counter() - postprocess_started) * 1000.0
        timings = {
            "preprocess": preprocess_ms,
            **dict(runtime_output.timings_ms),
            "postprocess": postprocess_ms,
        }
        packet = PredictionPacket(
            frame=frame,
            depth_m=depth,
            timings_ms=MappingProxyType(timings),
            metadata=MappingProxyType({"model_identity": self.runtime.model_spec.identity}),
        )
        for consumer in self.consumers:
            consumer.publish(packet)
        return packet

    def run(self, *, max_frames: int | None = None) -> Iterator[PredictionPacket]:
        if max_frames is not None and max_frames < 0:
            raise ContractError("max_frames cannot be negative")
        self.start()
        produced = 0
        while max_frames is None or produced < max_frames:
            frame = self.camera.read()
            if frame is None:
                break
            yield self.process(frame)
            produced += 1

    def close(self) -> None:
        for consumer in reversed(self.consumers):
            consumer.close()
        close_runtime = getattr(self.runtime, "close", None)
        if callable(close_runtime):
            close_runtime()
        self.camera.close()
        self._started = False

    def __enter__(self) -> RealtimePipeline:
        self.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
