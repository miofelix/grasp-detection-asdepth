"""严格的 OmegaConf 加载、覆盖、冻结与稳定哈希。"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, cast

import yaml
from omegaconf import DictConfig, OmegaConf
from omegaconf.errors import OmegaConfBaseException

from asdepth.artifacts.io import atomic_write_text
from asdepth.core import ContractError


class ConfigError(ContractError):
    """配置来源、字段、插值或覆盖不满足严格契约。"""


def _plain_config(config: DictConfig) -> dict[str, Any]:
    value = OmegaConf.to_container(config, resolve=True, enum_to_str=True)
    if not isinstance(value, dict):
        raise ConfigError("root config must be a mapping")
    return cast(dict[str, Any], value)


def config_hash(config: DictConfig | Mapping[str, Any]) -> str:
    """对 resolved config 使用排序 JSON 计算稳定 SHA-256。"""

    value = _plain_config(config) if isinstance(config, DictConfig) else dict(config)
    serialized = json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(serialized).hexdigest()


@dataclass(frozen=True, slots=True)
class ResolvedConfig:
    """只读 resolved OmegaConf、来源顺序和内容 hash。"""

    config: DictConfig
    hash: str
    sources: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return _plain_config(self.config)

    def to_yaml(self) -> str:
        return yaml.safe_dump(
            self.as_dict(),
            allow_unicode=True,
            default_flow_style=False,
            sort_keys=True,
        )

    def archive(self, path: Path, *, overwrite: bool = False) -> Path:
        """写入 `config.resolved.yaml`，默认拒绝覆盖。"""

        return atomic_write_text(path, self.to_yaml(), overwrite=overwrite)


def _merge_strict(base: DictConfig, incoming: DictConfig, *, source: str) -> DictConfig:
    try:
        merged = OmegaConf.merge(base, incoming)
        OmegaConf.set_struct(merged, True)
        return cast(DictConfig, merged)
    except OmegaConfBaseException as exc:
        raise ConfigError(f"invalid config from {source}: {exc}") from exc


def _dotlist(values: Sequence[str], *, source: str) -> DictConfig:
    try:
        result = OmegaConf.from_dotlist(list(values))
    except OmegaConfBaseException as exc:
        raise ConfigError(f"invalid {source} override: {exc}") from exc
    return result


class ConfigLoader:
    """按固定优先级解析配置并拒绝未知字段。"""

    def __init__(
        self,
        defaults: Mapping[str, Any] | DictConfig,
        *,
        allowed_env: Mapping[str, str] | None = None,
    ) -> None:
        if isinstance(defaults, DictConfig):
            defaults_config = defaults
        else:
            created_defaults = OmegaConf.create(dict(defaults))
            if not isinstance(created_defaults, DictConfig):
                raise ConfigError("defaults must be a mapping")
            defaults_config = created_defaults
        self._defaults = OmegaConf.create(OmegaConf.to_container(defaults_config, resolve=False))
        if not isinstance(self._defaults, DictConfig):
            raise ConfigError("defaults must be a mapping")
        OmegaConf.set_struct(self._defaults, True)
        self._allowed_env = dict(allowed_env or {})
        if len(set(self._allowed_env.values())) != len(self._allowed_env):
            raise ConfigError("allowed environment variables must map to unique config fields")

    @classmethod
    def from_package_defaults(
        cls,
        relative_path: str,
        *,
        allowed_env: Mapping[str, str] | None = None,
    ) -> ConfigLoader:
        resource = resources.files("asdepth.resources").joinpath(relative_path)
        if not resource.is_file():
            raise FileNotFoundError(relative_path)
        defaults = OmegaConf.create(resource.read_text(encoding="utf-8"))
        if not isinstance(defaults, DictConfig):
            raise ConfigError(f"package defaults {relative_path!r} must be a mapping")
        return cls(defaults, allowed_env=allowed_env)

    def load(
        self,
        *,
        files: Sequence[Path] = (),
        overrides: Sequence[str] = (),
        environ: Mapping[str, str] | None = None,
    ) -> ResolvedConfig:
        """应用 defaults < files < CLI dotlist < 显式环境变量。"""

        current = cast(DictConfig, OmegaConf.create(OmegaConf.to_container(self._defaults)))
        OmegaConf.set_struct(current, True)
        sources: list[str] = ["package-defaults"]

        for path in files:
            resolved_path = path.expanduser().resolve()
            if not resolved_path.is_file():
                raise FileNotFoundError(resolved_path)
            try:
                loaded = OmegaConf.load(resolved_path)
            except OmegaConfBaseException as exc:
                raise ConfigError(f"cannot load config {resolved_path}: {exc}") from exc
            if not isinstance(loaded, DictConfig):
                raise ConfigError(f"root config in {resolved_path} must be a mapping")
            incoming = loaded
            current = _merge_strict(current, incoming, source=str(resolved_path))
            sources.append(str(resolved_path))

        if overrides:
            current = _merge_strict(current, _dotlist(overrides, source="CLI"), source="CLI")
            sources.append("cli-overrides")

        active_environment = os.environ if environ is None else environ
        environment_dotlist = [
            f"{config_key}={active_environment[environment_name]}"
            for environment_name, config_key in self._allowed_env.items()
            if environment_name in active_environment
        ]
        if environment_dotlist:
            current = _merge_strict(
                current,
                _dotlist(environment_dotlist, source="environment"),
                source="environment",
            )
            sources.append("allowed-environment")

        try:
            OmegaConf.resolve(current)
        except OmegaConfBaseException as exc:
            raise ConfigError(f"cannot resolve config interpolation: {exc}") from exc
        digest = config_hash(current)
        OmegaConf.set_readonly(current, True)
        OmegaConf.set_struct(current, True)
        return ResolvedConfig(config=current, hash=digest, sources=tuple(sources))
