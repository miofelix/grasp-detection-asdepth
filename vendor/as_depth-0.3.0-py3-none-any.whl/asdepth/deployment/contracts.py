"""部署尺寸、固定 tensor 名称和产物布局契约。"""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from asdepth.core import ContractError, DepthRepresentation, ModelSpec, TensorSpec

PATCH_SIZE = 14
DEFAULT_OPSET = 18
DEFAULT_RESOLUTION_TEXT = "518x924"
INPUT_NAME = "rgbd_input"
OUTPUT_NAME = "depth"


@dataclass(frozen=True, order=True, slots=True)
class Resolution:
    """以 ``height x width`` 表示、与 DPT patch 对齐的固定分辨率。"""

    height: int
    width: int

    def __post_init__(self) -> None:
        if self.height <= 0 or self.width <= 0:
            raise ContractError("deployment resolution dimensions must be positive")
        if self.height % PATCH_SIZE or self.width % PATCH_SIZE:
            raise ContractError(
                f"deployment resolution must be divisible by patch size {PATCH_SIZE}: "
                f"{self.height}x{self.width}"
            )

    @classmethod
    def parse(cls, value: str) -> Resolution:
        match = re.fullmatch(r"\s*(\d+)\s*[xX*×]\s*(\d+)\s*", str(value))
        if match is None:
            raise ContractError(f"invalid deployment resolution {value!r}; expected HxW")
        return cls(int(match.group(1)), int(match.group(2)))

    @property
    def label(self) -> str:
        return f"{self.height}x{self.width}"

    @property
    def input_shape(self) -> tuple[int, int, int, int]:
        return (1, 4, self.height, self.width)

    @property
    def output_shape(self) -> tuple[int, int, int]:
        return (1, self.height, self.width)

    def to_json(self) -> dict[str, object]:
        return {
            "height": self.height,
            "width": self.width,
            "label": self.label,
            "input_shape": list(self.input_shape),
            "output_shape": list(self.output_shape),
        }


DEFAULT_RESOLUTION = Resolution.parse(DEFAULT_RESOLUTION_TEXT)


def parse_resolutions(
    values: Sequence[str | Resolution] | None,
) -> tuple[Resolution, ...]:
    raw_values: Sequence[str | Resolution] = values or (DEFAULT_RESOLUTION,)
    result: list[Resolution] = []
    seen: set[Resolution] = set()
    for raw in raw_values:
        value = raw if isinstance(raw, Resolution) else Resolution.parse(raw)
        if value not in seen:
            seen.add(value)
            result.append(value)
    if not result:
        raise ContractError("at least one deployment resolution is required")
    return tuple(result)


def deployment_tensor_specs(
    resolution: Resolution,
    *,
    dtype: str = "float32",
) -> tuple[tuple[TensorSpec, ...], tuple[TensorSpec, ...]]:
    return (
        (
            TensorSpec(
                INPUT_NAME,
                dtype,
                resolution.input_shape,
                layout="NCHW",
                semantic="normalized_rgb_plus_metric_depth",
            ),
        ),
        (
            TensorSpec(
                OUTPUT_NAME,
                dtype,
                resolution.output_shape,
                layout="NHW",
                semantic="metric_depth_meter",
            ),
        ),
    )


def require_deployable_model(model_spec: ModelSpec) -> None:
    """部署主线固定 metric meter、host preprocess、单输入和单输出。"""

    if model_spec.depth.representation is not DepthRepresentation.METRIC_DEPTH:
        raise ContractError(
            "deployment requires a model whose native output is metric_depth; "
            "inverse-depth compatibility conversion belongs to postprocessing"
        )
    if len(model_spec.inputs) != 1:
        raise ContractError("deployment requires exactly one model input")
    model_input = model_spec.inputs[0]
    if (
        model_input.name != INPUT_NAME
        or len(model_input.shape) != 4
        or model_input.shape[1] != 4
        or model_input.layout != "NCHW"
    ):
        raise ContractError(
            "deployment input must be host-preprocessed rgbd_input NCHW with four channels"
        )
    if len(model_spec.outputs) != 1:
        raise ContractError("deployment currently supports one metric depth output")


@dataclass(frozen=True, slots=True)
class DeploymentLayout:
    """一个部署目录内的可审计产物路径。"""

    root: Path
    model_path: Path
    manifest_path: Path
    benchmark_path: Path
    build_log_path: Path

    @classmethod
    def create(
        cls,
        root: str | Path,
        *,
        backend: str,
        resolution: Resolution,
    ) -> DeploymentLayout:
        resolved = Path(root).expanduser().resolve()
        suffix = {"onnx": ".onnx", "tensorrt": ".engine"}.get(backend)
        if suffix is None:
            raise ContractError(f"unsupported deployment backend {backend!r}")
        directory = resolved / backend / resolution.label
        return cls(
            root=resolved,
            model_path=directory / f"model{suffix}",
            manifest_path=directory / "manifest.json",
            benchmark_path=directory / "benchmark.json",
            build_log_path=directory / "build.log",
        )
