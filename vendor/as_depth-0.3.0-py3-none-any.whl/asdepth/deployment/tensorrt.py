"""trtexec 构建、版本探测和 TensorRT engine 契约检查。"""

from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from asdepth.artifacts import atomic_write_text
from asdepth.core import ContractError

from .contracts import INPUT_NAME, OUTPUT_NAME, Resolution


def tensorrt_major_from_version(value: str) -> int:
    """解析点分版本或 trtexec 的六位 NVIDIA 版本码。"""

    normalized = value.strip()
    if "." in normalized:
        head = normalized.split(".", 1)[0]
        if head.isdigit():
            return int(head)
    elif normalized.isdigit():
        if len(normalized) >= 6:
            return int(normalized[:2])
        return int(normalized[0])
    raise ValueError(f"unable to parse TensorRT version: {value!r}")


@dataclass(frozen=True, slots=True)
class TensorRTBuildConfig:
    trtexec_path: str = "trtexec"
    workspace_mib: int = 8192
    builder_optimization_level: int = 5
    profiling_verbosity: str = "detailed"

    def __post_init__(self) -> None:
        if self.workspace_mib <= 0:
            raise ContractError("TensorRT workspace_mib must be positive")
        if not 0 <= self.builder_optimization_level <= 5:
            raise ContractError("TensorRT builder optimization level must be in [0, 5]")
        if self.profiling_verbosity not in {"none", "layer_names_only", "detailed"}:
            raise ContractError("invalid TensorRT profiling verbosity")


def build_tensorrt_command(
    onnx_path: str | Path,
    engine_path: str | Path,
    *,
    timing_cache_path: str | Path,
    config: TensorRTBuildConfig | None = None,
) -> list[str]:
    active = config or TensorRTBuildConfig()
    return [
        active.trtexec_path,
        f"--onnx={Path(onnx_path).expanduser().resolve()}",
        f"--saveEngine={Path(engine_path).expanduser().resolve()}",
        f"--timingCacheFile={Path(timing_cache_path).expanduser().resolve()}",
        "--stronglyTyped",
        f"--builderOptimizationLevel={active.builder_optimization_level}",
        f"--memPoolSize=workspace:{active.workspace_mib}",
        f"--profilingVerbosity={active.profiling_verbosity}",
        "--skipInference",
    ]


def probe_trtexec(path: str = "trtexec") -> dict[str, Any]:
    executable = shutil.which(path) if not Path(path).is_absolute() else path
    if not executable or not Path(executable).is_file():
        raise FileNotFoundError(f"trtexec executable not found: {path}")
    completed = subprocess.run(
        [str(executable), "--help"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    output = completed.stdout or ""
    versions = re.findall(
        r"(?:TensorRT\.trtexec\s+\[TensorRT\s+v|TensorRT\s+(?:version:\s*|v))([0-9.]+)",
        output,
        flags=re.IGNORECASE,
    )
    if not versions:
        raise RuntimeError("unable to parse TensorRT version from trtexec output")
    version = versions[-1]
    command = [str(executable), "--help"]
    return {
        "path": str(Path(executable).resolve()),
        "version": version,
        "major": tensorrt_major_from_version(version),
        "command": command,
        "exit_code": completed.returncode,
        "banner": next(
            (line.strip() for line in output.splitlines() if "TensorRT" in line),
            "",
        ),
    }


def build_tensorrt(
    onnx_path: str | Path,
    engine_path: str | Path,
    *,
    timing_cache_path: str | Path | None = None,
    log_path: str | Path | None = None,
    config: TensorRTBuildConfig | None = None,
    overwrite: bool = False,
    dry_run: bool = False,
) -> Path | list[str]:
    source = Path(onnx_path).expanduser().resolve()
    target = Path(engine_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    if target.is_dir():
        raise IsADirectoryError(target)
    if target.exists() and not overwrite:
        raise FileExistsError(f"deployment artifact already exists: {target}")
    cache = (
        Path(timing_cache_path).expanduser().resolve()
        if timing_cache_path is not None
        else target.with_suffix(".timing.cache")
    )
    command = build_tensorrt_command(
        source,
        target,
        timing_cache_path=cache,
        config=config,
    )
    if dry_run:
        return command
    target.parent.mkdir(parents=True, exist_ok=True)
    completed = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        check=False,
    )
    output = completed.stdout or ""
    if log_path is not None:
        atomic_write_text(
            Path(log_path).expanduser().resolve(),
            output,
            overwrite=overwrite,
        )
    if completed.returncode != 0:
        raise RuntimeError(f"trtexec failed with exit code {completed.returncode}")
    if not target.is_file():
        raise RuntimeError(f"trtexec did not create engine: {target}")
    return target


def inspect_tensorrt_engine(
    engine_path: str | Path,
    *,
    resolution: Resolution,
    dtype: str | None = None,
) -> dict[str, Any]:
    try:
        import tensorrt as trt
    except ImportError as exc:
        raise RuntimeError("TensorRT engine inspection requires Python bindings") from exc
    path = Path(engine_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    logger = trt.Logger(trt.Logger.WARNING)
    runtime = trt.Runtime(logger)
    engine = runtime.deserialize_cuda_engine(path.read_bytes())
    if engine is None:
        raise RuntimeError(f"failed to deserialize TensorRT engine: {path}")
    records: list[dict[str, Any]] = []
    for index in range(engine.num_io_tensors):
        name = engine.get_tensor_name(index)
        mode = engine.get_tensor_mode(name)
        records.append(
            {
                "name": name,
                "mode": "input" if mode == trt.TensorIOMode.INPUT else "output",
                "shape": [int(value) for value in engine.get_tensor_shape(name)],
                "dtype": str(engine.get_tensor_dtype(name)),
            }
        )
    expected = [
        {"name": INPUT_NAME, "mode": "input", "shape": list(resolution.input_shape)},
        {"name": OUTPUT_NAME, "mode": "output", "shape": list(resolution.output_shape)},
    ]
    actual = [{key: item[key] for key in ("name", "mode", "shape")} for item in records]
    if actual != expected:
        raise ContractError(f"TensorRT engine IO contract mismatch: {actual}")
    if dtype is not None:
        expected_dtype = {"float16": "HALF", "float32": "FLOAT"}.get(dtype)
        if expected_dtype is None:
            raise ContractError(f"unsupported TensorRT IO dtype contract: {dtype!r}")
        mismatches = [item for item in records if expected_dtype not in str(item["dtype"]).upper()]
        if mismatches:
            raise ContractError(
                f"TensorRT engine IO dtype mismatch: expected={dtype}, actual={records}"
            )
    return {
        "path": str(path),
        "io_tensors": records,
        "num_layers": int(engine.num_layers),
        "serialized_size_bytes": path.stat().st_size,
    }
