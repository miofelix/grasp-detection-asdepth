"""ONNX、TensorRT 与 DeploymentManifest 的正式部署 API。"""

from .benchmark import BenchmarkReport, benchmark_runtime, parse_trtexec_summary
from .contracts import (
    DEFAULT_OPSET,
    DEFAULT_RESOLUTION,
    DEFAULT_RESOLUTION_TEXT,
    INPUT_NAME,
    OUTPUT_NAME,
    DeploymentLayout,
    Resolution,
    deployment_tensor_specs,
    parse_resolutions,
)
from .onnx import convert_onnx_fp16, export_onnx, inspect_onnx, verify_onnx
from .service import (
    create_deployment_manifest,
    load_deployment_manifest,
    write_deployment_manifest,
)
from .tensorrt import (
    TensorRTBuildConfig,
    build_tensorrt,
    build_tensorrt_command,
    inspect_tensorrt_engine,
    probe_trtexec,
    tensorrt_major_from_version,
)

__all__ = [
    "DEFAULT_OPSET",
    "DEFAULT_RESOLUTION",
    "DEFAULT_RESOLUTION_TEXT",
    "INPUT_NAME",
    "OUTPUT_NAME",
    "BenchmarkReport",
    "DeploymentLayout",
    "Resolution",
    "TensorRTBuildConfig",
    "benchmark_runtime",
    "build_tensorrt",
    "build_tensorrt_command",
    "convert_onnx_fp16",
    "create_deployment_manifest",
    "deployment_tensor_specs",
    "export_onnx",
    "inspect_onnx",
    "inspect_tensorrt_engine",
    "load_deployment_manifest",
    "parse_resolutions",
    "parse_trtexec_summary",
    "probe_trtexec",
    "tensorrt_major_from_version",
    "verify_onnx",
    "write_deployment_manifest",
]
