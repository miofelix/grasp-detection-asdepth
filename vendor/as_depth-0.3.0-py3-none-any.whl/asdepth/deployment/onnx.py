"""Canonical PyTorch → ONNX 导出、图检查和可选数值验证。"""

from __future__ import annotations

import tempfile
from collections import Counter
from collections.abc import Mapping
from pathlib import Path
from typing import Any

import numpy as np
import torch

from asdepth.artifacts import atomic_write_json, sha256_file
from asdepth.core import ContractError, ModelSpec

from .contracts import (
    DEFAULT_OPSET,
    INPUT_NAME,
    OUTPUT_NAME,
    Resolution,
    require_deployable_model,
)


def _require_onnx() -> Any:
    try:
        import onnx
    except ImportError as exc:
        raise RuntimeError(
            "ONNX export requires the 'export' extra: pip install 'as-depth[export]'"
        ) from exc
    return onnx


def _guard_output(path: Path, *, overwrite: bool) -> None:
    if path.is_dir():
        raise IsADirectoryError(path)
    if path.exists() and not overwrite:
        raise FileExistsError(f"deployment artifact already exists: {path}")


def _primary_output(value: Any) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        return value
    if isinstance(value, Mapping):
        candidate = value.get("depth")
        if candidate is None:
            candidate = value.get("metric_depth")
        if isinstance(candidate, torch.Tensor):
            return candidate
    if isinstance(value, tuple | list) and value and isinstance(value[0], torch.Tensor):
        return value[0]
    raise ContractError("model output cannot be reduced to one depth tensor for deployment")


class _DepthOnly(torch.nn.Module):
    def __init__(self, model: torch.nn.Module) -> None:
        super().__init__()
        self.model = model

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return _primary_output(self.model(inputs))


def export_onnx(
    model: torch.nn.Module,
    model_spec: ModelSpec,
    output_path: str | Path,
    *,
    resolution: Resolution,
    opset: int = DEFAULT_OPSET,
    device: str | torch.device = "cpu",
    dynamic_batch: bool = False,
    overwrite: bool = False,
    verify: bool = True,
) -> Path:
    """导出 host-preprocess 单输入、metric depth 单输出 ONNX。"""

    require_deployable_model(model_spec)
    if opset < 14:
        raise ContractError("ONNX opset must be at least 14")
    onnx = _require_onnx()
    target = Path(output_path).expanduser().resolve()
    external = target.with_name(target.stem + ".onnx.data")
    _guard_output(target, overwrite=overwrite)
    _guard_output(external, overwrite=overwrite)
    target.parent.mkdir(parents=True, exist_ok=True)

    active_device = torch.device(device)
    wrapper = _DepthOnly(model).to(active_device).eval()
    dummy = torch.zeros(resolution.input_shape, dtype=torch.float32, device=active_device)
    dynamic_axes = {INPUT_NAME: {0: "N"}, OUTPUT_NAME: {0: "N"}} if dynamic_batch else None
    with tempfile.TemporaryDirectory(prefix="asdepth-onnx-") as temporary:
        temporary_path = Path(temporary) / "model.onnx"
        torch.onnx.export(
            wrapper,
            (dummy,),
            str(temporary_path),
            input_names=[INPUT_NAME],
            output_names=[OUTPUT_NAME],
            dynamic_axes=dynamic_axes,
            opset_version=opset,
            do_constant_folding=True,
        )
        exported = onnx.load(str(temporary_path), load_external_data=True)

    from onnx.external_data_helper import convert_model_to_external_data

    convert_model_to_external_data(
        exported,
        all_tensors_to_one_file=True,
        location=external.name,
        size_threshold=1024,
        convert_attribute=True,
    )
    onnx.save(exported, str(target))
    if verify:
        inspect_onnx(target, expected_model=model_spec, resolution=resolution, opset=opset)
    return target


def _shape(value: Any) -> tuple[int | str, ...]:
    result: list[int | str] = []
    for dimension in value.type.tensor_type.shape.dim:
        if dimension.HasField("dim_value"):
            result.append(int(dimension.dim_value))
        elif dimension.HasField("dim_param"):
            result.append(str(dimension.dim_param))
        else:
            result.append("?")
    return tuple(result)


def inspect_onnx(
    path: str | Path,
    *,
    expected_model: ModelSpec | None = None,
    resolution: Resolution | None = None,
    opset: int | None = None,
    dtype: str = "FLOAT",
) -> dict[str, Any]:
    """检查 ONNX 图并可选冻结单输入/单输出 tensor 契约。"""

    onnx = _require_onnx()
    model_path = Path(path).expanduser().resolve()
    if not model_path.is_file():
        raise FileNotFoundError(model_path)
    onnx.checker.check_model(str(model_path), full_check=False)
    model = onnx.load(str(model_path), load_external_data=False)
    initializer_names = {item.name for item in model.graph.initializer}
    inputs = [item for item in model.graph.input if item.name not in initializer_names]
    outputs = list(model.graph.output)

    def record(value: Any) -> dict[str, Any]:
        dtype_id = int(value.type.tensor_type.elem_type)
        return {
            "name": value.name,
            "shape": list(_shape(value)),
            "dtype": onnx.TensorProto.DataType.Name(dtype_id),
        }

    record_inputs = [record(item) for item in inputs]
    record_outputs = [record(item) for item in outputs]
    model_opset = next(
        (int(item.version) for item in model.opset_import if not item.domain),
        None,
    )
    if opset is not None and model_opset != opset:
        raise ContractError(f"ONNX opset mismatch: expected={opset}, actual={model_opset}")
    if expected_model is not None:
        require_deployable_model(expected_model)
    if resolution is not None:
        expected_inputs = [
            {"name": INPUT_NAME, "shape": list(resolution.input_shape), "dtype": dtype}
        ]
        expected_outputs = [
            {"name": OUTPUT_NAME, "shape": list(resolution.output_shape), "dtype": dtype}
        ]
        if record_inputs != expected_inputs or record_outputs != expected_outputs:
            raise ContractError(
                f"ONNX tensor contract mismatch: inputs={record_inputs}, outputs={record_outputs}"
            )
    dtype_counts = Counter(
        onnx.TensorProto.DataType.Name(int(item.data_type)) for item in model.graph.initializer
    )
    return {
        "path": str(model_path),
        "sha256": sha256_file(model_path),
        "opset": model_opset,
        "inputs": record_inputs,
        "outputs": record_outputs,
        "node_count": len(model.graph.node),
        "initializer_count": len(model.graph.initializer),
        "initializer_dtype_counts": dict(sorted(dtype_counts.items())),
    }


def convert_onnx_fp16(
    source_path: str | Path,
    output_path: str | Path,
    *,
    resolution: Resolution,
    opset: int = DEFAULT_OPSET,
    overwrite: bool = False,
) -> Path:
    """将 FP32 图显式转为 FP16 IO/权重，并保留必要 Cast 边界。"""

    try:
        import onnx
        from onnx.external_data_helper import convert_model_to_external_data
        from onnxruntime.transformers.float16 import convert_float_to_float16
    except ImportError as exc:
        raise RuntimeError("FP16 conversion requires onnx and onnxruntime") from exc
    source = Path(source_path).expanduser().resolve()
    target = Path(output_path).expanduser().resolve()
    external = target.with_name(target.stem + ".onnx.data")
    if not source.is_file():
        raise FileNotFoundError(source)
    _guard_output(target, overwrite=overwrite)
    _guard_output(external, overwrite=overwrite)
    target.parent.mkdir(parents=True, exist_ok=True)
    model = onnx.load(str(source), load_external_data=True)
    converted = convert_float_to_float16(
        model,
        keep_io_types=False,
        disable_shape_infer=True,
        force_fp16_initializers=False,
    )
    convert_model_to_external_data(
        converted,
        all_tensors_to_one_file=True,
        location=external.name,
        size_threshold=1024,
        convert_attribute=True,
    )
    onnx.save_model(converted, str(target))
    inspect_onnx(target, resolution=resolution, opset=opset, dtype="FLOAT16")
    return target


def verify_onnx(
    path: str | Path,
    model: torch.nn.Module,
    *,
    resolution: Resolution,
    device: str | torch.device = "cpu",
    rtol: float = 1e-4,
    atol: float = 1e-5,
) -> dict[str, float | bool]:
    """用确定性输入对比 Torch 与 ONNX Runtime 数值。"""

    try:
        import onnxruntime as ort
    except ImportError as exc:
        raise RuntimeError(
            "ONNX verification requires onnxruntime from the 'export' extra"
        ) from exc
    rng = np.random.default_rng(20260812)
    values = rng.normal(0.0, 0.5, resolution.input_shape).astype(np.float32)
    values[:, 3] = rng.uniform(0.1, 6.0, (1, resolution.height, resolution.width))
    active_device = torch.device(device)
    wrapper = _DepthOnly(model).to(active_device).eval()
    with torch.inference_mode():
        torch_output = wrapper(torch.from_numpy(values).to(active_device)).detach().cpu().numpy()
    session = ort.InferenceSession(
        str(Path(path).expanduser().resolve()),
        providers=["CPUExecutionProvider"],
    )
    ort_output = session.run([OUTPUT_NAME], {INPUT_NAME: values})[0]
    maximum = float(np.max(np.abs(torch_output - ort_output)))
    passed = bool(np.allclose(torch_output, ort_output, rtol=rtol, atol=atol))
    return {"passed": passed, "max_abs_error": maximum, "rtol": rtol, "atol": atol}


def write_onnx_report(path: Path, payload: dict[str, Any], *, overwrite: bool = False) -> Path:
    return atomic_write_json(path, payload, overwrite=overwrite)
