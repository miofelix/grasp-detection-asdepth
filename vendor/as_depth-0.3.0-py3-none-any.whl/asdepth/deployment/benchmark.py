"""统一 runtime benchmark 的确定性统计。"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from statistics import median
from types import MappingProxyType
from typing import Any

import numpy as np

from asdepth.core import ContractError
from asdepth.runtime import RuntimeBackend

from .contracts import Resolution

_TRT_NUMBER = r"[0-9]+(?:\.[0-9]+)?"


def _parse_trtexec_summary_line(output: str, label: str) -> dict[str, float]:
    pattern = re.compile(
        rf"^{re.escape(label)}:\s*"
        rf"min\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"max\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"mean\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"median\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"percentile\(90%\)\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"percentile\(95%\)\s*=\s*({_TRT_NUMBER})\s*ms,\s*"
        rf"percentile\(99%\)\s*=\s*({_TRT_NUMBER})\s*ms",
        flags=re.IGNORECASE,
    )
    matches: list[tuple[str, ...]] = []
    for line in output.splitlines():
        payload = line.rsplit("[I]", maxsplit=1)[-1].strip()
        match = pattern.search(payload)
        if match is not None:
            matches.append(match.groups())
    if not matches:
        raise RuntimeError(f"无法从 trtexec 日志解析 {label}")
    keys = (
        "min_ms",
        "max_ms",
        "mean_ms",
        "median_ms",
        "p90_ms",
        "p95_ms",
        "p99_ms",
    )
    return dict(zip(keys, (float(value) for value in matches[-1]), strict=True))


def parse_trtexec_summary(output: str) -> dict[str, object]:
    """解析 ``trtexec`` 最后一组吞吐、延迟和 GPU 统计。"""

    throughput_matches = re.findall(
        rf"Throughput:\s*({_TRT_NUMBER})\s*qps",
        output,
        flags=re.IGNORECASE,
    )
    if not throughput_matches:
        raise RuntimeError("无法从 trtexec 日志解析 Throughput")
    walltime_matches = re.findall(
        rf"Total Host Walltime:\s*({_TRT_NUMBER})\s*s",
        output,
        flags=re.IGNORECASE,
    )
    gpu_total_matches = re.findall(
        rf"Total GPU Compute Time:\s*({_TRT_NUMBER})\s*s",
        output,
        flags=re.IGNORECASE,
    )
    return {
        "fps": float(throughput_matches[-1]),
        "latency": _parse_trtexec_summary_line(output, "Latency"),
        "enqueue_time": _parse_trtexec_summary_line(output, "Enqueue Time"),
        "gpu_compute_time": _parse_trtexec_summary_line(output, "GPU Compute Time"),
        "total_host_walltime_sec": (float(walltime_matches[-1]) if walltime_matches else None),
        "total_gpu_compute_sec": (float(gpu_total_matches[-1]) if gpu_total_matches else None),
    }


@dataclass(frozen=True, slots=True)
class BenchmarkReport:
    backend: str
    warmup: int
    iterations: int
    median_ms: float
    mean_ms: float
    p95_ms: float
    throughput_fps: float
    timings_ms: tuple[float, ...]
    metadata: MappingProxyType[str, Any] = field(default_factory=lambda: MappingProxyType({}))


def benchmark_runtime(
    runtime: RuntimeBackend,
    *,
    resolution: Resolution,
    warmup: int = 5,
    iterations: int = 20,
    seed: int = 20260812,
) -> BenchmarkReport:
    if warmup < 0 or iterations <= 0:
        raise ContractError("benchmark warmup must be non-negative and iterations positive")
    rng = np.random.default_rng(seed)
    inputs = rng.normal(0.0, 0.5, resolution.input_shape).astype(np.float32)
    inputs[:, 3] = rng.uniform(0.1, 6.0, (1, resolution.height, resolution.width))
    for _ in range(warmup):
        runtime.infer(inputs)
    timings: list[float] = []
    for _ in range(iterations):
        started = time.perf_counter()
        runtime.infer(inputs)
        timings.append((time.perf_counter() - started) * 1000.0)
    values = np.asarray(timings, dtype=np.float64)
    median_ms = float(median(timings))
    return BenchmarkReport(
        backend=type(runtime).__name__,
        warmup=warmup,
        iterations=iterations,
        median_ms=median_ms,
        mean_ms=float(values.mean()),
        p95_ms=float(np.percentile(values, 95)),
        throughput_fps=1000.0 / median_ms if median_ms > 0 else float("inf"),
        timings_ms=tuple(timings),
        metadata=MappingProxyType({"resolution": resolution.label, "seed": seed}),
    )
