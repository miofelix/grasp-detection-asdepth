"""脚本说明：
作用：通过 canonical checkpoint/model 身份导出 ONNX，或从 ONNX 构建 TensorRT engine。

典型用法：
    asdepth export --checkpoint ckpts/asdepth2.ckpt --model defm_stackconv_depth \
        --resolution 518x924 --output runs/deploy/model.onnx
    asdepth deploy --onnx runs/deploy/model.onnx --output runs/deploy/model.engine \
        --resolution 518x924 --dry-run

参数说明：
    - export 只接受 host preprocess 的单输入 rgbd_input 与 metric depth 模型。
    - deploy 使用 TensorRT Strongly Typed 构建；--dry-run 只输出命令。

环境变量/外部依赖：
    - ONNX 导出/检查需要 `as-depth[export]`；TensorRT 由部署机系统提供。

运行注意：
    - 默认拒绝覆盖精确文件；旧 embedded 双输入导出不进入本入口。
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import torch

from asdepth.artifacts import sha256_file
from asdepth.core import ContractError
from asdepth.models import load_model_with_report

from .contracts import DEFAULT_OPSET, DEFAULT_RESOLUTION_TEXT, Resolution
from .onnx import convert_onnx_fp16, export_onnx, inspect_onnx, verify_onnx
from .service import create_deployment_manifest, write_deployment_manifest
from .tensorrt import (
    TensorRTBuildConfig,
    build_tensorrt,
    build_tensorrt_command,
    inspect_tensorrt_engine,
    probe_trtexec,
)


def _device(value: str) -> torch.device:
    if value != "auto":
        return torch.device(value)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _export_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth export",
        description="从 canonical checkpoint 导出 host-preprocess ONNX",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--checkpoint", "--ckpt-path", "--ckpt_path", required=True)
    parser.add_argument("--model", dest="model_id")
    parser.add_argument("--output", "--output-path", "--output_path", required=True)
    parser.add_argument("--resolution", default=DEFAULT_RESOLUTION_TEXT)
    parser.add_argument("--input-height", "--input_height", type=int)
    parser.add_argument("--input-width", "--input_width", type=int)
    parser.add_argument("--opset", type=int, default=DEFAULT_OPSET)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--dynamic-batch", action="store_true")
    parser.add_argument("--verify-runtime", action="store_true")
    parser.add_argument("--no-graph-check", action="store_true")
    parser.add_argument("--trusted-pickle", action="store_true")
    parser.add_argument("--no-verify-checksums", action="store_true")
    parser.add_argument("--overwrite", "--force", action="store_true")
    return parser


def _deploy_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth deploy",
        description="从 ONNX 构建 TensorRT engine 与 DeploymentManifest",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--onnx", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--manifest")
    parser.add_argument("--model", dest="model_id", required=True)
    parser.add_argument("--resolution", default=DEFAULT_RESOLUTION_TEXT)
    parser.add_argument("--trtexec", default="trtexec")
    parser.add_argument("--workspace-mib", type=int, default=8192)
    parser.add_argument("--builder-optimization-level", type=int, default=5)
    parser.add_argument(
        "--profiling-verbosity",
        choices=["none", "layer_names_only", "detailed"],
        default="detailed",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--inspect-engine", action="store_true")
    parser.add_argument("--keep-fp32-onnx", action="store_true")
    parser.add_argument("--overwrite", "--force", action="store_true")
    return parser


def _export_resolution(args: argparse.Namespace) -> Resolution:
    if (args.input_height is None) != (args.input_width is None):
        raise ContractError("--input-height and --input-width must be provided together")
    if args.input_height is not None:
        assert args.input_width is not None
        return Resolution(args.input_height, args.input_width)
    return Resolution.parse(args.resolution)


def export_main(argv: Sequence[str] | None = None) -> int:
    parser = _export_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    try:
        resolution = _export_resolution(args)
        device = _device(args.device)
        report = load_model_with_report(
            args.checkpoint,
            model_id=args.model_id,
            device=device,
            verify_checksums=not args.no_verify_checksums,
            trusted_pickle=args.trusted_pickle,
        )
        output = export_onnx(
            report.model,
            report.spec,
            args.output,
            resolution=resolution,
            opset=args.opset,
            device=device,
            dynamic_batch=args.dynamic_batch,
            overwrite=args.overwrite,
            verify=not args.no_graph_check,
        )
        inspection = inspect_onnx(
            output,
            expected_model=report.spec,
            resolution=None if args.dynamic_batch else resolution,
            opset=args.opset,
        )
        runtime_check: dict[str, float | bool] | None = None
        if args.verify_runtime:
            runtime_check = verify_onnx(
                output,
                report.model,
                resolution=resolution,
                device=device,
            )
            if not bool(runtime_check["passed"]):
                raise ContractError(f"ONNX numerical verification failed: {runtime_check}")
        manifest = create_deployment_manifest(
            deployment_id=f"{report.spec.model_id}-onnx-{resolution.label}",
            model_spec=report.spec,
            backend="onnx",
            precision="float32",
            resolution=resolution,
            artifact_root=output.parent,
            artifacts={"model": output},
            platform_info={
                "opset": args.opset,
                "dynamic_batch": args.dynamic_batch,
                "graph": {key: value for key, value in inspection.items() if key != "path"},
                "runtime_verification": runtime_check,
            },
        )
        manifest_path = output.with_name(output.stem + ".manifest.json")
        write_deployment_manifest(manifest_path, manifest, overwrite=args.overwrite)
    except (ContractError, FileExistsError, FileNotFoundError, RuntimeError) as exc:
        parser.error(str(exc))
    print(
        json.dumps(
            {"model": str(output), "manifest": str(manifest_path)},
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


def deploy_main(argv: Sequence[str] | None = None) -> int:
    parser = _deploy_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    try:
        from asdepth.models import ModelCatalog

        model_spec = ModelCatalog.from_package().get(args.model_id).to_model_spec()
        resolution = Resolution.parse(args.resolution)
        source = Path(args.onnx).expanduser().resolve()
        target = Path(args.output).expanduser().resolve()
        config = TensorRTBuildConfig(
            trtexec_path=args.trtexec,
            workspace_mib=args.workspace_mib,
            builder_optimization_level=args.builder_optimization_level,
            profiling_verbosity=args.profiling_verbosity,
        )
        build_source = source if args.keep_fp32_onnx else target.with_suffix(".fp16.onnx")
        build_precision = "float32" if args.keep_fp32_onnx else "float16"
        if args.dry_run:
            if not source.is_file():
                raise FileNotFoundError(source)
            command = build_tensorrt_command(
                build_source,
                target,
                timing_cache_path=target.with_suffix(".timing.cache"),
                config=config,
            )
            conversion = None
            if not args.keep_fp32_onnx:
                conversion = {
                    "source": str(source),
                    "output": str(build_source),
                    "precision": "float16",
                }
            print(
                json.dumps(
                    {
                        "conversion": conversion,
                        "build_onnx": str(build_source),
                        "precision": build_precision,
                        "command": command,
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        trtexec = probe_trtexec(args.trtexec)
        if not args.keep_fp32_onnx:
            convert_onnx_fp16(
                source,
                build_source,
                resolution=resolution,
                overwrite=args.overwrite,
            )
        engine = build_tensorrt(
            build_source,
            target,
            log_path=target.with_suffix(".build.log"),
            config=config,
            overwrite=args.overwrite,
        )
        assert isinstance(engine, Path)
        inspection: dict[str, Any] | None = None
        if args.inspect_engine:
            inspection = inspect_tensorrt_engine(
                engine,
                resolution=resolution,
                dtype=build_precision,
            )
        manifest = create_deployment_manifest(
            deployment_id=f"{model_spec.model_id}-tensorrt-{resolution.label}",
            model_spec=model_spec,
            backend="tensorrt",
            precision=build_precision,
            resolution=resolution,
            artifact_root=engine.parent,
            artifacts={"model": engine},
            platform_info={
                "trtexec": trtexec,
                "source_onnx": {"name": source.name, "sha256": sha256_file(source)},
                "build_onnx": {
                    "name": build_source.name,
                    "sha256": sha256_file(build_source),
                    "precision": build_precision,
                },
                "engine_inspection": inspection,
            },
        )
        manifest_path = (
            Path(args.manifest).expanduser().resolve()
            if args.manifest
            else engine.with_name(engine.stem + ".manifest.json")
        )
        write_deployment_manifest(manifest_path, manifest, overwrite=args.overwrite)
    except (ContractError, FileExistsError, FileNotFoundError, RuntimeError) as exc:
        parser.error(str(exc))
    print(
        json.dumps(
            {"engine": str(engine), "manifest": str(manifest_path)},
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0
