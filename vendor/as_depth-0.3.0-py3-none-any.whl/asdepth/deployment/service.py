"""DeploymentManifest 生成、落盘和加载。"""

from __future__ import annotations

import json
import platform
from pathlib import Path
from types import MappingProxyType
from typing import Any

from asdepth.artifacts import (
    DeploymentManifest,
    atomic_write_json,
    serialize_relative_path,
    sha256_file,
    utc_now,
    validate_manifest,
)
from asdepth.core import ModelSpec
from asdepth.core.serialization import frozen_mapping

from .contracts import Resolution, deployment_tensor_specs


def create_deployment_manifest(
    *,
    deployment_id: str,
    model_spec: ModelSpec,
    backend: str,
    precision: str,
    resolution: Resolution,
    artifact_root: str | Path,
    artifacts: dict[str, str | Path],
    platform_info: dict[str, Any] | None = None,
) -> DeploymentManifest:
    root = Path(artifact_root).expanduser().resolve()
    serialized = {
        name: serialize_relative_path(root, Path(path)) for name, path in artifacts.items()
    }
    checksums = {
        name: sha256_file(root / relative)
        for name, relative in serialized.items()
        if (root / relative).is_file()
    }
    dtype = "float16" if precision == "float16" else "float32"
    inputs, outputs = deployment_tensor_specs(resolution, dtype=dtype)
    environment = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "resolution": resolution.label,
        **(platform_info or {}),
    }
    manifest = DeploymentManifest(
        deployment_id=deployment_id,
        created_at=utc_now(),
        model=model_spec,
        backend=backend,
        precision=precision,
        inputs=inputs,
        outputs=outputs,
        artifacts=MappingProxyType(serialized),
        checksums=MappingProxyType(checksums),
        platform=frozen_mapping(environment),
    )
    validate_manifest(manifest.to_dict(), "deployment")
    return manifest


def write_deployment_manifest(
    path: str | Path,
    manifest: DeploymentManifest,
    *,
    overwrite: bool = False,
) -> Path:
    validate_manifest(manifest.to_dict(), "deployment")
    return atomic_write_json(
        Path(path).expanduser().resolve(),
        manifest.to_dict(),
        overwrite=overwrite,
    )


def load_deployment_manifest(path: str | Path) -> DeploymentManifest:
    manifest_path = Path(path).expanduser().resolve()
    with manifest_path.open(encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ValueError("deployment manifest must be a JSON object")
    validate_manifest(payload, "deployment")
    return DeploymentManifest.from_dict(payload)
