"""Run、Prediction、Checkpoint 与 Deployment manifest。"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from types import MappingProxyType
from typing import Any, ClassVar, cast

from asdepth.core import ContractError, DepthSpec, ModelSpec, TensorSpec
from asdepth.core.serialization import (
    frozen_mapping,
    require_exact_keys,
    require_schema_version,
    to_primitive,
)

from .paths import validate_relative_path

_SHA256 = re.compile(r"^[0-9a-f]{64}$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _validate_hash(value: str, name: str) -> None:
    if not _SHA256.fullmatch(value):
        raise ContractError(f"{name} must be a lowercase SHA-256 digest")


def _freeze_string_mapping(
    value: dict[str, str] | MappingProxyType[str, str],
) -> MappingProxyType[str, str]:
    return MappingProxyType({str(key): str(item) for key, item in value.items()})


def _validate_relative_values(values: MappingProxyType[str, str], context: str) -> None:
    for name, value in values.items():
        try:
            validate_relative_path(value)
        except ValueError as exc:
            raise ContractError(f"invalid {context} path {name!r}: {value!r}") from exc


class CheckpointFormat(str, Enum):
    ENVELOPE = "envelope"
    ACCELERATE = "accelerate"
    LEGACY_CKPT = "legacy_ckpt"


@dataclass(frozen=True, slots=True)
class RunManifest:
    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    run_id: str
    task: str
    created_at: str
    config_hash: str
    status: str
    model: ModelSpec | None = None
    paths: MappingProxyType[str, str] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"RunManifest requires schema {self.SCHEMA_VERSION}")
        if not self.run_id or not self.task or not self.status:
            raise ContractError("run_id, task, and status are required")
        _validate_hash(self.config_hash, "config_hash")
        paths = _freeze_string_mapping(self.paths)
        _validate_relative_values(paths, "run")
        object.__setattr__(self, "paths", paths)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> RunManifest:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "run_id",
                "task",
                "created_at",
                "config_hash",
                "status",
                "model",
                "paths",
                "metadata",
            },
            context="RunManifest",
        )
        require_schema_version(payload, context="RunManifest")
        values = dict(payload)
        values["model"] = ModelSpec.from_dict(payload["model"]) if payload["model"] else None
        values["paths"] = _freeze_string_mapping(payload["paths"])
        values["metadata"] = frozen_mapping(payload["metadata"])
        return cls(**values)


@dataclass(frozen=True, slots=True)
class PredictionArtifact:
    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    artifact_id: str
    created_at: str
    model: ModelSpec
    depth: DepthSpec
    arrays_dir: str
    samples_file: str
    sample_count: int
    layout: str = "manifest"
    checksums: MappingProxyType[str, str] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"PredictionArtifact requires schema {self.SCHEMA_VERSION}")
        if not self.artifact_id or self.sample_count < 0:
            raise ContractError("artifact_id is required and sample_count cannot be negative")
        validate_relative_path(self.arrays_dir)
        validate_relative_path(self.samples_file)
        checksums = _freeze_string_mapping(self.checksums)
        for name, value in checksums.items():
            _validate_hash(value, f"checksums[{name!r}]")
        object.__setattr__(self, "checksums", checksums)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> PredictionArtifact:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "artifact_id",
                "created_at",
                "model",
                "depth",
                "arrays_dir",
                "samples_file",
                "sample_count",
                "layout",
                "checksums",
                "metadata",
            },
            context="PredictionArtifact",
        )
        require_schema_version(payload, context="PredictionArtifact")
        values = dict(payload)
        values["model"] = ModelSpec.from_dict(payload["model"])
        values["depth"] = DepthSpec.from_dict(payload["depth"])
        values["checksums"] = _freeze_string_mapping(payload["checksums"])
        values["metadata"] = frozen_mapping(payload["metadata"])
        return cls(**values)


@dataclass(frozen=True, slots=True)
class CheckpointEnvelope:
    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    checkpoint_format: CheckpointFormat
    model: ModelSpec
    depth: DepthSpec
    step: int
    config_hash: str
    files: MappingProxyType[str, str]
    checksums: MappingProxyType[str, str] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"CheckpointEnvelope requires schema {self.SCHEMA_VERSION}")
        if not isinstance(self.checkpoint_format, CheckpointFormat):
            object.__setattr__(self, "checkpoint_format", CheckpointFormat(self.checkpoint_format))
        if self.step < 0:
            raise ContractError("checkpoint step cannot be negative")
        _validate_hash(self.config_hash, "config_hash")
        if self.config_hash != self.model.config_hash:
            raise ContractError("checkpoint config_hash must match model.config_hash")
        if self.depth != self.model.depth:
            raise ContractError("checkpoint depth must match model.depth")
        files = _freeze_string_mapping(self.files)
        if "model" not in files:
            raise ContractError("checkpoint files must contain a model role")
        _validate_relative_values(files, "checkpoint")
        object.__setattr__(self, "files", files)
        checksums = _freeze_string_mapping(self.checksums)
        for name, value in checksums.items():
            _validate_hash(value, f"checksums[{name!r}]")
        object.__setattr__(self, "checksums", checksums)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> CheckpointEnvelope:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "checkpoint_format",
                "model",
                "depth",
                "step",
                "config_hash",
                "files",
                "checksums",
                "metadata",
            },
            context="CheckpointEnvelope",
        )
        require_schema_version(payload, context="CheckpointEnvelope")
        values = dict(payload)
        values["model"] = ModelSpec.from_dict(payload["model"])
        values["depth"] = DepthSpec.from_dict(payload["depth"])
        values["files"] = _freeze_string_mapping(payload["files"])
        values["checksums"] = _freeze_string_mapping(payload["checksums"])
        values["metadata"] = frozen_mapping(payload["metadata"])
        return cls(**values)


@dataclass(frozen=True, slots=True)
class DeploymentManifest:
    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    deployment_id: str
    created_at: str
    model: ModelSpec
    backend: str
    precision: str
    inputs: tuple[TensorSpec, ...]
    outputs: tuple[TensorSpec, ...]
    artifacts: MappingProxyType[str, str]
    checksums: MappingProxyType[str, str] = field(default_factory=lambda: MappingProxyType({}))
    platform: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"DeploymentManifest requires schema {self.SCHEMA_VERSION}")
        if not self.deployment_id or not self.backend or not self.precision:
            raise ContractError("deployment_id, backend, and precision are required")
        object.__setattr__(self, "inputs", tuple(self.inputs))
        object.__setattr__(self, "outputs", tuple(self.outputs))
        artifacts = _freeze_string_mapping(self.artifacts)
        if not artifacts:
            raise ContractError("deployment artifacts cannot be empty")
        _validate_relative_values(artifacts, "deployment")
        object.__setattr__(self, "artifacts", artifacts)
        checksums = _freeze_string_mapping(self.checksums)
        for name, value in checksums.items():
            _validate_hash(value, f"checksums[{name!r}]")
        object.__setattr__(self, "checksums", checksums)
        if not isinstance(self.platform, MappingProxyType):
            object.__setattr__(self, "platform", frozen_mapping(dict(self.platform)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> DeploymentManifest:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "deployment_id",
                "created_at",
                "model",
                "backend",
                "precision",
                "inputs",
                "outputs",
                "artifacts",
                "checksums",
                "platform",
            },
            context="DeploymentManifest",
        )
        require_schema_version(payload, context="DeploymentManifest")
        values = dict(payload)
        values["model"] = ModelSpec.from_dict(payload["model"])
        values["inputs"] = tuple(TensorSpec.from_dict(item) for item in payload["inputs"])
        values["outputs"] = tuple(TensorSpec.from_dict(item) for item in payload["outputs"])
        values["artifacts"] = _freeze_string_mapping(payload["artifacts"])
        values["checksums"] = _freeze_string_mapping(payload["checksums"])
        values["platform"] = frozen_mapping(payload["platform"])
        return cls(**values)
