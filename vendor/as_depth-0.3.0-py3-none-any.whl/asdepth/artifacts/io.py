"""带精确覆盖保护的原子 artifact 写入。"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

from asdepth.core import ArtifactExistsError


def _guard_target(path: Path, *, overwrite: bool) -> None:
    if path.is_dir():
        raise IsADirectoryError(f"artifact target is a directory: {path}")
    if path.exists() and not overwrite:
        raise ArtifactExistsError(f"artifact already exists: {path}")


def atomic_write_bytes(path: Path, value: bytes, *, overwrite: bool = False) -> Path:
    """同目录临时文件 + `os.replace`，并默认拒绝覆盖精确文件。"""

    target = path.expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    _guard_target(target, overwrite=overwrite)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        _guard_target(target, overwrite=overwrite)
        os.replace(temporary, target)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return target


def atomic_write_text(
    path: Path, value: str, *, encoding: str = "utf-8", overwrite: bool = False
) -> Path:
    return atomic_write_bytes(path, value.encode(encoding), overwrite=overwrite)


def atomic_write_json(path: Path, payload: dict[str, Any], *, overwrite: bool = False) -> Path:
    serialized = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    return atomic_write_text(path, serialized, overwrite=overwrite)
