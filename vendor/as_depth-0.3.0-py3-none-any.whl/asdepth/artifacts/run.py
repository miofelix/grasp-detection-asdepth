"""统一 `runs/<run_id>` 目录布局。"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from asdepth.core import ArtifactExistsError, ContractError

from .paths import validate_relative_path


@dataclass(frozen=True, slots=True)
class RunLayout:
    root: Path
    run_json: Path
    resolved_config: Path
    environment_json: Path
    logs: Path
    checkpoints: Path
    predictions: Path
    prediction_arrays: Path
    prediction_visualizations: Path
    metrics: Path
    deployment: Path


def create_run_layout(runs_root: Path, run_id: str) -> RunLayout:
    """创建全新 run；现有同名目录一律拒绝覆盖。"""

    if validate_relative_path(run_id).as_posix() != run_id or "/" in run_id:
        raise ContractError(f"run_id must be one safe path component, got {run_id!r}")
    root = runs_root.expanduser().resolve() / run_id
    if root.exists():
        raise ArtifactExistsError(f"run directory already exists: {root}")

    logs = root / "logs"
    checkpoints = root / "checkpoints"
    predictions = root / "predictions"
    prediction_arrays = predictions / "arrays"
    prediction_visualizations = predictions / "visualizations"
    metrics = root / "metrics"
    deployment = root / "deployment"
    for directory in (
        logs,
        checkpoints,
        prediction_arrays,
        prediction_visualizations,
        metrics,
        deployment,
    ):
        directory.mkdir(parents=True, exist_ok=False)

    return RunLayout(
        root=root,
        run_json=root / "run.json",
        resolved_config=root / "config.resolved.yaml",
        environment_json=root / "environment.json",
        logs=logs,
        checkpoints=checkpoints,
        predictions=predictions,
        prediction_arrays=prediction_arrays,
        prediction_visualizations=prediction_visualizations,
        metrics=metrics,
        deployment=deployment,
    )
