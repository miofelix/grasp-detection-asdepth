"""artifact 根目录内的安全路径解析。"""

from __future__ import annotations

from pathlib import Path, PurePosixPath

from asdepth.core import UnsafePathError


def validate_relative_path(value: str | Path) -> PurePosixPath:
    """拒绝绝对路径、空路径、`.` 与任何 `..` 穿越。"""

    text = Path(value).as_posix() if isinstance(value, Path) else str(value).replace("\\", "/")
    path = PurePosixPath(text)
    if (
        not text
        or text == "."
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise UnsafePathError(f"unsafe relative artifact path: {value!r}")
    return path


def safe_join(root: Path, relative: str | Path) -> Path:
    """在解析 symlink/`..` 后保证结果仍位于 root 内。"""

    normalized = validate_relative_path(relative)
    resolved_root = root.expanduser().resolve()
    candidate = resolved_root.joinpath(*normalized.parts).resolve()
    if not candidate.is_relative_to(resolved_root):
        raise UnsafePathError(f"artifact path escapes root {resolved_root}: {relative!r}")
    return candidate


def serialize_relative_path(root: Path, value: Path) -> str:
    """把 artifact 路径序列化为相对 POSIX 路径。"""

    resolved_root = root.expanduser().resolve()
    resolved_value = value.expanduser().resolve()
    try:
        relative = resolved_value.relative_to(resolved_root)
    except ValueError as exc:
        raise UnsafePathError(f"path {value} is outside artifact root {root}") from exc
    return validate_relative_path(relative).as_posix()
