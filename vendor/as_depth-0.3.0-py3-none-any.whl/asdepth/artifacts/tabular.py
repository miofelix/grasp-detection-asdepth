"""轻量 CSV 产物写入。"""

from __future__ import annotations

import csv
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Literal


def write_csv(
    path: str | Path,
    rows: Sequence[Mapping[str, Any]],
    fieldnames: Sequence[str] | None = None,
    *,
    encoding: str = "utf-8",
    extrasaction: Literal["raise", "ignore"] = "ignore",
) -> Path:
    """写入 CSV 并自动创建父目录；空 rows 仍写 header。"""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    columns = list(fieldnames) if fieldnames is not None else _collect_columns(rows)
    with target.open("w", encoding=encoding, newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=columns,
            extrasaction=extrasaction,
        )
        writer.writeheader()
        writer.writerows(rows)
    return target


def _collect_columns(rows: Sequence[Mapping[str, Any]]) -> list[str]:
    seen: set[str] = set()
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                columns.append(key)
    return columns


__all__ = ["write_csv"]
