"""工具层可复用的 JSON 写入适配。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from asdepth.core.serialization import to_primitive


def write_json(
    path: str | Path,
    payload: Any,
    *,
    default: Any | None = None,
    sort_keys: bool = False,
) -> Path:
    """写入 UTF-8 JSON，并显式支持 Path/dataclass/NumPy 标量。"""

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    normalized = to_primitive(payload) if default is None else payload
    target.write_text(
        json.dumps(
            normalized,
            ensure_ascii=False,
            indent=2,
            sort_keys=sort_keys,
            default=default,
        )
        + "\n",
        encoding="utf-8",
    )
    return target
