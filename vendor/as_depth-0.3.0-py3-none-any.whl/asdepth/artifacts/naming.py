"""产物目录与文件名的确定性清洗。"""

from __future__ import annotations

import re

from asdepth.core import ContractError


def validate_filename_component(value: str, *, field: str = "name") -> str:
    """验证值可安全拼入 artifact 相对路径，不执行有损清洗。"""

    if not value or value in {".", ".."} or "/" in value or "\\" in value or "\x00" in value:
        raise ContractError(f"{field} must be one safe filename component: {value!r}")
    return value


def sanitize_name(
    value: str,
    *,
    fallback: str = "sample",
    max_len: int | None = None,
) -> str:
    """把任意值清洗为只含 ``[A-Za-z0-9._-]`` 的稳定名称片段。"""

    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value)).strip("._-")
    if not safe:
        safe = fallback
    if max_len is not None:
        if max_len < 1:
            raise ValueError("max_len must be positive when set")
        safe = safe[:max_len]
    return safe


__all__ = ["sanitize_name", "validate_filename_component"]
