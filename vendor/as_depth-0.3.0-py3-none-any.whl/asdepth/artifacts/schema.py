"""定位并校验随发行包分发的 JSON Schema。"""

from __future__ import annotations

import json
from importlib import metadata
from pathlib import Path
from typing import Any, cast

import jsonschema

from asdepth.core import ContractError

SCHEMAS = {
    "checkpoint": "checkpoint-v1.schema.json",
    "dataset": "dataset-v1.schema.json",
    "deployment": "deployment-v1.schema.json",
    "model": "model-v1.schema.json",
    "prediction": "prediction-v1.schema.json",
    "run": "run-v1.schema.json",
}


def schema_path(name: str) -> Path:
    """同时支持源码 checkout、editable install 和普通 wheel。"""

    try:
        filename = SCHEMAS[name]
    except KeyError as exc:
        raise KeyError(f"unknown schema {name!r}; available: {sorted(SCHEMAS)}") from exc

    source_path = Path(__file__).resolve().parents[3] / "schemas" / filename
    if source_path.is_file():
        return source_path

    distribution = metadata.distribution("as-depth")
    suffix = f"share/asdepth/schemas/{filename}"
    for installed_file in distribution.files or ():
        if installed_file.as_posix().endswith(suffix):
            resolved = Path(str(distribution.locate_file(installed_file))).resolve()
            if resolved.is_file():
                return resolved
    raise FileNotFoundError(f"installed AS-Depth schema is missing: {filename}")


def load_schema(name: str) -> dict[str, Any]:
    with schema_path(name).open(encoding="utf-8") as stream:
        return cast(dict[str, Any], json.load(stream))


def validate_manifest(payload: dict[str, Any], schema: str) -> None:
    """使用 Draft 2020-12 校验并转换为领域错误。"""

    validator = jsonschema.Draft202012Validator(load_schema(schema))
    errors = sorted(validator.iter_errors(payload), key=lambda item: list(item.absolute_path))
    if errors:
        first = errors[0]
        location = ".".join(str(part) for part in first.absolute_path) or "<root>"
        raise ContractError(f"{schema} schema validation failed at {location}: {first.message}")
