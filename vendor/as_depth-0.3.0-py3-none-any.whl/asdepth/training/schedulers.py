"""训练 scheduler 的单一实现。"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch

from asdepth.core import ContractError


@dataclass(frozen=True, slots=True)
class WarmupCosineConfig:
    total_steps: int
    warmup_steps: int = 3_000
    min_factor: float = 0.0

    def __post_init__(self) -> None:
        if self.total_steps <= 0:
            raise ContractError("scheduler total_steps must be positive")
        if self.warmup_steps < 0 or self.warmup_steps > self.total_steps:
            raise ContractError("warmup_steps must be in [0, total_steps]")
        if not 0.0 <= self.min_factor <= 1.0:
            raise ContractError("scheduler min_factor must be in [0, 1]")


def warmup_cosine_factor(step: int, config: WarmupCosineConfig) -> float:
    """按 optimizer step 计算 warmup + cosine 因子。"""

    current = max(int(step), 0)
    if config.warmup_steps > 0 and current < config.warmup_steps:
        return float(current) / float(config.warmup_steps)
    decay_steps = config.total_steps - config.warmup_steps
    if decay_steps <= 0:
        return 1.0
    progress = min(max((current - config.warmup_steps) / decay_steps, 0.0), 1.0)
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    return config.min_factor + (1.0 - config.min_factor) * cosine


def create_warmup_cosine_scheduler(
    optimizer: torch.optim.Optimizer,
    config: WarmupCosineConfig,
) -> torch.optim.lr_scheduler.LambdaLR:
    return torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lr_lambda=lambda step: warmup_cosine_factor(step, config),
    )
