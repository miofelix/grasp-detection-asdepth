"""训练 callback 事件与组合器。"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass

from ..state import TrainingState


@dataclass(frozen=True, slots=True)
class StepEvent:
    state: TrainingState
    metrics: Mapping[str, float]
    learning_rates: tuple[float, ...]


class TrainingCallback:
    def on_start(self, state: TrainingState) -> None:
        del state

    def on_step(self, event: StepEvent) -> None:
        del event

    def on_end(self, state: TrainingState) -> None:
        del state


class CompositeCallback(TrainingCallback):
    def __init__(self, callbacks: Sequence[TrainingCallback] = ()) -> None:
        self.callbacks = tuple(callbacks)

    def on_start(self, state: TrainingState) -> None:
        for callback in self.callbacks:
            callback.on_start(state)

    def on_step(self, event: StepEvent) -> None:
        for callback in self.callbacks:
            callback.on_step(event)

    def on_end(self, state: TrainingState) -> None:
        for callback in reversed(self.callbacks):
            callback.on_end(state)


class CheckpointCallback(TrainingCallback):
    def __init__(
        self,
        interval: int,
        saver: Callable[[TrainingState], object],
    ) -> None:
        self.interval = int(interval)
        self.saver = saver

    def on_step(self, event: StepEvent) -> None:
        if self.interval > 0 and event.state.global_step % self.interval == 0:
            self.saver(event.state)
