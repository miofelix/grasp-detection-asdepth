"""标准 logging 与可选 W&B callback。"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any

from .base import StepEvent, TrainingCallback


class LoggingCallback(TrainingCallback):
    def __init__(
        self,
        *,
        interval: int = 100,
        logger: logging.Logger | None = None,
        enabled: bool = True,
    ) -> None:
        self.interval = int(interval)
        self.logger = logger or logging.getLogger("asdepth.training")
        self.enabled = enabled

    def on_step(self, event: StepEvent) -> None:
        if not self.enabled or self.interval <= 0:
            return
        if event.state.global_step % self.interval != 0:
            return
        metrics = " ".join(f"{name}={value:.6f}" for name, value in event.metrics.items())
        learning_rate = event.learning_rates[0] if event.learning_rates else 0.0
        self.logger.info(
            "step=%d micro_batches=%d lr=%.3e %s",
            event.state.global_step,
            event.state.micro_batches_seen,
            learning_rate,
            metrics,
        )


class WandbCallback(TrainingCallback):
    def __init__(
        self,
        *,
        project: str,
        name: str,
        config: Mapping[str, Any],
        enabled: bool = True,
        finish_on_end: bool = True,
    ) -> None:
        self.project = project
        self.name = name
        self.config = dict(config)
        self.enabled = enabled
        self.finish_on_end = finish_on_end
        self._wandb: Any | None = None

    def on_start(self, state: object) -> None:
        del state
        if not self.enabled:
            return
        try:
            import wandb
        except ImportError as exc:  # pragma: no cover - optional train dependency
            raise RuntimeError("W&B logging requires `as-depth[train]`") from exc
        self._wandb = wandb
        if getattr(wandb, "run", None) is None:
            wandb.init(project=self.project, name=self.name, config=self.config)

    def on_step(self, event: StepEvent) -> None:
        if self._wandb is None or getattr(self._wandb, "run", None) is None:
            return
        payload = {f"train/{name}": value for name, value in event.metrics.items()}
        for index, learning_rate in enumerate(event.learning_rates):
            payload[f"train/lr_group_{index}"] = learning_rate
        self._wandb.log(payload, step=event.state.global_step)

    def on_end(self, state: object) -> None:
        del state
        if (
            self.finish_on_end
            and self._wandb is not None
            and getattr(self._wandb, "run", None) is not None
        ):
            self._wandb.finish()
