"""训练服务、策略、状态与恢复 API。"""

from .backends import (
    AccelerateTrainingBackend,
    TorchTrainingBackend,
    TrainingBackend,
    create_training_backend,
)
from .checkpoint import CheckpointManager, SavedCheckpoint
from .engine import TrainingEngine
from .optimization import (
    OptimizationConfig,
    OptimizationProfile,
    ParameterGroupSummary,
    create_optimizer,
    create_parameter_groups,
)
from .resume import (
    ExactResumeUnavailable,
    ResumeError,
    ResumeMode,
    ResumeReport,
    load_initial_weights,
    restore_training_state,
)
from .service import TrainingResult, train
from .state import TrainingConfig, TrainingState
from .strategies import (
    DistillationStrategy,
    G2Loss,
    MultiTaskStrategy,
    StandardTrainingStrategy,
    StrategyResult,
    TrainingStrategy,
)

__all__ = [
    "AccelerateTrainingBackend",
    "CheckpointManager",
    "DistillationStrategy",
    "ExactResumeUnavailable",
    "G2Loss",
    "MultiTaskStrategy",
    "OptimizationConfig",
    "OptimizationProfile",
    "ParameterGroupSummary",
    "ResumeError",
    "ResumeMode",
    "ResumeReport",
    "SavedCheckpoint",
    "StandardTrainingStrategy",
    "StrategyResult",
    "TorchTrainingBackend",
    "TrainingBackend",
    "TrainingConfig",
    "TrainingEngine",
    "TrainingResult",
    "TrainingState",
    "TrainingStrategy",
    "create_optimizer",
    "create_parameter_groups",
    "create_training_backend",
    "load_initial_weights",
    "restore_training_state",
    "train",
]
