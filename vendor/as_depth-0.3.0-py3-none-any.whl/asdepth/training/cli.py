"""脚本说明：
作用：通过 canonical Model/Data/Training API 执行 WDS 训练。

典型用法：
    asdepth train --model defm_stackconv_depth --strategy standard \
        --tar-paths data/train-{000000..000010}.tar --dataset-ids hammer
    asdepth train --config configs/profiles/train-distillation.yaml \
        --teacher-checkpoint ckpts/teacher.ckpt --init-checkpoint ckpts/student.ckpt \
        --tar-paths data/train.tar --dataset-ids hiss

参数说明：
    - --resume/--resume-mode：统一 weights、fast、exact 恢复语义。
    - --is-disp：仅为旧调用兼容；解析后立即转为 DepthSpec 并校验模型身份。

环境变量/外部依赖：
    - WDS/Accelerate/W&B/Kornia 由 train extra 提供；重型训练通常在 CUDA 服务器执行。

运行注意：
    - exact resume 要求 canonical checkpoint 同时保存 RNG 与 stateful dataloader 游标；
      当前普通 WDS 流不提供游标时会明确报错，不会降级成 fast。
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal, cast

from asdepth.config import ConfigLoader, ResolvedConfig
from asdepth.core import ContractError, DepthSpec, ModelSpec
from asdepth.data import create_webdataset_dataloader
from asdepth.models import ModelCatalog, ModelFactory

from .backends import create_training_backend
from .callbacks import WandbCallback
from .optimization import OptimizationConfig, OptimizationProfile
from .resume import ResumeMode, load_initial_weights, load_prefixed_weights
from .schedulers import WarmupCosineConfig, create_warmup_cosine_scheduler
from .service import train
from .state import TrainingConfig, seed_everything
from .strategies import (
    DistillationStrategy,
    MultiTaskStrategy,
    StandardTrainingStrategy,
    TrainingStrategy,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth train",
        description="训练 canonical RGB-D 模型并写统一 run/checkpoint envelope",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--config", type=Path, action="append", default=[])
    parser.add_argument("--set", dest="dotlist", action="append", default=[])
    parser.add_argument("--model")
    parser.add_argument("--init-checkpoint", "--model-path", "--model_path")
    parser.add_argument("--strict-initialization", action="store_true", default=None)
    parser.add_argument("--strategy", choices=["standard", "distillation", "multitask"])
    parser.add_argument("--tar-paths", "--tar_paths", nargs="+")
    parser.add_argument("--dataset-ids", "--dataset-names", "--dataset_names", nargs="+")
    parser.add_argument("--input-size", "--input_size", type=int)
    parser.add_argument("--batch-size", "--batch_size", type=int)
    parser.add_argument("--num-workers", type=int)
    parser.add_argument("--shuffle", type=int)
    parser.add_argument("--drop-last", action="store_true", default=None)
    parser.add_argument("--error-policy", choices=["raise", "skip"])
    parser.add_argument("--total-steps", "--total_steps", type=int)
    parser.add_argument(
        "--gradient-accumulation-steps",
        "--gradient_accumulation_steps",
        type=int,
    )
    parser.add_argument("--max-grad-norm", "--max_grad_norm", type=float)
    parser.add_argument("--save-freq", "--save_freq", type=int)
    parser.add_argument("--loss-freq", "--loss_freq", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--encoder-lr", "--encoder_lr", type=float)
    parser.add_argument("--decoder-lr", "--decoder_lr", type=float)
    parser.add_argument("--rgb-encoder-lr", "--rgb_encoder_lr", type=float)
    parser.add_argument("--weight-decay", type=float)
    parser.add_argument("--warmup-steps", type=int)
    parser.add_argument(
        "--optimization-profile",
        choices=[profile.value for profile in OptimizationProfile],
    )
    parser.add_argument("--freeze-rgb", "--freeze_rgb", choices=["auto", "true", "false"])
    parser.add_argument("--rgb-backbone-checkpoint")
    parser.add_argument("--rgb-backbone-prefix")
    parser.add_argument("--depth-backbone-checkpoint")
    parser.add_argument("--teacher-model")
    parser.add_argument("--teacher-checkpoint")
    parser.add_argument("--distill-weight", "--distill_weight", type=float)
    parser.add_argument("--mask-loss-weight", type=float)
    parser.add_argument("--mask-target-key")
    parser.add_argument("--require-mask-target", action="store_true", default=None)
    parser.add_argument("--backend", choices=["auto", "torch", "accelerate"])
    parser.add_argument("--device")
    parser.add_argument("--mixed-precision", choices=["no", "fp16", "bf16"])
    parser.add_argument("--runs-root")
    parser.add_argument("--run-id")
    parser.add_argument("--run-dir", "--output")
    parser.add_argument("--resume")
    parser.add_argument("--resume-mode", choices=[mode.value for mode in ResumeMode])
    parser.add_argument("--resume_from", dest="resume_legacy")
    parser.add_argument("--is-disp", "--is_disp", choices=["auto", "true", "false"])
    parser.add_argument("--wandb", action="store_true", default=None)
    parser.add_argument("--wandb-project")
    parser.add_argument("--write-legacy-checkpoints", action="store_true", default=None)
    return parser


def _dot_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    if isinstance(value, list | tuple):
        return json.dumps(list(value), ensure_ascii=False)
    if isinstance(value, int | float):
        return str(value)
    return json.dumps(str(value), ensure_ascii=False)


def _argument_overrides(args: argparse.Namespace) -> list[str]:
    result = list(args.dotlist)

    def add(path: str, value: Any) -> None:
        if value is not None:
            result.append(f"{path}={_dot_value(value)}")

    add("model.id", args.model)
    add("model.initialization", args.init_checkpoint)
    add("model.strict_initialization", args.strict_initialization)
    add("training.strategy", args.strategy)
    add("data.sources", args.tar_paths)
    add("data.dataset_ids", args.dataset_ids)
    add("data.image_size", args.input_size)
    add("data.batch_size", args.batch_size)
    add("data.num_workers", args.num_workers)
    add("data.shuffle", args.shuffle)
    add("data.drop_last", args.drop_last)
    add("data.error_policy", args.error_policy)
    add("training.total_steps", args.total_steps)
    add("training.gradient_accumulation_steps", args.gradient_accumulation_steps)
    add("training.max_grad_norm", args.max_grad_norm)
    add("training.checkpoint_interval", args.save_freq)
    add("training.log_interval", args.loss_freq)
    add("training.seed", args.seed)
    add("optimization.encoder_lr", args.encoder_lr)
    add("optimization.decoder_lr", args.decoder_lr)
    add("optimization.rgb_encoder_lr", args.rgb_encoder_lr)
    add("optimization.weight_decay", args.weight_decay)
    add("optimization.warmup_steps", args.warmup_steps)
    add("optimization.profile", args.optimization_profile)
    if args.freeze_rgb not in {None, "auto"}:
        add("model.freeze_rgb", args.freeze_rgb == "true")
    add("model.rgb_backbone_checkpoint", args.rgb_backbone_checkpoint)
    add("model.rgb_backbone_prefix", args.rgb_backbone_prefix)
    add("model.depth_backbone_checkpoint", args.depth_backbone_checkpoint)
    add("teacher.id", args.teacher_model)
    add("teacher.checkpoint", args.teacher_checkpoint)
    add("distillation.weight", args.distill_weight)
    add("multitask.mask_loss_weight", args.mask_loss_weight)
    add("multitask.mask_target_key", args.mask_target_key)
    add("multitask.require_mask_target", args.require_mask_target)
    add("runtime.backend", args.backend)
    add("runtime.device", args.device)
    add("runtime.mixed_precision", args.mixed_precision)
    add("output.runs_root", args.runs_root)
    add("output.run_id", args.run_id)
    add("output.run_dir", args.run_dir)
    add("resume.path", args.resume or args.resume_legacy)
    add("resume.mode", args.resume_mode)
    if args.is_disp not in {None, "auto"}:
        add(
            "data.depth_representation",
            "inverse_depth" if args.is_disp == "true" else "metric_depth",
        )
    add("observability.wandb", args.wandb)
    add("observability.wandb_project", args.wandb_project)
    add("compatibility.write_legacy_checkpoints", args.write_legacy_checkpoints)
    return result


def resolve_config(args: argparse.Namespace) -> ResolvedConfig:
    loader = ConfigLoader.from_package_defaults(
        "defaults/training.yaml",
        allowed_env={
            "ASDEPTH_RUNS_ROOT": "output.runs_root",
            "ASDEPTH_TRAIN_BACKEND": "runtime.backend",
            "ASDEPTH_TRAIN_DEVICE": "runtime.device",
        },
    )
    return loader.load(files=args.config, overrides=_argument_overrides(args))


def _depth_from_config(value: str, fallback: DepthSpec) -> DepthSpec:
    if value == "auto":
        return fallback
    selected = DepthSpec.inverse() if value == "inverse_depth" else DepthSpec.metric()
    if selected != fallback:
        raise ContractError(
            "configured depth representation conflicts with model identity: "
            f"model={fallback.representation.value}, configured={selected.representation.value}"
        )
    return selected


def _create_model(config: dict[str, Any]) -> tuple[Any, ModelSpec]:
    catalog = ModelCatalog.from_package()
    entry = catalog.get(str(config["id"]))
    overrides: dict[str, Any] = {}
    if config.get("freeze_rgb") is not None:
        overrides["freeze_rgb"] = bool(config["freeze_rgb"])
    depth_checkpoint = config.get("depth_backbone_checkpoint")
    if depth_checkpoint:
        overrides["depth_pretrained"] = True
        overrides["depth_pretrained_path"] = str(depth_checkpoint)
    created = ModelFactory(catalog).create_with_spec(entry, **overrides)
    initialization = config.get("initialization")
    if initialization:
        load_initial_weights(
            created.model,
            str(initialization),
            strict=bool(config.get("strict_initialization", False)),
        )
    rgb_checkpoint = config.get("rgb_backbone_checkpoint")
    if rgb_checkpoint:
        backbone = getattr(created.model, "pretrained", None)
        if backbone is None:
            raise ContractError("selected model has no pretrained RGB backbone")
        load_prefixed_weights(
            backbone,
            str(rgb_checkpoint),
            prefix=str(config.get("rgb_backbone_prefix") or "model.backbone.pretrained."),
        )
    return created.model, created.spec


def _run(resolved: ResolvedConfig) -> int:
    config = resolved.as_dict()
    training_values = config["training"]
    optimization_values = config["optimization"]
    data_values = config["data"]
    sources = [str(value) for value in data_values["sources"]]
    dataset_ids = [str(value) for value in data_values["dataset_ids"]]
    if not sources or len(sources) != len(dataset_ids):
        raise ContractError("training requires equal non-empty data.sources and data.dataset_ids")

    training_config = TrainingConfig(
        total_steps=int(training_values["total_steps"]),
        gradient_accumulation_steps=int(training_values["gradient_accumulation_steps"]),
        max_grad_norm=float(training_values["max_grad_norm"]),
        checkpoint_interval=int(training_values["checkpoint_interval"]),
        log_interval=int(training_values["log_interval"]),
        seed=int(training_values["seed"]),
    )
    seed_everything(training_config.seed)
    model, model_spec = _create_model(config["model"])
    depth = _depth_from_config(str(data_values["depth_representation"]), model_spec.depth)

    dataloader = create_webdataset_dataloader(
        sources,
        dataset_ids,
        raw_depth=depth,
        target_depth=depth,
        image_size=int(data_values["image_size"]),
        batch_size=int(data_values["batch_size"]),
        shuffle=int(data_values["shuffle"]),
        num_workers=int(data_values["num_workers"]),
        drop_last=bool(data_values["drop_last"]),
        error_policy=cast(Literal["raise", "skip"], str(data_values["error_policy"])),
    )

    strategy_name = str(training_values["strategy"])
    strategy: TrainingStrategy
    if strategy_name == "standard":
        strategy = StandardTrainingStrategy(depth)
    elif strategy_name == "distillation":
        teacher_config = dict(config["teacher"])
        teacher_config["initialization"] = teacher_config.get("checkpoint")
        teacher, teacher_spec = _create_model(teacher_config)
        if teacher_spec.depth != depth:
            raise ContractError("teacher/student depth representations must match")
        if teacher_config.get("checkpoint") is None:
            raise ContractError("distillation requires teacher.checkpoint")
        strategy = DistillationStrategy(
            depth,
            teacher,
            distill_weight=float(config["distillation"]["weight"]),
        )
    elif strategy_name == "multitask":
        strategy = MultiTaskStrategy(
            depth,
            mask_loss_weight=float(config["multitask"]["mask_loss_weight"]),
            mask_target_key=str(config["multitask"]["mask_target_key"]),
            require_mask_target=bool(config["multitask"]["require_mask_target"]),
        )
    else:
        raise ContractError(f"unknown training strategy {strategy_name!r}")

    optimization = OptimizationConfig(
        encoder_lr=float(optimization_values["encoder_lr"]),
        decoder_lr=float(optimization_values["decoder_lr"]),
        rgb_encoder_lr=(
            None
            if optimization_values["rgb_encoder_lr"] is None
            else float(optimization_values["rgb_encoder_lr"])
        ),
        weight_decay=float(optimization_values["weight_decay"]),
        profile=OptimizationProfile(str(optimization_values["profile"])),
    )
    from .optimization import create_optimizer

    optimizer, _ = create_optimizer(model, optimization)
    scheduler = create_warmup_cosine_scheduler(
        optimizer,
        WarmupCosineConfig(
            total_steps=training_config.total_steps,
            warmup_steps=min(int(optimization_values["warmup_steps"]), training_config.total_steps),
        ),
    )
    backend = create_training_backend(
        str(config["runtime"]["backend"]),
        device=str(config["runtime"]["device"]),
        gradient_accumulation_steps=training_config.gradient_accumulation_steps,
        mixed_precision=str(config["runtime"]["mixed_precision"]),
    )
    callbacks = []
    if bool(config["observability"]["wandb"]):
        callbacks.append(
            WandbCallback(
                project=str(config["observability"]["wandb_project"]),
                name=str(config["output"]["run_id"] or model_spec.model_id),
                config=config,
                enabled=backend.is_main_process,
            )
        )
    result = train(
        model,
        dataloader,
        model_spec=model_spec,
        strategy=strategy,
        training_config=training_config,
        optimization_config=optimization,
        optimizer=optimizer,
        scheduler=scheduler,
        backend=backend,
        runs_root=str(config["output"]["runs_root"]),
        run_id=config["output"]["run_id"],
        run_dir=config["output"]["run_dir"],
        resume=config["resume"]["path"],
        resume_mode=ResumeMode(str(config["resume"]["mode"])),
        resolved_config=resolved,
        callbacks=callbacks,
        metadata={"dataset_ids": dataset_ids, "strategy": strategy_name},
        write_legacy_checkpoints=bool(config["compatibility"]["write_legacy_checkpoints"]),
    )
    if backend.is_main_process:
        print(
            json.dumps(
                {
                    "run_dir": str(result.run_dir),
                    "global_step": result.state.global_step,
                    "checkpoint": str(result.final_checkpoint),
                    "model_identity": result.model_spec.identity,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
        )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    try:
        return _run(resolve_config(args))
    except (ContractError, FileNotFoundError, RuntimeError, ValueError) as exc:
        parser.error(str(exc))
    return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
