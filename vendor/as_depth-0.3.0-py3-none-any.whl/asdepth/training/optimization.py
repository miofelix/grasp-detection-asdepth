"""参数分组与 AdamW 构建。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import torch

from asdepth.core import ContractError


class OptimizationProfile(str, Enum):
    STANDARD = "standard"
    DEFM = "defm"
    DISTILLATION = "distillation"
    MULTITASK = "multitask"


@dataclass(frozen=True, slots=True)
class OptimizationConfig:
    encoder_lr: float = 1e-5
    decoder_lr: float = 1e-4
    rgb_encoder_lr: float | None = None
    weight_decay: float = 0.05
    profile: OptimizationProfile = OptimizationProfile.STANDARD

    def __post_init__(self) -> None:
        if not isinstance(self.profile, OptimizationProfile):
            object.__setattr__(self, "profile", OptimizationProfile(self.profile))
        if self.encoder_lr <= 0 or self.decoder_lr <= 0:
            raise ContractError("optimizer learning rates must be positive")
        if self.rgb_encoder_lr is not None and self.rgb_encoder_lr <= 0:
            raise ContractError("rgb_encoder_lr must be positive")
        if self.weight_decay < 0:
            raise ContractError("weight_decay cannot be negative")

    def to_dict(self) -> dict[str, str | float | None]:
        return {
            "encoder_lr": self.encoder_lr,
            "decoder_lr": self.decoder_lr,
            "rgb_encoder_lr": self.rgb_encoder_lr,
            "weight_decay": self.weight_decay,
            "profile": self.profile.value,
        }


@dataclass(frozen=True, slots=True)
class ParameterGroupSummary:
    name: str
    learning_rate: float
    parameter_count: int
    tensor_count: int


def _parameter_role(name: str, profile: OptimizationProfile) -> str:
    if profile in {OptimizationProfile.DEFM, OptimizationProfile.MULTITASK}:
        if name.startswith("pretrained."):
            return "rgb_encoder"
        if name.startswith("depth_pretrained"):
            return "depth_encoder"
        return "decoder"
    if name.startswith("depth_pretrained"):
        return "depth_encoder"
    return "decoder"


def create_parameter_groups(
    model: torch.nn.Module,
    config: OptimizationConfig,
) -> tuple[list[dict[str, object]], tuple[ParameterGroupSummary, ...]]:
    grouped: dict[str, list[torch.nn.Parameter]] = {
        "rgb_encoder": [],
        "depth_encoder": [],
        "decoder": [],
    }
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue
        grouped[_parameter_role(name, config.profile)].append(parameter)

    learning_rates = {
        "rgb_encoder": config.rgb_encoder_lr or config.encoder_lr,
        "depth_encoder": config.encoder_lr,
        "decoder": config.decoder_lr,
    }
    order = (
        ("rgb_encoder", "depth_encoder", "decoder")
        if config.profile in {OptimizationProfile.DEFM, OptimizationProfile.MULTITASK}
        else ("depth_encoder", "decoder")
    )
    parameter_groups: list[dict[str, object]] = []
    summaries: list[ParameterGroupSummary] = []
    for role in order:
        parameters = grouped[role]
        if not parameters:
            continue
        learning_rate = learning_rates[role]
        parameter_groups.append({"params": parameters, "lr": learning_rate, "name": role})
        summaries.append(
            ParameterGroupSummary(
                name=role,
                learning_rate=learning_rate,
                parameter_count=sum(parameter.numel() for parameter in parameters),
                tensor_count=len(parameters),
            )
        )
    if not parameter_groups:
        raise ContractError("model has no trainable parameters")
    return parameter_groups, tuple(summaries)


def create_optimizer(
    model: torch.nn.Module,
    config: OptimizationConfig,
) -> tuple[torch.optim.AdamW, tuple[ParameterGroupSummary, ...]]:
    groups, summaries = create_parameter_groups(model, config)
    return torch.optim.AdamW(groups, weight_decay=config.weight_decay), summaries
