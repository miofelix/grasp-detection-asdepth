"""训练策略协议与 batch/output 规范化。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import torch

from asdepth.core import ContractError, DepthSpec, RgbdBatch


@dataclass(frozen=True, slots=True)
class StrategyResult:
    loss: torch.Tensor
    metrics: Mapping[str, torch.Tensor]
    prediction: torch.Tensor


def ensure_n1hw(value: torch.Tensor, *, name: str) -> torch.Tensor:
    if value.ndim == 3:
        return value.unsqueeze(1)
    if value.ndim == 4 and value.shape[1] == 1:
        return value
    raise ContractError(f"{name} must be NHW or N1HW, got {tuple(value.shape)}")


def extract_depth_prediction(output: Any) -> torch.Tensor:
    if isinstance(output, torch.Tensor):
        return output
    if isinstance(output, Mapping):
        for name in ("depth", "metric_depth", "inverse_depth", "prediction"):
            value = output.get(name)
            if isinstance(value, torch.Tensor):
                return value
    if isinstance(output, tuple | list) and output and isinstance(output[0], torch.Tensor):
        return output[0]
    raise ContractError(f"model output does not contain a depth tensor: {type(output).__name__}")


def extract_mask_prediction(output: Any) -> torch.Tensor:
    if isinstance(output, Mapping):
        for name in ("mask", "transparent_mask", "foreground_mask"):
            value = output.get(name)
            if isinstance(value, torch.Tensor):
                return value
    if (
        isinstance(output, tuple | list)
        and len(output) >= 2
        and isinstance(output[1], torch.Tensor)
    ):
        return output[1]
    raise ContractError("multitask model output does not contain a mask tensor")


def prepare_batch(
    batch: RgbdBatch,
    *,
    device: torch.device,
    expected_depth: DepthSpec,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    if batch.target_depth is None or batch.target_depth_spec is None:
        raise ContractError("training requires target_depth")
    if batch.depth_spec != expected_depth or batch.target_depth_spec != expected_depth:
        raise ContractError(
            "training batch DepthSpec does not match model/strategy semantics: "
            f"raw={batch.depth_spec.representation.value}, "
            f"target={batch.target_depth_spec.representation.value}, "
            f"expected={expected_depth.representation.value}"
        )
    rgb = batch.rgb.to(device=device, dtype=torch.float32, non_blocking=True)
    raw_depth = batch.raw_depth.to(device=device, dtype=torch.float32, non_blocking=True)
    target = batch.target_depth.to(device=device, dtype=torch.float32, non_blocking=True)
    if rgb.ndim != 4 or rgb.shape[1] != 3:
        raise ContractError(f"training RGB must be N3HW, got {tuple(rgb.shape)}")
    raw_depth = ensure_n1hw(raw_depth, name="raw_depth")
    target = ensure_n1hw(target, name="target_depth")
    if rgb.shape[0] != raw_depth.shape[0] or rgb.shape[-2:] != raw_depth.shape[-2:]:
        raise ContractError("RGB/raw depth shapes do not match")
    if target.shape != raw_depth.shape:
        raise ContractError("raw/target depth shapes do not match")
    model_input = torch.cat((rgb, raw_depth), dim=1)
    return model_input, target, raw_depth > 0, target > 0


class TrainingStrategy(ABC):
    def __init__(self, depth: DepthSpec) -> None:
        self.depth = depth

    def to(self, device: torch.device) -> TrainingStrategy:
        del device
        return self

    def train(self) -> None:
        return None

    @abstractmethod
    def compute(
        self,
        model: torch.nn.Module,
        batch: RgbdBatch,
        *,
        device: torch.device,
    ) -> StrategyResult:
        raise NotImplementedError
