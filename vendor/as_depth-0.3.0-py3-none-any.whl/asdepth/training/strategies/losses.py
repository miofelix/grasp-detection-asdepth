"""保持源训练数学实现的 G2 与可选透明 mask loss。"""

from __future__ import annotations

from typing import Any, cast

import torch
import torch.nn.functional as functional
from torch import Tensor
from torch.nn import Module, Parameter


class Gradient2D(Module):
    def __init__(self) -> None:
        super().__init__()
        kernel_x = torch.tensor(
            [[-1.0, 0.0, 1.0], [-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0]],
            dtype=torch.float32,
        )
        kernel_y = torch.tensor(
            [[-1.0, -2.0, -1.0], [0.0, 0.0, 0.0], [1.0, 2.0, 1.0]],
            dtype=torch.float32,
        )
        self.weight_x = Parameter(kernel_x.unsqueeze(0).unsqueeze(0), requires_grad=False)
        self.weight_y = Parameter(kernel_y.unsqueeze(0).unsqueeze(0), requires_grad=False)

    def forward(self, value: Tensor) -> tuple[Tensor, Tensor]:
        return (
            functional.conv2d(value, self.weight_x),
            functional.conv2d(value, self.weight_y),
        )


class MaskedMSGradLoss(Module):
    def __init__(self) -> None:
        super().__init__()
        self.grad_fun = Gradient2D()

    def _gradient_loss(self, residual: Tensor) -> Tensor:
        loss_x, loss_y = self.grad_fun(residual)
        return torch.sum(torch.abs(loss_x)) + torch.sum(torch.abs(loss_y))

    def forward(self, residual: Tensor, number_valid: Tensor, levels: int = 4) -> Tensor:
        loss = residual.new_zeros(())
        current = residual
        for level in range(levels):
            if level > 0:
                current = functional.interpolate(
                    current,
                    scale_factor=0.5,
                    recompute_scale_factor=True,
                )
            loss = loss + self._gradient_loss(current)
        return loss / number_valid


class MaskedDataLoss(Module):
    def forward(self, residual: Tensor, number_valid: Tensor) -> Tensor:
        return torch.sum(torch.abs(residual)) / number_valid


class G2LossTool(Module):
    def __init__(self) -> None:
        super().__init__()
        self.eps = 1e-6
        self.dataloss = MaskedDataLoss()
        self.msgradloss = MaskedMSGradLoss()

    def maskedmeanstd(self, depth: Tensor, mask: Tensor) -> tuple[Tensor, Tensor]:
        mask_num = torch.sum(mask, dim=(2, 3), keepdim=True)
        mask_num = torch.where(mask_num == 0, mask_num.new_full((), self.eps), mask_num)
        depth_mean = torch.sum(depth * mask, dim=(2, 3), keepdim=True) / mask_num
        depth_std = (
            torch.sum(torch.abs((depth - depth_mean) * mask), dim=(2, 3), keepdim=True) / mask_num
        )
        return depth_mean, depth_std + self.eps

    def standardize(self, depth: Tensor, mask: Tensor) -> tuple[Tensor, ...]:
        mean, std = self.maskedmeanstd(depth, mask)
        standardized = (depth - mean) / std
        return tuple(
            standardized[:, channel : channel + 1] for channel in range(standardized.shape[1])
        )

    def relative_loss(self, prediction: Tensor, target: Tensor, target_mask: Tensor) -> Tensor:
        residual = (prediction - target) * target_mask
        number_valid = torch.sum(target_mask) + self.eps
        return cast(
            Tensor,
            self.dataloss(residual, number_valid) + 0.5 * self.msgradloss(residual, number_valid),
        )

    def absolute_loss(self, prediction: Tensor, target: Tensor, mask: Tensor) -> Tensor:
        residual = (prediction - target) * mask
        return cast(Tensor, self.dataloss(residual, torch.sum(mask) + self.eps))

    def g2_loss(
        self,
        prediction: Tensor,
        target: Tensor,
        standardized_prediction: Tensor,
        standardized_target: Tensor,
        raw_mask: Tensor,
        target_mask: Tensor,
    ) -> Tensor:
        del raw_mask  # 源实现最终 absolute loss 使用 target mask；保留参数以保持调用契约。
        relative = self.relative_loss(
            standardized_prediction,
            standardized_target,
            target_mask,
        )
        absolute = self.absolute_loss(prediction, target, target_mask)
        result = prediction.new_zeros(())
        if not torch.isnan(relative):
            result = result + relative
        if not torch.isnan(absolute):
            result = result + absolute
        return result


class G2Loss(G2LossTool):
    def forward(
        self,
        prediction: Tensor,
        target: Tensor,
        raw_mask: Tensor,
        target_mask: Tensor,
    ) -> Tensor:
        standardized_prediction, standardized_target = self.standardize(
            torch.cat([prediction, target], dim=1),
            torch.cat([target_mask, target_mask], dim=1),
        )
        return self.g2_loss(
            prediction,
            target,
            standardized_prediction,
            standardized_target,
            raw_mask,
            target_mask,
        )


class TransparentMaskLoss(Module):
    """源 multitask 使用的 Kornia dice + focal loss，只有启用 mask supervision 才导入。"""

    def __init__(self, focal_weight: float = 0.5) -> None:
        super().__init__()
        try:
            from kornia.losses import dice_loss, focal_loss
        except ImportError as exc:  # pragma: no cover - optional train dependency
            raise RuntimeError(
                "mask supervision requires kornia; install `as-depth[train]`"
            ) from exc
        self.focal_weight = float(focal_weight)
        self._dice_loss: Any = dice_loss
        self._focal_loss: Any = focal_loss

    def forward(self, prediction: Tensor, target: Tensor) -> dict[str, Tensor]:
        if target.ndim == 4 and target.shape[1] == 1:
            target = target[:, 0]
        if prediction.ndim == 3:
            prediction = prediction.unsqueeze(1)
        if target.ndim != 3:
            raise ValueError(f"mask target must be NHW or N1HW, got {tuple(target.shape)}")
        target_long = target.long()
        dice = self._dice_loss(prediction, target_long)
        focal = self._focal_loss(
            prediction,
            target_long,
            alpha=self.focal_weight,
            reduction="mean",
        )
        return {"total_loss": dice + focal, "dice_loss": dice, "focal_loss": focal}
