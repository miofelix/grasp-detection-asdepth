"""官方 CDM teacher/student 蒸馏策略。"""

from __future__ import annotations

import torch

from asdepth.core import ContractError, DepthSpec, RgbdBatch

from .base import (
    StrategyResult,
    TrainingStrategy,
    ensure_n1hw,
    extract_depth_prediction,
    prepare_batch,
)
from .losses import G2Loss


class DistillationStrategy(TrainingStrategy):
    def __init__(
        self,
        depth: DepthSpec,
        teacher: torch.nn.Module,
        *,
        distill_weight: float = 0.7,
        task_loss: torch.nn.Module | None = None,
        distill_loss: torch.nn.Module | None = None,
    ) -> None:
        super().__init__(depth)
        if not 0.0 <= distill_weight <= 1.0:
            raise ContractError("distill_weight must be in [0, 1]")
        self.teacher = teacher
        self.distill_weight = float(distill_weight)
        self.task_loss = task_loss or G2Loss()
        self.distill_loss = distill_loss or torch.nn.L1Loss()

    def to(self, device: torch.device) -> DistillationStrategy:
        self.teacher.to(device).eval()
        self.task_loss.to(device)
        self.distill_loss.to(device)
        for parameter in self.teacher.parameters():
            parameter.requires_grad_(False)
        return self

    def train(self) -> None:
        self.teacher.eval()

    def compute(
        self,
        model: torch.nn.Module,
        batch: RgbdBatch,
        *,
        device: torch.device,
    ) -> StrategyResult:
        model_input, target, raw_mask, target_mask = prepare_batch(
            batch,
            device=device,
            expected_depth=self.depth,
        )
        student = ensure_n1hw(
            extract_depth_prediction(model(model_input)),
            name="student depth prediction",
        )
        with torch.no_grad():
            teacher = ensure_n1hw(
                extract_depth_prediction(self.teacher(model_input)),
                name="teacher depth prediction",
            )
        task = self.task_loss(student, target, raw_mask, target_mask)
        valid = target_mask.to(dtype=student.dtype)
        distill = self.distill_loss(student * valid, teacher * valid)
        total = (1.0 - self.distill_weight) * task + self.distill_weight * distill
        return StrategyResult(
            loss=total,
            metrics={"loss": total, "task_loss": task, "distill_loss": distill},
            prediction=student,
        )
