"""标准、蒸馏与 multitask 训练策略。"""

from .base import StrategyResult, TrainingStrategy
from .distillation import DistillationStrategy
from .losses import G2Loss, TransparentMaskLoss
from .multitask import MultiTaskStrategy
from .standard import StandardTrainingStrategy

__all__ = [
    "DistillationStrategy",
    "G2Loss",
    "MultiTaskStrategy",
    "StandardTrainingStrategy",
    "StrategyResult",
    "TrainingStrategy",
    "TransparentMaskLoss",
]
