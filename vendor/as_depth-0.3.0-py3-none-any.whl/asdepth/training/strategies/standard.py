"""默认 RGB-D depth 训练策略。"""

from __future__ import annotations

import torch

from asdepth.core import DepthSpec, RgbdBatch

from .base import (
    StrategyResult,
    TrainingStrategy,
    ensure_n1hw,
    extract_depth_prediction,
    prepare_batch,
)
from .losses import G2Loss


class StandardTrainingStrategy(TrainingStrategy):
    def __init__(self, depth: DepthSpec, *, loss: torch.nn.Module | None = None) -> None:
        super().__init__(depth)
        self.loss = loss or G2Loss()

    def to(self, device: torch.device) -> StandardTrainingStrategy:
        self.loss.to(device)
        return self

    def compute(
        self,
        model: torch.nn.Module,
        batch: RgbdBatch,
        *,
        device: torch.device,
    ) -> StrategyResult:
        model_input, target, raw_mask, target_mask = prepare_batch(
            batch,
            device=device,
            expected_depth=self.depth,
        )
        prediction = ensure_n1hw(
            extract_depth_prediction(model(model_input)),
            name="depth prediction",
        )
        loss = self.loss(prediction, target, raw_mask, target_mask)
        return StrategyResult(
            loss=loss,
            metrics={"loss": loss, "depth_loss": loss},
            prediction=prediction,
        )
