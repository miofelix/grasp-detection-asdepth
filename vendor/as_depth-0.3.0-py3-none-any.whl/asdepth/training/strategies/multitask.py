"""DeFM stack-conv depth + transparent mask 策略。"""

from __future__ import annotations

from typing import Any

import numpy as np
import torch

from asdepth.core import ContractError, DepthSpec, RgbdBatch

from .base import (
    StrategyResult,
    TrainingStrategy,
    ensure_n1hw,
    extract_depth_prediction,
    extract_mask_prediction,
    prepare_batch,
)
from .losses import G2Loss, TransparentMaskLoss


def _mask_target_from_metadata(
    batch: RgbdBatch,
    *,
    key: str,
    device: torch.device,
) -> torch.Tensor | None:
    if not batch.metadata:
        return None
    values = [metadata.get(key) for metadata in batch.metadata]
    if all(value is None for value in values):
        return None
    if any(value is None for value in values):
        raise ContractError(f"batch mixes samples with and without metadata[{key!r}]")
    tensors: list[torch.Tensor] = []
    for value in values:
        array = np.asarray(value, dtype=np.float32)
        if array.ndim == 3 and array.shape[0] == 1:
            array = array[0]
        if array.ndim != 2:
            raise ContractError(f"metadata[{key!r}] must be HW or 1HW, got {array.shape}")
        tensors.append(torch.from_numpy(np.ascontiguousarray(array)))
    return torch.stack(tensors).to(device=device, dtype=torch.float32, non_blocking=True)


class MultiTaskStrategy(TrainingStrategy):
    def __init__(
        self,
        depth: DepthSpec,
        *,
        depth_loss: torch.nn.Module | None = None,
        mask_loss: torch.nn.Module | None = None,
        mask_loss_weight: float = 1.0,
        mask_target_key: str = "transparent_mask",
        require_mask_target: bool = False,
    ) -> None:
        super().__init__(depth)
        if mask_loss_weight < 0:
            raise ContractError("mask_loss_weight cannot be negative")
        self.depth_loss = depth_loss or G2Loss()
        self.mask_loss = mask_loss
        self.mask_loss_weight = float(mask_loss_weight)
        self.mask_target_key = mask_target_key
        self.require_mask_target = require_mask_target

    def to(self, device: torch.device) -> MultiTaskStrategy:
        self.depth_loss.to(device)
        if self.mask_loss is not None:
            self.mask_loss.to(device)
        return self

    def _active_mask_loss(self) -> torch.nn.Module:
        if self.mask_loss is None:
            self.mask_loss = TransparentMaskLoss()
        return self.mask_loss

    def compute(
        self,
        model: torch.nn.Module,
        batch: RgbdBatch,
        *,
        device: torch.device,
    ) -> StrategyResult:
        model_input, target, raw_mask, target_mask = prepare_batch(
            batch,
            device=device,
            expected_depth=self.depth,
        )
        output: Any = model(model_input)
        prediction = ensure_n1hw(extract_depth_prediction(output), name="depth prediction")
        depth_loss = self.depth_loss(prediction, target, raw_mask, target_mask)
        mask_target = _mask_target_from_metadata(
            batch,
            key=self.mask_target_key,
            device=device,
        )
        if mask_target is None:
            if self.require_mask_target:
                raise ContractError(
                    f"multitask training requires metadata[{self.mask_target_key!r}]"
                )
            return StrategyResult(
                loss=depth_loss,
                metrics={"loss": depth_loss, "depth_loss": depth_loss},
                prediction=prediction,
            )

        mask_prediction = ensure_n1hw(extract_mask_prediction(output), name="mask prediction")
        mask_result = self._active_mask_loss()(mask_prediction, mask_target)
        if isinstance(mask_result, dict):
            mask_loss = mask_result["total_loss"]
            auxiliary_metrics = {
                f"mask_{name.removesuffix('_loss')}_loss": value
                for name, value in mask_result.items()
                if isinstance(value, torch.Tensor) and name != "total_loss"
            }
        elif isinstance(mask_result, torch.Tensor):
            mask_loss = mask_result
            auxiliary_metrics = {}
        else:
            raise ContractError("mask loss must return a tensor or mapping with total_loss")
        total = depth_loss + self.mask_loss_weight * mask_loss
        return StrategyResult(
            loss=total,
            metrics={
                "loss": total,
                "depth_loss": depth_loss,
                "mask_loss": mask_loss,
                **auxiliary_metrics,
            },
            prediction=prediction,
        )
