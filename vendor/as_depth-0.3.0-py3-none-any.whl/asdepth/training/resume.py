"""weights/fast/exact 恢复与旧 checkpoint 兼容。"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

import torch

from asdepth.artifacts import CheckpointEnvelope, safe_join, sha256_file
from asdepth.core import ContractError
from asdepth.models import CheckpointLoader, StateDictKeyMapper

from .backends import TrainingBackend
from .state import TrainingState, restore_data_state, restore_rng_state


class ResumeError(ContractError):
    pass


class ExactResumeUnavailable(ResumeError):
    pass


class ResumeMode(str, Enum):
    WEIGHTS = "weights"
    FAST = "fast"
    EXACT = "exact"


@dataclass(frozen=True, slots=True)
class ResumeReport:
    path: Path
    requested_mode: ResumeMode
    checkpoint_format: str
    checkpoint_step: int | None
    state: TrainingState
    restored: tuple[str, ...]
    warnings: tuple[str, ...] = ()

    @property
    def exact(self) -> bool:
        return self.requested_mode is ResumeMode.EXACT


def _torch_load(path: Path) -> Any:
    return torch.load(path, map_location="cpu", weights_only=False)


def _apply_model_state(
    model: torch.nn.Module,
    state_dict: Mapping[str, torch.Tensor],
    *,
    backend: TrainingBackend | None,
    strict: bool,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    target = model if backend is None else backend.unwrap_model(model)
    mapped = StateDictKeyMapper(strip_prefixes=("module.",)).map(state_dict)
    result = target.load_state_dict(mapped, strict=strict)
    return tuple(result.missing_keys), tuple(result.unexpected_keys)


def load_initial_weights(
    model: torch.nn.Module,
    checkpoint: str | Path,
    *,
    strict: bool = False,
    trusted_pickle: bool = True,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    loaded = CheckpointLoader().load(checkpoint, trusted_pickle=trusted_pickle)
    return _apply_model_state(model, loaded.state_dict, backend=None, strict=strict)


def load_prefixed_weights(
    module: torch.nn.Module,
    checkpoint: str | Path,
    *,
    prefix: str,
    strict: bool = False,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    loaded = CheckpointLoader().load(checkpoint, trusted_pickle=True)
    selected = {
        name[len(prefix) :]: tensor
        for name, tensor in loaded.state_dict.items()
        if name.startswith(prefix)
    }
    if not selected:
        raise ResumeError(f"checkpoint contains no state keys with prefix {prefix!r}")
    result = module.load_state_dict(selected, strict=strict)
    return tuple(result.missing_keys), tuple(result.unexpected_keys)


def _verify_manifest_files(directory: Path, manifest: CheckpointEnvelope) -> None:
    for role, relative_path in manifest.files.items():
        path = safe_join(directory, relative_path)
        if not path.is_file():
            raise FileNotFoundError(path)
        expected = manifest.checksums.get(role) or manifest.checksums.get(relative_path)
        if expected is not None and sha256_file(path) != expected:
            raise ResumeError(f"checkpoint checksum mismatch for {role}: {path}")


def _trainer_payload(directory: Path, manifest: CheckpointEnvelope) -> dict[str, Any]:
    relative = manifest.files.get("trainer_state")
    if relative is None:
        raise ResumeError("checkpoint has no trainer_state role")
    with safe_join(directory, relative).open(encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ResumeError("trainer_state.json must contain an object")
    return payload


def _load_required_state(
    directory: Path,
    manifest: CheckpointEnvelope,
    role: str,
) -> Any:
    relative = manifest.files.get(role)
    if relative is None:
        raise ResumeError(f"checkpoint has no {role} state")
    return _torch_load(safe_join(directory, relative))


def _adjust_fast_progress(
    state: TrainingState,
    *,
    saved_accumulation: int,
    current_accumulation: int,
) -> tuple[TrainingState, tuple[str, ...]]:
    expected = state.global_step * current_accumulation
    warnings: list[str] = []
    if saved_accumulation != current_accumulation or state.micro_batches_seen != expected:
        warnings.append(
            "fast resume uses step-aligned progress with the current gradient accumulation; "
            f"saved_ga={saved_accumulation}, current_ga={current_accumulation}, "
            f"saved_micro_batches={state.micro_batches_seen}, derived={expected}"
        )
    state.micro_batches_seen = expected
    return state, tuple(warnings)


def _restore_envelope(
    directory: Path,
    *,
    mode: ResumeMode,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    backend: TrainingBackend,
    dataloader: Any,
    gradient_accumulation_steps: int,
    expected_config_hash: str | None,
    strict_model: bool,
) -> ResumeReport:
    loaded = CheckpointLoader().load(directory, verify_checksums=True)
    manifest = loaded.manifest
    if manifest is None:
        raise ResumeError(f"checkpoint envelope has no manifest: {directory}")
    _verify_manifest_files(directory, manifest)
    _apply_model_state(model, loaded.state_dict, backend=backend, strict=strict_model)
    if mode is ResumeMode.WEIGHTS:
        return ResumeReport(
            path=directory,
            requested_mode=mode,
            checkpoint_format="envelope",
            checkpoint_step=manifest.step,
            state=TrainingState(),
            restored=("model",),
        )

    trainer = _trainer_payload(directory, manifest)
    raw_state = trainer.get("state", trainer)
    if not isinstance(raw_state, Mapping):
        raise ResumeError("trainer_state.state must be an object")
    state = TrainingState.from_dict(raw_state)
    saved_accumulation = int(trainer.get("gradient_accumulation_steps", 1))
    warnings: tuple[str, ...] = ()

    optimizer.load_state_dict(_load_required_state(directory, manifest, "optimizer"))
    restored = ["model", "optimizer"]
    if scheduler is not None:
        scheduler.load_state_dict(_load_required_state(directory, manifest, "scheduler"))
        restored.append("scheduler")
    scaler_role = manifest.files.get("scaler")
    if scaler_role is not None:
        scaler_payload = _torch_load(safe_join(directory, scaler_role))
        if not isinstance(scaler_payload, dict):
            raise ResumeError("scaler state must be a mapping")
        backend.load_scaler_state_dict(scaler_payload)
        restored.append("scaler")

    if mode is ResumeMode.FAST:
        state, warnings = _adjust_fast_progress(
            state,
            saved_accumulation=saved_accumulation,
            current_accumulation=gradient_accumulation_steps,
        )
        restored.append("step")
    else:
        if saved_accumulation != gradient_accumulation_steps:
            raise ExactResumeUnavailable(
                "exact resume requires unchanged gradient_accumulation_steps: "
                f"saved={saved_accumulation}, current={gradient_accumulation_steps}"
            )
        saved_config_hash = manifest.metadata.get("run_config_hash")
        if expected_config_hash is not None and saved_config_hash != expected_config_hash:
            raise ExactResumeUnavailable(
                "exact resume requires the same resolved config hash: "
                f"saved={saved_config_hash}, current={expected_config_hash}"
            )
        if "rng_state" not in manifest.files or "data_state" not in manifest.files:
            raise ExactResumeUnavailable(
                "exact resume requires both rng_state and a stateful dataloader cursor"
            )
        rng_payload = _load_required_state(directory, manifest, "rng_state")
        if not isinstance(rng_payload, Mapping):
            raise ResumeError("RNG state must be a mapping")
        restore_rng_state(rng_payload)
        try:
            restore_data_state(
                dataloader,
                _load_required_state(directory, manifest, "data_state"),
            )
        except ContractError as exc:
            raise ExactResumeUnavailable(str(exc)) from exc
        restored.extend(("step", "rng", "data_cursor"))

    return ResumeReport(
        path=directory,
        requested_mode=mode,
        checkpoint_format="envelope",
        checkpoint_step=manifest.step,
        state=state,
        restored=tuple(restored),
        warnings=warnings,
    )


def _legacy_progress(payload: Mapping[str, Any], accumulation: int) -> TrainingState:
    checkpoint_format = int(payload.get("checkpoint_format_version", 1))
    if checkpoint_format >= 2:
        step = int(payload.get("global_step_idx", payload.get("global_iter_idx", 0)))
        return TrainingState(global_step=step, micro_batches_seen=step * accumulation)
    micro_index = int(payload.get("global_iter_idx", -1))
    if micro_index < 0:
        return TrainingState()
    consumed = micro_index + 1
    return TrainingState(global_step=consumed // accumulation, micro_batches_seen=consumed)


def _restore_legacy(
    path: Path,
    *,
    mode: ResumeMode,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    backend: TrainingBackend,
    gradient_accumulation_steps: int,
    strict_model: bool,
) -> ResumeReport:
    if mode is ResumeMode.EXACT:
        raise ExactResumeUnavailable("legacy .ckpt files do not contain an exact data cursor")
    payload = _torch_load(path)
    if not isinstance(payload, Mapping):
        raise ResumeError("legacy checkpoint payload must be a mapping")
    loaded = CheckpointLoader().load(path, trusted_pickle=True)
    _apply_model_state(model, loaded.state_dict, backend=backend, strict=strict_model)
    if mode is ResumeMode.WEIGHTS:
        return ResumeReport(
            path=path,
            requested_mode=mode,
            checkpoint_format="legacy_ckpt",
            checkpoint_step=loaded.step,
            state=TrainingState(),
            restored=("model",),
        )
    if "optimizer" not in payload:
        raise ResumeError("fast resume requires optimizer state; use --resume-mode weights")
    optimizer.load_state_dict(payload["optimizer"])
    restored = ["model", "optimizer"]
    if scheduler is not None:
        if payload.get("scheduler") is None:
            raise ResumeError("fast resume requires scheduler state; use --resume-mode weights")
        scheduler.load_state_dict(payload["scheduler"])
        restored.append("scheduler")
    state = _legacy_progress(payload, gradient_accumulation_steps)
    restored.append("step")
    return ResumeReport(
        path=path,
        requested_mode=mode,
        checkpoint_format="legacy_ckpt",
        checkpoint_step=state.global_step,
        state=state,
        restored=tuple(restored),
        warnings=("fast resume starts a fresh shuffled dataloader stream",),
    )


def _first_existing(directory: Path, names: tuple[str, ...]) -> Path | None:
    return next((directory / name for name in names if (directory / name).is_file()), None)


def _restore_accelerate(
    directory: Path,
    *,
    mode: ResumeMode,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    backend: TrainingBackend,
    gradient_accumulation_steps: int,
    strict_model: bool,
) -> ResumeReport:
    if mode is ResumeMode.EXACT:
        raise ExactResumeUnavailable(
            "Accelerate directories are fast resume inputs unless a canonical data cursor is present"
        )
    loaded = CheckpointLoader().load(directory)
    if mode is ResumeMode.WEIGHTS:
        _apply_model_state(model, loaded.state_dict, backend=backend, strict=strict_model)
        return ResumeReport(
            path=directory,
            requested_mode=mode,
            checkpoint_format="accelerate",
            checkpoint_step=loaded.step,
            state=TrainingState(),
            restored=("model",),
        )

    native_loaded = False
    try:
        backend.load_native_state(str(directory))
        native_loaded = True
    except RuntimeError as native_error:
        _apply_model_state(model, loaded.state_dict, backend=backend, strict=strict_model)
        optimizer_path = _first_existing(directory, ("optimizer.bin", "optimizer.pt"))
        if optimizer_path is None:
            raise ResumeError(
                "Accelerate fast resume requires optimizer.bin/optimizer.pt"
            ) from native_error
        optimizer.load_state_dict(_torch_load(optimizer_path))
        if scheduler is not None:
            scheduler_path = _first_existing(directory, ("scheduler.bin", "scheduler.pt"))
            if scheduler_path is None:
                raise ResumeError(
                    "Accelerate fast resume requires scheduler.bin/scheduler.pt"
                ) from native_error
            scheduler.load_state_dict(_torch_load(scheduler_path))

    trainer_path = directory / "trainer_state.json"
    if not trainer_path.is_file():
        raise ResumeError("Accelerate fast resume requires trainer_state.json step metadata")
    with trainer_path.open(encoding="utf-8") as stream:
        trainer = json.load(stream)
    if not isinstance(trainer, Mapping):
        raise ResumeError("trainer_state.json must be an object")
    state = _legacy_progress(trainer, gradient_accumulation_steps)
    restored = ["model", "optimizer"]
    if scheduler is not None:
        restored.append("scheduler")
    restored.append("step")
    warnings = ["fast resume starts a fresh shuffled dataloader stream"]
    if native_loaded:
        warnings.append("Accelerate native state may restore RNG, but no data cursor was restored")
    return ResumeReport(
        path=directory,
        requested_mode=mode,
        checkpoint_format="accelerate",
        checkpoint_step=state.global_step,
        state=state,
        restored=tuple(restored),
        warnings=tuple(warnings),
    )


def restore_training_state(
    checkpoint: str | Path,
    *,
    mode: ResumeMode | str,
    model: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    scheduler: Any | None,
    backend: TrainingBackend,
    dataloader: Any,
    gradient_accumulation_steps: int,
    expected_config_hash: str | None = None,
    strict_model: bool = True,
) -> ResumeReport:
    requested = mode if isinstance(mode, ResumeMode) else ResumeMode(mode)
    path = Path(checkpoint).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir() and (path / "manifest.json").is_file():
        return _restore_envelope(
            path,
            mode=requested,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            backend=backend,
            dataloader=dataloader,
            gradient_accumulation_steps=gradient_accumulation_steps,
            expected_config_hash=expected_config_hash,
            strict_model=strict_model,
        )
    if path.is_dir():
        return _restore_accelerate(
            path,
            mode=requested,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            backend=backend,
            gradient_accumulation_steps=gradient_accumulation_steps,
            strict_model=strict_model,
        )
    return _restore_legacy(
        path,
        mode=requested,
        model=model,
        optimizer=optimizer,
        scheduler=scheduler,
        backend=backend,
        gradient_accumulation_steps=gradient_accumulation_steps,
        strict_model=strict_model,
    )
