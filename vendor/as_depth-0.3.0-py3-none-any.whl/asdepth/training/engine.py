"""设备无关、optimizer-step 对齐的训练循环。"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import Any

import torch

from asdepth.core import ContractError, RgbdBatch, RgbdSample
from asdepth.data import collate_rgbd_samples

from .backends import TrainingBackend
from .callbacks import CompositeCallback, StepEvent, TrainingCallback
from .state import TrainingConfig, TrainingState
from .strategies import TrainingStrategy


def _cycling_batches(source: Iterable[Any]) -> Iterator[RgbdBatch]:
    iterator = iter(source)
    while True:
        try:
            item = next(iterator)
        except StopIteration:
            iterator = iter(source)
            try:
                item = next(iterator)
            except StopIteration as exc:
                raise ContractError("training dataloader produced no batches") from exc
        if isinstance(item, RgbdBatch):
            yield item
        elif isinstance(item, RgbdSample):
            yield collate_rgbd_samples([item])
        else:
            raise ContractError(
                "canonical training dataloader must yield RgbdBatch or RgbdSample, "
                f"got {type(item).__name__}"
            )


class TrainingEngine:
    def __init__(
        self,
        *,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
        strategy: TrainingStrategy,
        backend: TrainingBackend,
        config: TrainingConfig,
        callbacks: tuple[TrainingCallback, ...] = (),
    ) -> None:
        self.model = model
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.strategy = strategy
        self.backend = backend
        self.config = config
        self.callbacks = CompositeCallback(callbacks)

    def run(
        self,
        source: Iterable[Any],
        *,
        state: TrainingState | None = None,
    ) -> TrainingState:
        active_state = state or TrainingState()
        if active_state.global_step > self.config.total_steps:
            raise ContractError(
                f"resume step {active_state.global_step} exceeds total_steps={self.config.total_steps}"
            )
        self.model.train()
        self.strategy.train()
        self.optimizer.zero_grad(set_to_none=True)
        self.callbacks.on_start(active_state.snapshot())
        batches = _cycling_batches(source)
        metric_sums: dict[str, float] = {}
        metric_count = 0

        try:
            while active_state.global_step < self.config.total_steps:
                batch = next(batches)
                active_state.micro_batches_seen += 1
                with self.backend.accumulate(self.model):
                    result = self.strategy.compute(
                        self.model,
                        batch,
                        device=self.backend.device,
                    )
                    self.backend.backward(result.loss)
                    performed_step = self.backend.finish_micro_batch(
                        self.model,
                        self.optimizer,
                        max_grad_norm=self.config.max_grad_norm,
                    )
                for name, value in result.metrics.items():
                    metric_sums[name] = metric_sums.get(name, 0.0) + float(value.detach().item())
                metric_count += 1
                if not performed_step:
                    continue
                if self.scheduler is not None:
                    self.scheduler.step()
                active_state.global_step += 1
                metrics = {
                    name: value / max(metric_count, 1) for name, value in metric_sums.items()
                }
                event = StepEvent(
                    state=active_state.snapshot(),
                    metrics=metrics,
                    learning_rates=tuple(
                        float(group["lr"]) for group in self.optimizer.param_groups
                    ),
                )
                self.callbacks.on_step(event)
                metric_sums.clear()
                metric_count = 0
        finally:
            self.callbacks.on_end(active_state.snapshot())
        return active_state
