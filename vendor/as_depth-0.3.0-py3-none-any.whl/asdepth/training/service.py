"""统一 train() 服务、run 产物与 checkpoint 编排。"""

from __future__ import annotations

import json
import platform
import sys
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from types import MappingProxyType
from typing import Any

import torch
import yaml

from asdepth.artifacts import (
    CheckpointEnvelope,
    RunLayout,
    RunManifest,
    atomic_write_json,
    atomic_write_text,
    create_run_layout,
    utc_now,
)
from asdepth.config import ResolvedConfig, config_hash
from asdepth.core import ArtifactExistsError, ContractError, ModelSpec

from .backends import TorchTrainingBackend, TrainingBackend
from .callbacks import CheckpointCallback, LoggingCallback, TrainingCallback
from .checkpoint import CheckpointManager, SavedCheckpoint
from .engine import TrainingEngine
from .optimization import OptimizationConfig, ParameterGroupSummary, create_optimizer
from .resume import ResumeMode, ResumeReport, restore_training_state
from .schedulers import WarmupCosineConfig, create_warmup_cosine_scheduler
from .state import TrainingConfig, TrainingState, seed_everything
from .strategies import StandardTrainingStrategy, TrainingStrategy


@dataclass(frozen=True, slots=True)
class TrainingResult:
    state: TrainingState
    run_dir: Path
    final_checkpoint: Path
    model: torch.nn.Module
    model_spec: ModelSpec
    parameter_groups: tuple[ParameterGroupSummary, ...]
    resume: ResumeReport | None = None


def _model_spec(model: torch.nn.Module, explicit: ModelSpec | None) -> ModelSpec:
    if explicit is not None:
        return explicit
    attached = getattr(model, "__asdepth_model_spec__", None)
    if not isinstance(attached, ModelSpec):
        raise ContractError("train() requires model_spec or a model created by ModelFactory")
    return attached


def _default_run_id(model_spec: ModelSpec) -> str:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{timestamp}-{model_spec.model_id}"


def _layout_from_root(root: Path) -> RunLayout:
    predictions = root / "predictions"
    return RunLayout(
        root=root,
        run_json=root / "run.json",
        resolved_config=root / "config.resolved.yaml",
        environment_json=root / "environment.json",
        logs=root / "logs",
        checkpoints=root / "checkpoints",
        predictions=predictions,
        prediction_arrays=predictions / "arrays",
        prediction_visualizations=predictions / "visualizations",
        metrics=root / "metrics",
        deployment=root / "deployment",
    )


def _ensure_existing_layout(root: Path) -> RunLayout:
    layout = _layout_from_root(root)
    for directory in (
        layout.logs,
        layout.checkpoints,
        layout.prediction_arrays,
        layout.prediction_visualizations,
        layout.metrics,
        layout.deployment,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return layout


def _resolve_layout(
    *,
    backend: TrainingBackend,
    runs_root: Path,
    run_id: str | None,
    run_dir: Path | None,
    resume: str | Path | None,
) -> RunLayout:
    selected_root: str | None = None
    if backend.is_main_process:
        if run_dir is not None:
            root = run_dir.expanduser().resolve()
            selected_root = str(root)
            if root.exists():
                if resume is None:
                    raise ArtifactExistsError(f"run directory already exists: {root}")
                _ensure_existing_layout(root)
            else:
                create_run_layout(root.parent, root.name)
        else:
            identifier = run_id
            if identifier is None:
                raise ContractError(
                    "internal error: run_id must be resolved before layout creation"
                )
            root = runs_root.expanduser().resolve() / identifier
            selected_root = str(root)
            if root.exists():
                if resume is None:
                    raise ArtifactExistsError(f"run directory already exists: {root}")
                _ensure_existing_layout(root)
            else:
                create_run_layout(runs_root, identifier)
    selected_root = backend.broadcast_object(selected_root)
    backend.wait_for_everyone()
    if not isinstance(selected_root, str):
        raise RuntimeError("failed to broadcast run directory")
    return _layout_from_root(Path(selected_root))


def _environment_payload(backend: TrainingBackend) -> dict[str, Any]:
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "device": str(backend.device),
    }


def _config_material(
    *,
    resolved_config: ResolvedConfig | None,
    training: TrainingConfig,
    optimization: OptimizationConfig,
    model_spec: ModelSpec,
    metadata: Mapping[str, Any],
) -> tuple[dict[str, Any], str, str]:
    if resolved_config is not None:
        return resolved_config.as_dict(), resolved_config.hash, resolved_config.to_yaml()
    payload = {
        "model": {"model_id": model_spec.model_id, "identity": model_spec.identity},
        "training": training.to_dict(),
        "optimization": optimization.to_dict(),
        "metadata": dict(metadata),
    }
    digest = config_hash(payload)
    return (
        payload,
        digest,
        yaml.safe_dump(payload, allow_unicode=True, sort_keys=True),
    )


def _write_run_manifest(
    layout: RunLayout,
    *,
    model_spec: ModelSpec,
    run_config_hash: str,
    status: str,
    metadata: Mapping[str, Any],
) -> None:
    manifest = RunManifest(
        run_id=layout.root.name,
        task="train",
        created_at=utc_now(),
        config_hash=run_config_hash,
        status=status,
        model=model_spec,
        paths=MappingProxyType(
            {
                "logs": "logs",
                "checkpoints": "checkpoints",
                "predictions": "predictions",
                "metrics": "metrics",
                "deployment": "deployment",
            }
        ),
        metadata=MappingProxyType(dict(metadata)),
    )
    atomic_write_json(layout.run_json, manifest.to_dict(), overwrite=layout.run_json.exists())


def train(
    model: torch.nn.Module,
    source: Iterable[Any],
    *,
    model_spec: ModelSpec | None = None,
    strategy: TrainingStrategy | None = None,
    training_config: TrainingConfig | None = None,
    optimization_config: OptimizationConfig | None = None,
    optimizer: torch.optim.Optimizer | None = None,
    scheduler: Any | None = None,
    backend: TrainingBackend | None = None,
    runs_root: str | Path = "runs",
    run_id: str | None = None,
    run_dir: str | Path | None = None,
    resume: str | Path | None = None,
    resume_mode: ResumeMode | str = ResumeMode.FAST,
    resolved_config: ResolvedConfig | None = None,
    callbacks: Sequence[TrainingCallback] = (),
    metadata: Mapping[str, Any] | None = None,
    write_legacy_checkpoints: bool = False,
) -> TrainingResult:
    """执行 canonical WDS/RgbdBatch 训练并返回最终 checkpoint。"""

    active_training = training_config or TrainingConfig()
    active_optimization = optimization_config or OptimizationConfig()
    active_backend = backend or TorchTrainingBackend(
        gradient_accumulation_steps=active_training.gradient_accumulation_steps
    )
    spec = _model_spec(model, model_spec)
    active_strategy = strategy or StandardTrainingStrategy(spec.depth)
    run_metadata = dict(metadata or {})
    _, run_config_hash, config_yaml = _config_material(
        resolved_config=resolved_config,
        training=active_training,
        optimization=active_optimization,
        model_spec=spec,
        metadata=run_metadata,
    )

    seed_everything(active_training.seed)
    selected_run_id = run_id
    if run_dir is None and selected_run_id is None and active_backend.is_main_process:
        selected_run_id = _default_run_id(spec)
    selected_run_id = active_backend.broadcast_object(selected_run_id)
    layout = _resolve_layout(
        backend=active_backend,
        runs_root=Path(runs_root),
        run_id=selected_run_id,
        run_dir=None if run_dir is None else Path(run_dir),
        resume=resume,
    )

    if optimizer is None:
        optimizer, parameter_groups = create_optimizer(model, active_optimization)
    else:
        parameter_groups = ()
    if scheduler is None:
        scheduler = create_warmup_cosine_scheduler(
            optimizer,
            WarmupCosineConfig(
                total_steps=active_training.total_steps,
                warmup_steps=min(3_000, active_training.total_steps),
            ),
        )
    model, optimizer, scheduler = active_backend.prepare(model, optimizer, scheduler)
    active_strategy.to(active_backend.device)

    resume_report = None
    state = TrainingState()
    if resume is not None:
        resume_report = restore_training_state(
            resume,
            mode=resume_mode,
            model=model,
            optimizer=optimizer,
            scheduler=scheduler,
            backend=active_backend,
            dataloader=source,
            gradient_accumulation_steps=active_training.gradient_accumulation_steps,
            expected_config_hash=run_config_hash,
        )
        state = resume_report.state

    manager = CheckpointManager(
        layout.checkpoints,
        model_spec=spec,
        run_config_hash=run_config_hash,
        resolved_config_yaml=config_yaml,
        legacy_root=layout.root if write_legacy_checkpoints else None,
    )
    saved: list[SavedCheckpoint] = []

    def save_periodic(current_state: TrainingState) -> object:
        if current_state.global_step >= active_training.total_steps:
            return None
        active_backend.wait_for_everyone()
        if active_backend.is_main_process:
            saved.append(
                manager.save(
                    backend=active_backend,
                    model=model,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    state=current_state,
                    dataloader=source,
                    gradient_accumulation_steps=active_training.gradient_accumulation_steps,
                    metadata={"strategy": type(active_strategy).__name__},
                    write_legacy=write_legacy_checkpoints,
                )
            )
        active_backend.wait_for_everyone()
        return None

    active_callbacks: list[TrainingCallback] = [
        LoggingCallback(
            interval=active_training.log_interval,
            enabled=active_backend.is_main_process,
        ),
        CheckpointCallback(active_training.checkpoint_interval, save_periodic),
        *callbacks,
    ]

    if active_backend.is_main_process:
        if not layout.resolved_config.exists():
            atomic_write_text(layout.resolved_config, config_yaml)
        else:
            atomic_write_text(
                layout.logs / f"config.resume-step-{state.global_step:08d}.yaml",
                config_yaml,
            )
        if not layout.environment_json.exists():
            atomic_write_json(layout.environment_json, _environment_payload(active_backend))
        _write_run_manifest(
            layout,
            model_spec=spec,
            run_config_hash=run_config_hash,
            status="running",
            metadata={
                **run_metadata,
                "strategy": type(active_strategy).__name__,
                "resume": None if resume_report is None else str(resume_report.path),
            },
        )

    engine = TrainingEngine(
        model=model,
        optimizer=optimizer,
        scheduler=scheduler,
        strategy=active_strategy,
        backend=active_backend,
        config=active_training,
        callbacks=tuple(active_callbacks),
    )
    try:
        state = engine.run(source, state=state)
        active_backend.wait_for_everyone()
        final_path_value: str | None = None
        if active_backend.is_main_process:
            final_path = manager.path_for_step(state.global_step)
            if final_path.exists():
                final_saved = SavedCheckpoint(
                    path=final_path,
                    manifest=CheckpointEnvelope.from_dict(
                        json.loads((final_path / "manifest.json").read_text(encoding="utf-8"))
                    ),
                )
            else:
                final_saved = manager.save(
                    backend=active_backend,
                    model=model,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    state=state,
                    dataloader=source,
                    gradient_accumulation_steps=active_training.gradient_accumulation_steps,
                    final=True,
                    metadata={"strategy": type(active_strategy).__name__},
                    write_legacy=write_legacy_checkpoints,
                )
            saved.append(final_saved)
            final_path_value = str(final_saved.path)
            _write_run_manifest(
                layout,
                model_spec=spec,
                run_config_hash=run_config_hash,
                status="completed",
                metadata={
                    **run_metadata,
                    "strategy": type(active_strategy).__name__,
                    "global_step": state.global_step,
                    "final_checkpoint": final_saved.path.relative_to(layout.root).as_posix(),
                },
            )
        final_path_value = active_backend.broadcast_object(final_path_value)
        active_backend.wait_for_everyone()
        if not isinstance(final_path_value, str):
            raise RuntimeError("failed to broadcast final checkpoint path")
        return TrainingResult(
            state=state.snapshot(),
            run_dir=layout.root,
            final_checkpoint=Path(final_path_value),
            model=model,
            model_spec=spec,
            parameter_groups=parameter_groups,
            resume=resume_report,
        )
    except Exception as exc:
        if active_backend.is_main_process:
            _write_run_manifest(
                layout,
                model_spec=spec,
                run_config_hash=run_config_hash,
                status="failed",
                metadata={**run_metadata, "error": f"{type(exc).__name__}: {exc}"},
            )
        raise
