"""单进程 PyTorch 后端，用于 CPU/GPU smoke 与普通训练。"""

from __future__ import annotations

from contextlib import AbstractContextManager, nullcontext
from typing import Any

import torch

from asdepth.core import ContractError

from .base import TrainingBackend


def resolve_torch_device(value: str | torch.device = "auto") -> torch.device:
    if isinstance(value, torch.device):
        return value
    if value != "auto":
        return torch.device(value)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


class TorchTrainingBackend(TrainingBackend):
    def __init__(
        self,
        *,
        device: str | torch.device = "auto",
        gradient_accumulation_steps: int = 1,
    ) -> None:
        if gradient_accumulation_steps <= 0:
            raise ContractError("gradient_accumulation_steps must be positive")
        self._device = resolve_torch_device(device)
        self.gradient_accumulation_steps = int(gradient_accumulation_steps)
        self._micro_step = 0

    @property
    def device(self) -> torch.device:
        return self._device

    @property
    def is_main_process(self) -> bool:
        return True

    def prepare(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
    ) -> tuple[torch.nn.Module, torch.optim.Optimizer, Any | None]:
        return model.to(self.device), optimizer, scheduler

    def accumulate(self, model: torch.nn.Module) -> AbstractContextManager[Any]:
        del model
        return nullcontext()

    def backward(self, loss: torch.Tensor) -> None:
        torch.autograd.backward(loss / self.gradient_accumulation_steps)

    def finish_micro_batch(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        *,
        max_grad_norm: float,
    ) -> bool:
        self._micro_step += 1
        if self._micro_step % self.gradient_accumulation_steps != 0:
            return False
        if max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        return True

    def unwrap_model(self, model: torch.nn.Module) -> torch.nn.Module:
        return model

    def wait_for_everyone(self) -> None:
        return None

    def broadcast_object(self, value: Any) -> Any:
        return value
