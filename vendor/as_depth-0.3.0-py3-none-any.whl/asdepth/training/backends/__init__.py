"""单进程 Torch 与 Accelerate 训练后端。"""

from __future__ import annotations

import os

from .accelerate import AccelerateTrainingBackend
from .base import TrainingBackend
from .torch import TorchTrainingBackend, resolve_torch_device


def create_training_backend(
    name: str = "auto",
    *,
    device: str = "auto",
    gradient_accumulation_steps: int = 1,
    mixed_precision: str = "no",
) -> TrainingBackend:
    normalized = name.lower()
    distributed = "LOCAL_RANK" in os.environ or int(os.environ.get("WORLD_SIZE", "1")) > 1
    if normalized == "auto":
        normalized = "accelerate" if distributed or mixed_precision != "no" else "torch"
    if normalized == "torch":
        if mixed_precision != "no":
            raise ValueError("mixed precision currently requires the Accelerate backend")
        return TorchTrainingBackend(
            device=device,
            gradient_accumulation_steps=gradient_accumulation_steps,
        )
    if normalized == "accelerate":
        return AccelerateTrainingBackend(
            gradient_accumulation_steps=gradient_accumulation_steps,
            mixed_precision=mixed_precision,
        )
    raise ValueError(f"unknown training backend {name!r}")


__all__ = [
    "AccelerateTrainingBackend",
    "TorchTrainingBackend",
    "TrainingBackend",
    "create_training_backend",
    "resolve_torch_device",
]
