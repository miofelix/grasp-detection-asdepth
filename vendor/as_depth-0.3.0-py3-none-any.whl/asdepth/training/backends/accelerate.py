"""Accelerate 多进程后端；依赖保持惰性导入。"""

from __future__ import annotations

import os
from contextlib import AbstractContextManager
from datetime import timedelta
from typing import Any, cast

import torch

from asdepth.core import ContractError

from .base import TrainingBackend


class AccelerateTrainingBackend(TrainingBackend):
    def __init__(
        self,
        *,
        gradient_accumulation_steps: int = 1,
        mixed_precision: str = "no",
        find_unused_parameters: bool = True,
    ) -> None:
        if gradient_accumulation_steps <= 0:
            raise ContractError("gradient_accumulation_steps must be positive")
        try:
            from accelerate import Accelerator, DataLoaderConfiguration
            from accelerate.utils import DistributedDataParallelKwargs, InitProcessGroupKwargs
        except ImportError as exc:  # pragma: no cover - optional train dependency
            raise RuntimeError(
                "Accelerate backend requires `pip install 'as-depth[train]'`"
            ) from exc

        handlers: list[Any] = [
            DistributedDataParallelKwargs(find_unused_parameters=find_unused_parameters)
        ]
        distributed = "LOCAL_RANK" in os.environ or int(os.environ.get("WORLD_SIZE", "1")) > 1
        if distributed:
            backend = "nccl" if torch.cuda.is_available() else "gloo"
            handlers.insert(
                0,
                InitProcessGroupKwargs(backend=backend, timeout=timedelta(minutes=30)),
            )
        dataloader_config = DataLoaderConfiguration(
            dispatch_batches=False,
            use_stateful_dataloader=False,
        )
        self.accelerator: Any = Accelerator(
            gradient_accumulation_steps=gradient_accumulation_steps,
            mixed_precision=mixed_precision,
            step_scheduler_with_optimizer=False,
            dataloader_config=dataloader_config,
            kwargs_handlers=handlers,
        )

    @property
    def device(self) -> torch.device:
        return cast(torch.device, self.accelerator.device)

    @property
    def is_main_process(self) -> bool:
        return bool(self.accelerator.is_main_process)

    def prepare(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
    ) -> tuple[torch.nn.Module, torch.optim.Optimizer, Any | None]:
        if scheduler is None:
            prepared_model, prepared_optimizer = self.accelerator.prepare(model, optimizer)
            return prepared_model, prepared_optimizer, None
        prepared_model, prepared_optimizer, prepared_scheduler = self.accelerator.prepare(
            model,
            optimizer,
            scheduler,
        )
        return prepared_model, prepared_optimizer, prepared_scheduler

    def accumulate(self, model: torch.nn.Module) -> AbstractContextManager[Any]:
        return cast(AbstractContextManager[Any], self.accelerator.accumulate(model))

    def backward(self, loss: torch.Tensor) -> None:
        self.accelerator.backward(loss)

    def finish_micro_batch(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        *,
        max_grad_norm: float,
    ) -> bool:
        if max_grad_norm > 0 and self.accelerator.sync_gradients:
            self.accelerator.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
        skipped = bool(getattr(optimizer, "step_was_skipped", False))
        return bool(self.accelerator.sync_gradients and not skipped)

    def unwrap_model(self, model: torch.nn.Module) -> torch.nn.Module:
        return cast(torch.nn.Module, self.accelerator.unwrap_model(model))

    def wait_for_everyone(self) -> None:
        self.accelerator.wait_for_everyone()

    def broadcast_object(self, value: Any) -> Any:
        if not torch.distributed.is_available() or not torch.distributed.is_initialized():
            return value
        values = [value if self.is_main_process else None]
        torch.distributed.broadcast_object_list(values, src=0)
        return values[0]

    def scaler_state_dict(self) -> dict[str, Any] | None:
        scaler = getattr(self.accelerator, "scaler", None)
        return None if scaler is None else dict(scaler.state_dict())

    def load_scaler_state_dict(self, payload: dict[str, Any]) -> None:
        scaler = getattr(self.accelerator, "scaler", None)
        if scaler is None:
            if payload:
                raise RuntimeError("checkpoint contains scaler state but this run has no scaler")
            return
        scaler.load_state_dict(payload)

    def load_native_state(self, path: str) -> None:
        self.accelerator.load_state(path)
