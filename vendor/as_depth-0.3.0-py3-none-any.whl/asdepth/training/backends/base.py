"""训练执行后端协议。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from contextlib import AbstractContextManager
from typing import Any

import torch


class TrainingBackend(ABC):
    @property
    @abstractmethod
    def device(self) -> torch.device:
        raise NotImplementedError

    @property
    @abstractmethod
    def is_main_process(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def prepare(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
    ) -> tuple[torch.nn.Module, torch.optim.Optimizer, Any | None]:
        raise NotImplementedError

    @abstractmethod
    def accumulate(self, model: torch.nn.Module) -> AbstractContextManager[Any]:
        raise NotImplementedError

    @abstractmethod
    def backward(self, loss: torch.Tensor) -> None:
        raise NotImplementedError

    @abstractmethod
    def finish_micro_batch(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        *,
        max_grad_norm: float,
    ) -> bool:
        """完成 optimizer/zero_grad；返回本 micro-batch 是否产生 optimizer step。"""

        raise NotImplementedError

    @abstractmethod
    def unwrap_model(self, model: torch.nn.Module) -> torch.nn.Module:
        raise NotImplementedError

    @abstractmethod
    def wait_for_everyone(self) -> None:
        raise NotImplementedError

    @abstractmethod
    def broadcast_object(self, value: Any) -> Any:
        raise NotImplementedError

    def scaler_state_dict(self) -> dict[str, Any] | None:
        return None

    def load_scaler_state_dict(self, payload: dict[str, Any]) -> None:
        if payload:
            raise RuntimeError(f"{type(self).__name__} has no gradient scaler to restore")

    def load_native_state(self, path: str) -> None:
        raise RuntimeError(f"{type(self).__name__} cannot load an Accelerate native state")
