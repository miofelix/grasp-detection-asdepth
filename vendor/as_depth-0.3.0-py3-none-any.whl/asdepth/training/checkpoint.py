"""新 checkpoint envelope 的安全、可恢复写入。"""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

import torch
from safetensors.torch import save_file as save_safetensors

from asdepth.artifacts import (
    CheckpointEnvelope,
    CheckpointFormat,
    atomic_write_json,
    atomic_write_text,
    sha256_file,
    utc_now,
)
from asdepth.core import ArtifactExistsError, ModelSpec

from .backends import TrainingBackend
from .state import TrainingState, capture_data_state, capture_rng_state


@dataclass(frozen=True, slots=True)
class SavedCheckpoint:
    path: Path
    manifest: CheckpointEnvelope
    legacy_path: Path | None = None


def _portable_model_state(model: torch.nn.Module) -> dict[str, torch.Tensor]:
    return {
        name: tensor.detach().cpu().contiguous().clone()
        for name, tensor in sorted(model.state_dict().items())
    }


class CheckpointManager:
    """写 `checkpoint-step-XXXXXXXX/`；目录和已有文件默认不可覆盖。"""

    def __init__(
        self,
        root: str | Path,
        *,
        model_spec: ModelSpec,
        run_config_hash: str,
        resolved_config_yaml: str,
        legacy_root: str | Path | None = None,
    ) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.model_spec = model_spec
        self.run_config_hash = run_config_hash
        self.resolved_config_yaml = resolved_config_yaml
        self.legacy_root = None if legacy_root is None else Path(legacy_root).expanduser().resolve()

    def path_for_step(self, step: int) -> Path:
        return self.root / f"checkpoint-step-{step:08d}"

    def save(
        self,
        *,
        backend: TrainingBackend,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
        state: TrainingState,
        dataloader: Any,
        gradient_accumulation_steps: int,
        final: bool = False,
        metadata: dict[str, Any] | None = None,
        write_legacy: bool = False,
    ) -> SavedCheckpoint:
        target = self.path_for_step(state.global_step)
        if target.exists():
            raise ArtifactExistsError(f"checkpoint directory already exists: {target}")
        temporary = Path(tempfile.mkdtemp(prefix=f".{target.name}-", dir=str(self.root))).resolve()
        try:
            files: dict[str, str] = {}
            checksums: dict[str, str] = {}

            model_path = temporary / "model.safetensors"
            portable_state = _portable_model_state(backend.unwrap_model(model))
            save_safetensors(portable_state, model_path)
            files["model"] = model_path.name

            optimizer_path = temporary / "optimizer.pt"
            torch.save(optimizer.state_dict(), optimizer_path)
            files["optimizer"] = optimizer_path.name

            if scheduler is not None:
                scheduler_path = temporary / "scheduler.pt"
                torch.save(scheduler.state_dict(), scheduler_path)
                files["scheduler"] = scheduler_path.name

            scaler_state = backend.scaler_state_dict()
            if scaler_state is not None:
                scaler_path = temporary / "scaler.pt"
                torch.save(scaler_state, scaler_path)
                files["scaler"] = scaler_path.name

            rng_path = temporary / "rng_state.pt"
            torch.save(capture_rng_state(), rng_path)
            files["rng_state"] = rng_path.name

            data_state = capture_data_state(dataloader)
            if data_state is not None:
                data_state_path = temporary / "data_state.pt"
                torch.save(data_state, data_state_path)
                files["data_state"] = data_state_path.name

            trainer_path = temporary / "trainer_state.json"
            atomic_write_json(
                trainer_path,
                {
                    "schema_version": TrainingState.SCHEMA_VERSION,
                    "saved_at": utc_now(),
                    "state": state.to_dict(),
                    "gradient_accumulation_steps": gradient_accumulation_steps,
                    "exact_data_state": data_state is not None,
                    "final": final,
                },
            )
            files["trainer_state"] = trainer_path.name

            config_path = temporary / "config.resolved.yaml"
            atomic_write_text(config_path, self.resolved_config_yaml)
            files["config"] = config_path.name

            for role, relative_path in files.items():
                checksums[role] = sha256_file(temporary / relative_path)

            manifest = CheckpointEnvelope(
                checkpoint_format=CheckpointFormat.ENVELOPE,
                model=self.model_spec,
                depth=self.model_spec.depth,
                step=state.global_step,
                config_hash=self.model_spec.config_hash,
                files=MappingProxyType(files),
                checksums=MappingProxyType(checksums),
                metadata=MappingProxyType(
                    {
                        "run_config_hash": self.run_config_hash,
                        "final": final,
                        "resume_modes": ["weights", "fast"]
                        + (["exact"] if data_state is not None else []),
                        **dict(metadata or {}),
                    }
                ),
            )
            atomic_write_json(temporary / "manifest.json", manifest.to_dict())
            temporary.replace(target)
            atomic_write_text(
                self.root / "latest_checkpoint.txt",
                f"{target.name}\n",
                overwrite=True,
            )

            legacy_path = None
            if write_legacy:
                legacy_path = self._save_legacy(
                    portable_state=portable_state,
                    optimizer=optimizer,
                    scheduler=scheduler,
                    state=state,
                    final=final,
                )
            return SavedCheckpoint(path=target, manifest=manifest, legacy_path=legacy_path)
        except Exception:
            if temporary.exists():
                shutil.rmtree(temporary)
            raise

    def _save_legacy(
        self,
        *,
        portable_state: dict[str, torch.Tensor],
        optimizer: torch.optim.Optimizer,
        scheduler: Any | None,
        state: TrainingState,
        final: bool,
    ) -> Path:
        if self.legacy_root is None:
            raise RuntimeError("legacy checkpoint output requested without legacy_root")
        self.legacy_root.mkdir(parents=True, exist_ok=True)
        name = f"final_step_{state.global_step}.ckpt" if final else f"step_{state.global_step}.ckpt"
        path = self.legacy_root / name
        if path.exists():
            raise ArtifactExistsError(f"legacy checkpoint already exists: {path}")
        torch.save(
            {
                "model": portable_state,
                "optimizer": optimizer.state_dict(),
                "scheduler": None if scheduler is None else scheduler.state_dict(),
                **state.to_legacy_progress(),
            },
            path,
        )
        atomic_write_text(
            self.legacy_root / "latest_checkpoint.txt",
            f"{self.path_for_step(state.global_step)}\n",
            overwrite=True,
        )
        return path
