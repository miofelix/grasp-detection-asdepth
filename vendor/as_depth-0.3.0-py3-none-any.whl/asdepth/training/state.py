"""训练配置、进度状态、RNG 与数据游标契约。"""

from __future__ import annotations

import random
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, ClassVar

import numpy as np
import torch

from asdepth.core import ContractError


@dataclass(frozen=True, slots=True)
class TrainingConfig:
    """设备无关的 optimizer-step 训练控制参数。"""

    total_steps: int = 100_000
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0
    checkpoint_interval: int = 5_000
    log_interval: int = 100
    seed: int = 42

    def __post_init__(self) -> None:
        if self.total_steps <= 0:
            raise ContractError("total_steps must be positive")
        if self.gradient_accumulation_steps <= 0:
            raise ContractError("gradient_accumulation_steps must be positive")
        if self.max_grad_norm < 0:
            raise ContractError("max_grad_norm cannot be negative")
        if self.checkpoint_interval < 0 or self.log_interval < 0:
            raise ContractError("checkpoint/log intervals cannot be negative")
        if self.seed < 0:
            raise ContractError("seed cannot be negative")

    def to_dict(self) -> dict[str, int | float]:
        return {
            "total_steps": self.total_steps,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "max_grad_norm": self.max_grad_norm,
            "checkpoint_interval": self.checkpoint_interval,
            "log_interval": self.log_interval,
            "seed": self.seed,
        }


@dataclass(slots=True)
class TrainingState:
    """统一使用 optimizer step，另行记录已消费的 per-process micro-batch。"""

    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    global_step: int = 0
    micro_batches_seen: int = 0
    optimizer_steps_skipped: int = 0
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"TrainingState requires schema {self.SCHEMA_VERSION}")
        if min(self.global_step, self.micro_batches_seen, self.optimizer_steps_skipped) < 0:
            raise ContractError("training counters cannot be negative")

    @property
    def batches_seen(self) -> int:
        """旧 checkpoint 字段的语义化别名。"""

        return self.micro_batches_seen

    def snapshot(self) -> TrainingState:
        return TrainingState(
            global_step=self.global_step,
            micro_batches_seen=self.micro_batches_seen,
            optimizer_steps_skipped=self.optimizer_steps_skipped,
        )

    def to_dict(self) -> dict[str, int | str]:
        return {
            "schema_version": self.schema_version,
            "global_step": self.global_step,
            "micro_batches_seen": self.micro_batches_seen,
            "optimizer_steps_skipped": self.optimizer_steps_skipped,
        }

    def to_legacy_progress(self) -> dict[str, int]:
        return {
            "checkpoint_format_version": 3,
            "global_step_idx": self.global_step,
            "global_iter_idx": self.global_step,
            "batches_seen": self.micro_batches_seen,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> TrainingState:
        schema_version = str(payload.get("schema_version", cls.SCHEMA_VERSION))
        global_step = int(
            payload.get(
                "global_step",
                payload.get("global_step_idx", payload.get("global_iter_idx", 0)),
            )
        )
        return cls(
            global_step=global_step,
            micro_batches_seen=int(
                payload.get("micro_batches_seen", payload.get("batches_seen", 0))
            ),
            optimizer_steps_skipped=int(payload.get("optimizer_steps_skipped", 0)),
            schema_version=schema_version,
        )


def seed_everything(seed: int) -> None:
    """设置 Python、NumPy、Torch CPU/CUDA RNG。"""

    if seed < 0:
        raise ContractError("seed cannot be negative")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def capture_rng_state() -> dict[str, Any]:
    """捕获 exact resume 所需 RNG；返回值通过 `torch.save` 序列化。"""

    result: dict[str, Any] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        result["torch_cuda"] = torch.cuda.get_rng_state_all()
    return result


def restore_rng_state(payload: Mapping[str, Any]) -> None:
    required = {"python", "numpy", "torch_cpu"}
    missing = required - payload.keys()
    if missing:
        raise ContractError(f"RNG state is incomplete: missing {sorted(missing)}")
    random.setstate(payload["python"])
    np.random.set_state(payload["numpy"])
    torch.set_rng_state(payload["torch_cpu"])
    if "torch_cuda" in payload:
        if not torch.cuda.is_available():
            raise ContractError("checkpoint contains CUDA RNG state but CUDA is unavailable")
        torch.cuda.set_rng_state_all(list(payload["torch_cuda"]))


def _stateful_data_target(source: Any) -> Any | None:
    if callable(getattr(source, "state_dict", None)) and callable(
        getattr(source, "load_state_dict", None)
    ):
        return source
    dataset = getattr(source, "dataset", None)
    if callable(getattr(dataset, "state_dict", None)) and callable(
        getattr(dataset, "load_state_dict", None)
    ):
        return dataset
    return None


def capture_data_state(source: Any) -> Any | None:
    target = _stateful_data_target(source)
    return None if target is None else target.state_dict()


def restore_data_state(source: Any, payload: Any) -> None:
    target = _stateful_data_target(source)
    if target is None:
        raise ContractError(
            "exact resume requires a dataloader or dataset implementing state_dict/load_state_dict"
        )
    target.load_state_dict(payload)
