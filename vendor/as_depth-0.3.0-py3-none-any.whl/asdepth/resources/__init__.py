"""随 wheel 分发的 catalog、默认配置、schema 与 Web 资源。"""
