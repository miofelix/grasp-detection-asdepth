"""Canonical RgbdBatch 到源 DPT 四通道输入的预处理。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

import numpy as np
import torch
from numpy.typing import NDArray

from asdepth.core import ContractError, DepthSpec, RgbdBatch
from asdepth.core.serialization import frozen_mapping
from asdepth.data.transforms.legacy_dpt import LegacyDptTransform

from .protocols import PreparedBatch


def _numpy(value: Any) -> NDArray[Any]:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def _rgb_hwc(value: NDArray[Any]) -> NDArray[np.uint8]:
    array = np.asarray(value)
    if array.ndim != 3:
        raise ContractError(f"RGB sample must have three dimensions, got {array.shape}")
    if array.shape[0] in {3, 4}:
        array = np.moveaxis(array[:3], 0, -1)
    elif array.shape[-1] in {3, 4}:
        array = array[..., :3]
    else:
        raise ContractError(f"RGB sample must be CHW or HWC with three channels, got {array.shape}")
    if not np.issubdtype(array.dtype, np.integer):
        raise ContractError(
            "DPT inference expects unnormalized integer RGB values in the 0-255 range"
        )
    return np.ascontiguousarray(array, dtype=np.uint8)


def _depth_hw(value: NDArray[Any]) -> NDArray[np.float32]:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim == 3 and array.shape[0] == 1:
        array = array[0]
    elif array.ndim == 3 and array.shape[-1] == 1:
        array = array[..., 0]
    if array.ndim != 2:
        raise ContractError(f"raw depth sample must be HxW or 1xHxW, got {array.shape}")
    return np.ascontiguousarray(array, dtype=np.float32)


def sparsify_raw_depth(
    inputs: torch.Tensor,
    *,
    generator: torch.Generator | None = None,
) -> torch.Tensor:
    """复刻旧 sparse raw 策略并返回新 tensor，不原地修改调用方输入。"""

    if inputs.ndim != 4 or inputs.shape[1] < 1:
        raise ContractError(f"sparse raw input must be NCHW, got {tuple(inputs.shape)}")
    result = inputs.clone()
    raw_batch = result[:, -1]
    sparse = torch.zeros_like(raw_batch)
    for index, raw in enumerate(raw_batch):
        valid_indices = torch.where((raw > 0).flatten())[0]
        sample_count = int(min(raw.numel() * 0.1, valid_indices.numel(), 10_000))
        if sample_count <= 0:
            continue
        order = torch.randperm(
            valid_indices.numel(),
            generator=generator,
            device=valid_indices.device,
        )[:sample_count]
        selected = valid_indices[order]
        sparse[index].flatten()[selected] = raw.flatten()[selected]
    raw_batch.copy_(sparse)
    return result


@dataclass(frozen=True, slots=True)
class DptBatchPreprocessor:
    """源批量推理等价的 resize、normalize、四通道拼接。"""

    depth: DepthSpec
    input_size: int = 518
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound"
    sparse_raw_depth: bool = False
    generator: torch.Generator | None = None

    def __post_init__(self) -> None:
        if self.input_size <= 0:
            raise ContractError("input_size must be positive")

    def prepare(self, batch: RgbdBatch) -> PreparedBatch:
        if (
            batch.raw_depth_spec.representation is not self.depth.representation
            or batch.raw_depth_spec.unit is not self.depth.unit
        ):
            raise ContractError(
                "batch raw depth semantics do not match the preprocessor: "
                f"{batch.raw_depth_spec.representation.value}/{batch.raw_depth_spec.unit.value} "
                f"vs {self.depth.representation.value}/{self.depth.unit.value}"
            )

        rgb_batch = _numpy(batch.rgb)
        depth_batch = _numpy(batch.raw_depth)
        if rgb_batch.shape[0] != batch.batch_size or depth_batch.shape[0] != batch.batch_size:
            raise ContractError("preprocessor inputs do not match RgbdBatch.batch_size")

        transform = LegacyDptTransform(
            image_size=self.input_size,
            resize_method=self.resize_method,
        )
        tensors: list[torch.Tensor] = []
        shapes: list[tuple[int, int]] = []
        transformed_shapes: set[tuple[int, int]] = set()
        for rgb_value, depth_value in zip(rgb_batch, depth_batch, strict=True):
            rgb = _rgb_hwc(rgb_value)
            raw = _depth_hw(depth_value)
            chw, resized_raw = transform.prepare_input(rgb, raw)
            transformed_shapes.add((int(chw.shape[1]), int(chw.shape[2])))
            tensors.append(
                torch.from_numpy(
                    np.concatenate((chw, resized_raw[None]), axis=0).astype(
                        np.float32,
                        copy=False,
                    )
                )
            )
            shapes.append((int(rgb.shape[0]), int(rgb.shape[1])))
        if len(transformed_shapes) != 1:
            raise ContractError(
                "samples in one DPT batch resize to different shapes; use batch_size=1 or bucket by shape"
            )

        inputs = torch.stack(tensors)
        if self.sparse_raw_depth:
            inputs = sparsify_raw_depth(inputs, generator=self.generator)
        return PreparedBatch(
            batch=batch,
            inputs=inputs,
            original_shapes=tuple(shapes),
            metadata=frozen_mapping(
                {
                    "input_depth": self.depth.to_dict(),
                    "input_size": self.input_size,
                    "resize_method": self.resize_method,
                    "sparse_raw_depth": self.sparse_raw_depth,
                }
            ),
        )
