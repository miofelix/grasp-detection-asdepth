"""推理侧 checkpoint、模型身份和设备装配。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

import torch
from loguru import logger

from asdepth.artifacts import CheckpointEnvelope, validate_manifest
from asdepth.core import ContractError, DepthRepresentation, ModelSpec
from asdepth.core.serialization import frozen_mapping
from asdepth.models import ModelCatalog, ModelLoadReport, ResolutionSource, load_model_with_report


def select_inference_device(value: str | torch.device | None = None) -> torch.device:
    """解析显式设备；未指定时按 CUDA、MPS、CPU 顺序选择。"""

    if value is not None and str(value).lower() != "auto":
        return torch.device(value)
    if torch.cuda.is_available():
        return torch.device("cuda")
    mps = getattr(torch.backends, "mps", None)
    if mps is not None and mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


@dataclass(frozen=True, slots=True)
class LoadedInferenceModel:
    """专项应用可复用的已加载模型和稳定解析元数据。"""

    model: torch.nn.Module
    spec: ModelSpec
    report: ModelLoadReport
    device: torch.device
    resolved_encoder: str
    registry_metadata: MappingProxyType[str, Any]

    @property
    def is_disp(self) -> bool:
        return self.spec.depth.representation is DepthRepresentation.INVERSE_DEPTH

    @property
    def is_sparse_raw_depth(self) -> bool:
        return bool(self.spec.metadata.get("is_sparse_raw_depth", False))


@dataclass(frozen=True, slots=True)
class ResolvedInferenceModel:
    """不读取 checkpoint tensor 的稳定模型身份与旧 registry 元数据。"""

    spec: ModelSpec
    source: ResolutionSource
    resolved_encoder: str
    registry_metadata: MappingProxyType[str, Any]

    @property
    def is_disp(self) -> bool:
        return self.spec.depth.representation is DepthRepresentation.INVERSE_DEPTH

    @property
    def is_sparse_raw_depth(self) -> bool:
        return bool(self.spec.metadata.get("is_sparse_raw_depth", False))


def _registry_metadata(
    spec: ModelSpec,
    source: ResolutionSource,
    encoder: str,
) -> MappingProxyType[str, Any]:
    module, separator, class_name = spec.entrypoint.partition(":")
    if not separator:
        raise ContractError(f"invalid model entrypoint: {spec.entrypoint!r}")
    legacy_name = str(spec.metadata.get("legacy_registry_name", spec.model_id))
    return frozen_mapping(
        {
            "name": legacy_name,
            "model_id": spec.model_id,
            "module": module,
            "class_name": class_name,
            "encoder": encoder,
            "is_disp": spec.depth.representation is DepthRepresentation.INVERSE_DEPTH,
            "is_sparse_raw_depth": bool(spec.metadata.get("is_sparse_raw_depth", False)),
            "resolution_source": source.value,
        }
    )


def _resolved_encoder(spec: ModelSpec, requested: str | None) -> str:
    constructor = spec.metadata.get("constructor_kwargs", {})
    if not isinstance(constructor, dict):
        raise ContractError("ModelSpec metadata.constructor_kwargs must be a mapping")
    resolved = str(constructor.get("encoder", ""))
    if not resolved:
        raise ContractError(f"model {spec.model_id!r} does not declare an encoder")
    if requested not in {None, "", "auto", resolved}:
        logger.warning(
            "Encoder '{}' does not match model catalog encoder '{}' for {}; using catalog value",
            requested,
            resolved,
            spec.model_id,
        )
    return resolved


def _checkpoint_manifest(checkpoint: str | Path) -> CheckpointEnvelope | None:
    path = Path(checkpoint).expanduser()
    manifest_path = path / "manifest.json" if path.is_dir() else path
    if manifest_path.name != "manifest.json" or not manifest_path.is_file():
        return None
    with manifest_path.open(encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ContractError("checkpoint envelope manifest must be an object")
    validate_manifest(payload, "checkpoint")
    return CheckpointEnvelope.from_dict(payload)


def resolve_inference_model(
    checkpoint: str | Path,
    *,
    model_id: str | None = None,
    encoder: str | None = "auto",
    model_registry: str | Path | None = None,
) -> ResolvedInferenceModel:
    """按 manifest > CLI model > 旧路径 fallback 解析身份，不打开模型 tensor。"""

    catalog = ModelCatalog.from_package(
        legacy_path=None if model_registry is None else Path(model_registry).expanduser().resolve()
    )
    resolved = catalog.resolve(
        checkpoint_manifest=_checkpoint_manifest(checkpoint),
        model_id=model_id,
        checkpoint_path=checkpoint,
    )
    selected_encoder = _resolved_encoder(resolved.spec, encoder)
    return ResolvedInferenceModel(
        spec=resolved.spec,
        source=resolved.source,
        resolved_encoder=selected_encoder,
        registry_metadata=_registry_metadata(
            resolved.spec,
            resolved.source,
            selected_encoder,
        ),
    )


def load_inference_model(
    checkpoint: str | Path,
    *,
    model_id: str | None = None,
    encoder: str | None = "auto",
    model_registry: str | Path | None = None,
    device: str | torch.device | None = None,
    strict: bool = False,
    verify_checksums: bool = True,
    trusted_pickle: bool = False,
) -> LoadedInferenceModel:
    """按 manifest > model ID > 旧路径 fallback 加载推理模型。"""

    active_device = select_inference_device(device)
    catalog = ModelCatalog.from_package(
        legacy_path=None if model_registry is None else Path(model_registry).expanduser().resolve()
    )
    report = load_model_with_report(
        checkpoint,
        model_id=model_id,
        device=active_device,
        strict=strict,
        verify_checksums=verify_checksums,
        trusted_pickle=trusted_pickle,
        catalog=catalog,
    )
    resolved_encoder = _resolved_encoder(report.spec, encoder)
    metadata = _registry_metadata(report.spec, report.resolution.source, resolved_encoder)
    logger.info(
        "Loaded {} via {} on {} (resolution={}, missing={}, unexpected={})",
        report.spec.model_id,
        report.spec.entrypoint,
        active_device,
        report.resolution.source.value,
        len(report.missing_keys),
        len(report.unexpected_keys),
    )
    return LoadedInferenceModel(
        model=report.model,
        spec=report.spec,
        report=report,
        device=active_device,
        resolved_encoder=resolved_encoder,
        registry_metadata=metadata,
    )
