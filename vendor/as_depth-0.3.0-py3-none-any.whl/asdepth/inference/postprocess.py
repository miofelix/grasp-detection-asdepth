"""模型原始输出到逐样本 metric ModelOutput 的后处理。"""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

import cv2
import numpy as np
import torch
from numpy.typing import NDArray

from asdepth.compat import LogDepthDecodeMode, decode_log_depth_3ch
from asdepth.core import (
    ContractError,
    DepthMap,
    DepthRepresentation,
    DepthSpec,
    ModelOutput,
    ModelSpec,
)
from asdepth.runtime import RuntimeBatchOutput

from .protocols import PreparedBatch


def _numpy(value: Any) -> NDArray[Any]:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


def _named_outputs(values: Any, model_spec: ModelSpec) -> dict[str, NDArray[Any]]:
    names = tuple(item.name for item in model_spec.outputs)
    if isinstance(values, dict):
        missing = set(names) - values.keys()
        if missing:
            raise ContractError(f"runtime output is missing model outputs: {sorted(missing)}")
        return {name: _numpy(values[name]) for name in names}
    if isinstance(values, tuple | list):
        if len(values) != len(names):
            raise ContractError(
                f"runtime returned {len(values)} outputs but ModelSpec declares {len(names)}"
            )
        return {name: _numpy(value) for name, value in zip(names, values, strict=True)}
    if len(names) != 1:
        raise ContractError(
            f"runtime returned one value but ModelSpec declares outputs {list(names)}"
        )
    return {names[0]: _numpy(values)}


def _primary_batch(value: NDArray[Any], spec: DepthSpec) -> NDArray[np.float32]:
    array = np.asarray(value, dtype=np.float32)
    if spec.channels == 1:
        if array.ndim == 4 and array.shape[1] == 1:
            array = array[:, 0]
        if array.ndim != 3:
            raise ContractError(f"single-channel runtime depth must be NHW, got {array.shape}")
    else:
        if array.ndim != 4 or array.shape[1] != spec.channels:
            raise ContractError(
                f"{spec.representation.value} runtime output must be NCHW with "
                f"{spec.channels} channels, got {array.shape}"
            )
    return np.ascontiguousarray(array, dtype=np.float32)


def _resize(value: NDArray[Any], shape: tuple[int, int]) -> NDArray[Any]:
    height, width = shape
    array = np.asarray(value)
    if array.shape[-2:] == shape:
        return np.ascontiguousarray(array)
    if array.ndim == 2:
        return cv2.resize(array, (width, height), interpolation=cv2.INTER_NEAREST)
    if array.ndim == 3:
        return np.stack(
            [
                cv2.resize(channel, (width, height), interpolation=cv2.INTER_NEAREST)
                for channel in array
            ]
        )
    raise ContractError(f"cannot resize runtime output with shape {array.shape}")


@dataclass(frozen=True, slots=True)
class DepthPostprocessor:
    """按显式 native DepthSpec 解读输出，并统一返回 meter metric depth。"""

    native_depth: DepthSpec | None = None
    log_depth_decode_mode: LogDepthDecodeMode = LogDepthDecodeMode.C1_METRIC

    def process(
        self,
        output: RuntimeBatchOutput,
        prepared: PreparedBatch,
        model_spec: ModelSpec,
    ) -> tuple[ModelOutput, ...]:
        native = self.native_depth or model_spec.depth
        named = _named_outputs(output.values, model_spec)
        primary_name = model_spec.outputs[0].name
        primary = _primary_batch(named.pop(primary_name), native)
        if primary.shape[0] != prepared.batch.batch_size:
            raise ContractError("runtime output batch dimension does not match the prepared batch")

        auxiliary_batches: dict[str, NDArray[Any]] = {}
        for name, value in named.items():
            array = np.asarray(value)
            if array.shape[0] != prepared.batch.batch_size:
                raise ContractError(f"auxiliary output {name!r} has the wrong batch dimension")
            if array.ndim == 4 and array.shape[1] == 1:
                array = array[:, 0]
            auxiliary_batches[name] = array

        results: list[ModelOutput] = []
        for index, shape in enumerate(prepared.original_shapes):
            resized_primary = np.asarray(_resize(primary[index], shape), dtype=np.float32)
            auxiliary: dict[str, NDArray[Any]] = {
                name: _resize(value[index], shape) for name, value in auxiliary_batches.items()
            }
            if native.representation is DepthRepresentation.LOG_DEPTH_3CH:
                raw = DepthMap(resized_primary, native)
                depth = decode_log_depth_3ch(raw, self.log_depth_decode_mode)
                auxiliary["raw_log_depth_3ch"] = raw.values
            else:
                depth = DepthMap(resized_primary, native).to_metric()
            results.append(ModelOutput(depth=depth, auxiliary=MappingProxyType(auxiliary)))
        return tuple(results)
