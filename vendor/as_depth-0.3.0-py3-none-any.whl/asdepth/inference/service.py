"""数据批到 PredictionArtifact 的正式 infer() 服务。"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from pathlib import Path
from types import MappingProxyType
from typing import Any

from asdepth.artifacts import PredictionArtifact
from asdepth.core import ContractError, InferenceOutput, RgbdBatch, RgbdSample
from asdepth.core.serialization import frozen_mapping
from asdepth.data import collate_rgbd_samples
from asdepth.runtime import RuntimeBackend

from .artifacts import LegacyPredictionLayout, PredictionWriter
from .postprocess import DepthPostprocessor
from .protocols import BatchPostprocessor, BatchPreprocessor


def _batches(source: Iterable[Any]) -> Iterator[RgbdBatch]:
    for item in source:
        if isinstance(item, RgbdBatch):
            yield item
        elif isinstance(item, RgbdSample):
            yield collate_rgbd_samples([item])
        else:
            raise ContractError(
                f"infer source must yield RgbdBatch or RgbdSample, got {type(item).__name__}"
            )


def infer(
    source: Iterable[Any],
    runtime: RuntimeBackend,
    *,
    output: str | Path,
    preprocessor: BatchPreprocessor,
    postprocessor: BatchPostprocessor | None = None,
    artifact_id: str | None = None,
    metadata: dict[str, Any] | None = None,
    compatibility_layouts: Iterable[LegacyPredictionLayout | str] = (),
    overwrite: bool = False,
) -> PredictionArtifact:
    """执行设备无关流水线并返回已落盘的 PredictionArtifact。"""

    active_postprocessor = postprocessor or DepthPostprocessor()
    writer = PredictionWriter(
        output,
        model=runtime.model_spec,
        artifact_id=artifact_id,
        metadata=metadata,
        compatibility_layouts=compatibility_layouts,
        overwrite=overwrite,
    )
    for batch in _batches(source):
        prepared = preprocessor.prepare(batch)
        runtime_output = runtime.infer(prepared.inputs)
        outputs = active_postprocessor.process(runtime_output, prepared, runtime.model_spec)
        if len(outputs) != batch.batch_size:
            raise ContractError("postprocessor output count does not match RgbdBatch")
        per_sample_timings = {
            name.removesuffix("_batch"): value / batch.batch_size
            for name, value in runtime_output.timings_ms.items()
        }
        for index, model_output in enumerate(outputs):
            sample_metadata = dict(batch.metadata[index]) if batch.metadata else {}
            sample_metadata["preprocess"] = dict(prepared.metadata)
            writer.write(
                InferenceOutput(
                    sample_id=batch.sample_ids[index],
                    model=runtime.model_spec,
                    output=model_output,
                    timings_ms=MappingProxyType(per_sample_timings),
                    metadata=frozen_mapping(sample_metadata),
                )
            )
    return writer.finalize()
