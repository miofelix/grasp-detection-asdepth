"""PredictionArtifact 的 canonical writer、reader 与逐样本索引。"""

from __future__ import annotations

import io
import json
import re
import uuid
from collections.abc import Iterable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any, ClassVar, cast

import numpy as np
from numpy.typing import NDArray

from asdepth.artifacts import (
    PredictionArtifact,
    atomic_write_bytes,
    atomic_write_json,
    atomic_write_text,
    safe_join,
    sha256_file,
    utc_now,
    validate_filename_component,
    validate_manifest,
)
from asdepth.compat import LogDepthDecodeMode, decode_log_depth_3ch
from asdepth.core import ContractError, DepthMap, DepthRepresentation, DepthSpec, InferenceOutput
from asdepth.core.serialization import (
    frozen_mapping,
    require_exact_keys,
    require_schema_version,
    to_primitive,
)

_AUXILIARY_NAME = re.compile(r"^[A-Za-z0-9_.-]+$")


class LegacyPredictionLayout(str, Enum):
    """旧 evaluator 仍可读取的两种 `.npy` 目录布局。"""

    FLAT = "legacy-flat"
    PREDICTIONS = "legacy-predictions"


def _sample_basename(sample_id: str) -> str:
    return validate_filename_component(sample_id, field="sample_id")


def _npy_bytes(value: NDArray[Any]) -> bytes:
    stream = io.BytesIO()
    np.save(stream, np.asarray(value), allow_pickle=False)
    return stream.getvalue()


def _readonly(value: NDArray[Any]) -> NDArray[Any]:
    result = np.array(value, copy=True, order="C")
    result.setflags(write=False)
    return result


@dataclass(frozen=True, slots=True)
class PredictionRecord:
    """`samples.jsonl` 中单行的版本化索引记录。"""

    SCHEMA_VERSION: ClassVar[str] = "1.0.0"

    sample_id: str
    array: str
    shape: tuple[int, ...]
    dtype: str
    auxiliary: MappingProxyType[str, str] = field(default_factory=lambda: MappingProxyType({}))
    timings_ms: MappingProxyType[str, float] = field(default_factory=lambda: MappingProxyType({}))
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema_version != self.SCHEMA_VERSION:
            raise ContractError(f"PredictionRecord requires schema {self.SCHEMA_VERSION}")
        _sample_basename(self.sample_id)
        if not self.array or not self.shape or any(int(value) <= 0 for value in self.shape):
            raise ContractError("prediction array path and positive shape are required")
        object.__setattr__(self, "shape", tuple(int(value) for value in self.shape))
        auxiliary = MappingProxyType(
            {str(key): str(value) for key, value in self.auxiliary.items()}
        )
        if any(not _AUXILIARY_NAME.fullmatch(name) for name in auxiliary):
            raise ContractError("prediction auxiliary names must be safe identifiers")
        object.__setattr__(self, "auxiliary", auxiliary)
        timings = MappingProxyType(
            {str(key): float(value) for key, value in self.timings_ms.items()}
        )
        if any(value < 0 for value in timings.values()):
            raise ContractError("prediction timings cannot be negative")
        object.__setattr__(self, "timings_ms", timings)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    def to_dict(self) -> dict[str, Any]:
        return cast(dict[str, Any], to_primitive(self))

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> PredictionRecord:
        require_exact_keys(
            payload,
            required={
                "schema_version",
                "sample_id",
                "array",
                "shape",
                "dtype",
                "auxiliary",
                "timings_ms",
                "metadata",
            },
            context="PredictionRecord",
        )
        require_schema_version(payload, context="PredictionRecord")
        values = dict(payload)
        values["shape"] = tuple(payload["shape"])
        values["auxiliary"] = MappingProxyType(dict(payload["auxiliary"]))
        values["timings_ms"] = MappingProxyType(dict(payload["timings_ms"]))
        values["metadata"] = frozen_mapping(dict(payload["metadata"]))
        return cls(**values)


@dataclass(frozen=True, slots=True)
class LoadedPrediction:
    """保留落盘非有限值 mask 的读取结果。"""

    sample_id: str
    depth: DepthMap
    finite_mask: NDArray[np.bool_]
    path: Path
    record: PredictionRecord | None = None

    def __post_init__(self) -> None:
        mask = np.asarray(self.finite_mask, dtype=bool)
        if mask.shape != self.depth.shape:
            raise ContractError("prediction finite mask must match depth shape")
        object.__setattr__(self, "finite_mask", _readonly(mask))


class PredictionWriter:
    """写 `predictions/manifest.json + samples.jsonl + arrays/`。"""

    def __init__(
        self,
        output_root: str | Path,
        *,
        model: Any,
        artifact_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        compatibility_layouts: Iterable[LegacyPredictionLayout | str] = (),
        overwrite: bool = False,
    ) -> None:
        from asdepth.core import ModelSpec

        if not isinstance(model, ModelSpec):
            raise ContractError("PredictionWriter model must be ModelSpec")
        self.output_root = Path(output_root).expanduser().resolve()
        self.root = self.output_root / "predictions"
        self.arrays = self.root / "arrays"
        self.root.mkdir(parents=True, exist_ok=True)
        self.arrays.mkdir(parents=True, exist_ok=True)
        self.model = model
        self.artifact_id = artifact_id or f"prediction-{uuid.uuid4().hex}"
        self.metadata = dict(metadata or {})
        self.compatibility_layouts = frozenset(
            value if isinstance(value, LegacyPredictionLayout) else LegacyPredictionLayout(value)
            for value in compatibility_layouts
        )
        self.overwrite = overwrite
        self._records: list[PredictionRecord] = []
        self._sample_ids: set[str] = set()
        self._checksums: dict[str, str] = {}
        self._finalized = False

    @property
    def manifest_path(self) -> Path:
        return self.root / "manifest.json"

    def _write_array(self, relative: str, values: NDArray[Any]) -> Path:
        path = safe_join(self.root, relative)
        atomic_write_bytes(path, _npy_bytes(values), overwrite=self.overwrite)
        self._checksums[relative] = sha256_file(path)
        return path

    def _write_compatibility_array(
        self,
        sample_id: str,
        values: NDArray[Any],
        *,
        suffix: str = "",
    ) -> None:
        filename = f"{sample_id}{suffix}.npy"
        payload = _npy_bytes(values)
        if LegacyPredictionLayout.FLAT in self.compatibility_layouts:
            atomic_write_bytes(
                self.output_root / filename,
                payload,
                overwrite=self.overwrite,
            )
        if LegacyPredictionLayout.PREDICTIONS in self.compatibility_layouts:
            atomic_write_bytes(
                self.root / filename,
                payload,
                overwrite=self.overwrite,
            )

    def write(self, output: InferenceOutput) -> PredictionRecord:
        if self._finalized:
            raise ContractError("cannot write after PredictionWriter.finalize()")
        if output.model != self.model:
            raise ContractError("InferenceOutput model does not match PredictionWriter model")
        sample_id = _sample_basename(output.sample_id)
        if sample_id in self._sample_ids:
            raise ContractError(f"duplicate prediction sample_id {sample_id!r}")
        depth = output.output.depth
        if depth.spec.representation is not DepthRepresentation.METRIC_DEPTH:
            raise ContractError("canonical PredictionArtifact stores decoded metric depth")

        relative = f"arrays/{sample_id}.npy"
        self._write_array(relative, depth.values)
        self._write_compatibility_array(sample_id, depth.values)
        auxiliary_paths: dict[str, str] = {}
        for name, values in output.output.auxiliary.items():
            if not _AUXILIARY_NAME.fullmatch(name):
                raise ContractError(f"unsafe auxiliary output name {name!r}")
            auxiliary_relative = f"arrays/{sample_id}__{name}.npy"
            self._write_array(auxiliary_relative, values)
            auxiliary_paths[name] = auxiliary_relative
            if name == "raw_log_depth_3ch":
                self._write_compatibility_array(sample_id, values, suffix="_3ch")

        record = PredictionRecord(
            sample_id=sample_id,
            array=relative,
            shape=depth.shape,
            dtype=str(depth.values.dtype),
            auxiliary=MappingProxyType(auxiliary_paths),
            timings_ms=output.timings_ms,
            metadata=output.metadata,
        )
        self._records.append(record)
        self._sample_ids.add(sample_id)
        return record

    def finalize(self) -> PredictionArtifact:
        if self._finalized:
            raise ContractError("PredictionWriter.finalize() can only be called once")
        samples_payload = "".join(
            json.dumps(record.to_dict(), ensure_ascii=False, sort_keys=True) + "\n"
            for record in self._records
        )
        samples_path = atomic_write_text(
            self.root / "samples.jsonl",
            samples_payload,
            overwrite=self.overwrite,
        )
        self._checksums["samples.jsonl"] = sha256_file(samples_path)
        artifact = PredictionArtifact(
            artifact_id=self.artifact_id,
            created_at=utc_now(),
            model=self.model,
            depth=DepthSpec.metric(),
            arrays_dir="arrays",
            samples_file="samples.jsonl",
            sample_count=len(self._records),
            checksums=MappingProxyType(dict(sorted(self._checksums.items()))),
            metadata=frozen_mapping(
                {
                    **self.metadata,
                    "compatibility_layouts": sorted(
                        value.value for value in self.compatibility_layouts
                    ),
                }
            ),
        )
        payload = artifact.to_dict()
        validate_manifest(payload, "prediction")
        atomic_write_json(self.manifest_path, payload, overwrite=self.overwrite)
        self._finalized = True
        return artifact


class PredictionReader:
    """按 manifest > legacy predictions > legacy flat 优先级读取预测。"""

    def __init__(self, root: str | Path, *, verify_checksums: bool = True) -> None:
        requested = Path(root).expanduser().resolve()
        self.verify_checksums = verify_checksums
        self.artifact: PredictionArtifact | None
        canonical_root = (
            requested / "predictions"
            if (requested / "predictions" / "manifest.json").is_file()
            else requested
        )
        manifest_path = canonical_root / "manifest.json"
        if manifest_path.is_file():
            self.layout = "manifest"
            self.root = canonical_root
            self.artifact = self._load_manifest(manifest_path)
            self._records = self._load_records()
            return

        legacy_predictions = requested / "predictions"
        if legacy_predictions.is_dir() and any(legacy_predictions.glob("*.npy")):
            self.layout = LegacyPredictionLayout.PREDICTIONS.value
            self.root = legacy_predictions
        elif requested.is_dir() and any(requested.glob("*.npy")):
            self.layout = LegacyPredictionLayout.FLAT.value
            self.root = requested
        else:
            raise FileNotFoundError(
                f"no prediction manifest or legacy .npy files found under {requested}"
            )
        self.artifact = None
        self._records = self._load_legacy_records()

    def _load_manifest(self, manifest_path: Path) -> PredictionArtifact:
        with manifest_path.open(encoding="utf-8") as stream:
            payload = json.load(stream)
        if not isinstance(payload, dict):
            raise ContractError("prediction manifest must be a JSON object")
        validate_manifest(payload, "prediction")
        return PredictionArtifact.from_dict(payload)

    def _verify(self, relative: str, path: Path) -> None:
        if not self.verify_checksums:
            return
        if self.artifact is None:
            return
        expected = self.artifact.checksums.get(relative)
        if expected is not None and sha256_file(path) != expected:
            raise ContractError(f"prediction checksum mismatch: {path}")

    def _load_records(self) -> dict[str, PredictionRecord]:
        if self.artifact is None:
            raise ContractError("canonical records require PredictionArtifact")
        samples_path = safe_join(self.root, self.artifact.samples_file)
        if not samples_path.is_file():
            raise FileNotFoundError(samples_path)
        self._verify(self.artifact.samples_file, samples_path)
        records: dict[str, PredictionRecord] = {}
        with samples_path.open(encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, start=1):
                if not line.strip():
                    continue
                payload = json.loads(line)
                if not isinstance(payload, dict):
                    raise ContractError(f"samples.jsonl line {line_number} must be an object")
                record = PredictionRecord.from_dict(payload)
                if record.sample_id in records:
                    raise ContractError(f"duplicate prediction record {record.sample_id!r}")
                records[record.sample_id] = record
        if len(records) != self.artifact.sample_count:
            raise ContractError(
                "prediction sample_count does not match samples.jsonl: "
                f"{self.artifact.sample_count} vs {len(records)}"
            )
        return records

    def _load_legacy_records(self) -> dict[str, PredictionRecord]:
        records: dict[str, PredictionRecord] = {}
        for path in sorted(self.root.glob("*.npy")):
            if path.stem.endswith("_3ch"):
                continue
            sample_id = _sample_basename(path.stem)
            raw_path = self.root / f"{sample_id}_3ch.npy"
            auxiliary = (
                MappingProxyType({"raw_log_depth_3ch": raw_path.name})
                if raw_path.is_file()
                else MappingProxyType({})
            )
            values = np.load(path, allow_pickle=False, mmap_mode="r")
            records[sample_id] = PredictionRecord(
                sample_id=sample_id,
                array=path.name,
                shape=tuple(int(value) for value in values.shape),
                dtype=str(values.dtype),
                auxiliary=auxiliary,
                metadata=frozen_mapping({"legacy_layout": self.layout}),
            )
        if not records:
            raise ContractError(
                f"legacy prediction directory has no decoded .npy files: {self.root}"
            )
        return records

    @property
    def sample_ids(self) -> tuple[str, ...]:
        return tuple(self._records)

    def record(self, sample_id: str) -> PredictionRecord:
        try:
            return self._records[sample_id]
        except KeyError as exc:
            raise KeyError(f"prediction sample not found: {sample_id}") from exc

    def read_array(self, sample_id: str, *, auxiliary: str | None = None) -> NDArray[Any]:
        record = self.record(sample_id)
        relative = record.array if auxiliary is None else record.auxiliary[auxiliary]
        path = safe_join(self.root, relative)
        if not path.is_file():
            raise FileNotFoundError(path)
        self._verify(relative, path)
        return cast(NDArray[Any], np.load(path, allow_pickle=False))

    def _decode_log_depth(
        self,
        values: NDArray[Any],
        mode: LogDepthDecodeMode,
    ) -> DepthMap:
        array = np.asarray(values, dtype=np.float32)
        if array.ndim == 3 and array.shape[0] == 3:
            pass
        elif array.ndim == 3 and array.shape[-1] == 3:
            array = np.moveaxis(array, -1, 0)
        if array.ndim != 3 or array.shape[0] != 3:
            raise ContractError(f"raw 3ch prediction must be 3xHxW or HxWx3, got {array.shape}")
        return decode_log_depth_3ch(DepthMap(array, DepthSpec.log_depth_3ch()), mode)

    def load(
        self,
        sample_id: str,
        *,
        decode_mode: LogDepthDecodeMode | str | None = None,
    ) -> LoadedPrediction:
        record = self.record(sample_id)
        path = safe_join(self.root, record.array)
        mode = (
            decode_mode
            if isinstance(decode_mode, LogDepthDecodeMode)
            else LogDepthDecodeMode(decode_mode)
            if decode_mode is not None
            else None
        )
        if mode is not None and "raw_log_depth_3ch" in record.auxiliary:
            raw = self.read_array(sample_id, auxiliary="raw_log_depth_3ch")
            depth = self._decode_log_depth(raw, mode)
            return LoadedPrediction(
                sample_id=sample_id,
                depth=depth,
                finite_mask=np.isfinite(depth.values),
                path=safe_join(self.root, record.auxiliary["raw_log_depth_3ch"]),
                record=record,
            )
        if mode is LogDepthDecodeMode.C2_METRIC:
            raise ContractError(
                f"sample {sample_id!r} has no raw *_3ch.npy output required for c2_metric"
            )

        values = np.asarray(self.read_array(sample_id), dtype=np.float32)
        if values.ndim == 3 and values.shape[0] == 1:
            values = values[0]
        if values.ndim != 2:
            raise ContractError(f"decoded metric prediction must be HxW, got {values.shape}")
        finite = np.isfinite(values)
        native_spec = self.artifact.depth if self.artifact is not None else DepthSpec.metric()
        native = DepthMap(values, native_spec)
        depth = native.to_metric()
        return LoadedPrediction(
            sample_id=sample_id,
            depth=depth,
            finite_mask=finite,
            path=path,
            record=record,
        )

    def read(
        self,
        sample_id: str,
        *,
        decode_mode: LogDepthDecodeMode | str | None = None,
    ) -> DepthMap:
        return self.load(sample_id, decode_mode=decode_mode).depth
