"""RGB-only hole/noise 模型加载与 synthetic raw depth 合成语义。"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any, cast

import cv2
import numpy as np
import torch
from numpy.typing import NDArray

from asdepth.core import ContractError
from asdepth.models import CheckpointLoader, LoadedCheckpoint, StateDictKeyMapper

from .loading import select_inference_device

AFFINE_UNSCALE_MIN_VALID_PIXELS = 32


class SyntheticRawModelKind(str, Enum):
    """合成 raw depth 的两个 RGB-only 模型角色。"""

    HOLE = "hole"
    NOISE = "noise"


@dataclass(frozen=True, slots=True)
class SyntheticRawEncoderSpec:
    """源 Hole/Noise checkpoint 使用的 DINOv2 结构参数。"""

    encoder: str
    features: int
    out_channels: tuple[int, int, int, int]

    def constructor_kwargs(self) -> dict[str, Any]:
        return {
            "encoder": self.encoder,
            "features": self.features,
            "out_channels": self.out_channels,
        }


SYNTHETIC_RAW_ENCODERS: Mapping[str, SyntheticRawEncoderSpec] = MappingProxyType(
    {
        "vits": SyntheticRawEncoderSpec("vits", 64, (48, 96, 192, 384)),
        "vitb": SyntheticRawEncoderSpec("vitb", 128, (96, 192, 384, 768)),
        "vitl": SyntheticRawEncoderSpec("vitl", 256, (256, 512, 1024, 1024)),
        "vitg": SyntheticRawEncoderSpec("vitg", 384, (1536, 1536, 1536, 1536)),
    }
)


@dataclass(frozen=True, slots=True)
class LoadedSyntheticRawModel:
    """专用模型及 checkpoint 兼容报告。"""

    model: torch.nn.Module
    checkpoint: LoadedCheckpoint
    kind: SyntheticRawModelKind
    encoder: SyntheticRawEncoderSpec
    device: torch.device
    missing_keys: tuple[str, ...]
    unexpected_keys: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class AffineDepthAlignment:
    """Noise 模型相对值到 GT metric depth 的最小二乘恢复结果。"""

    depth: NDArray[np.float32]
    scale: float
    shift: float
    valid_pixel_count: int


@dataclass(frozen=True, slots=True)
class SyntheticRawDepth:
    """Hole/Noise 组合结果及可审计的中间数组。"""

    depth: NDArray[np.float32]
    aligned_gt_depth: NDArray[np.float32]
    hole_probability: NDArray[np.float32]
    noise_prediction: NDArray[np.float32]
    affine_depth: NDArray[np.float32]
    valid_mask: NDArray[np.bool_]
    affine_scale: float
    affine_shift: float
    fit_valid_pixels: int


def _model_class(kind: SyntheticRawModelKind) -> type[torch.nn.Module]:
    if kind is SyntheticRawModelKind.HOLE:
        from asdepth.models.variants.synthetic_raw import HoleRGBDepth

        return cast(type[torch.nn.Module], HoleRGBDepth)
    from asdepth.models.variants.synthetic_raw import NoiseRGBDepth

    return cast(type[torch.nn.Module], NoiseRGBDepth)


def load_synthetic_raw_model(
    checkpoint: str | Path,
    *,
    kind: SyntheticRawModelKind | str,
    encoder: str = "vitl",
    device: str | torch.device | None = None,
    strict: bool = False,
    verify_checksums: bool = True,
    trusted_pickle: bool = False,
) -> LoadedSyntheticRawModel:
    """使用统一安全 checkpoint loader 构建源 Hole/Noise 模型。"""

    try:
        resolved_kind = SyntheticRawModelKind(kind)
    except ValueError as exc:
        raise ContractError(f"unknown synthetic raw model kind: {kind!r}") from exc
    try:
        encoder_spec = SYNTHETIC_RAW_ENCODERS[encoder]
    except KeyError as exc:
        raise ContractError(
            f"unknown synthetic raw encoder {encoder!r}; available={sorted(SYNTHETIC_RAW_ENCODERS)}"
        ) from exc

    active_device = select_inference_device(device)
    loaded = CheckpointLoader().load(
        checkpoint,
        verify_checksums=verify_checksums,
        trusted_pickle=trusted_pickle,
    )
    model_class = _model_class(resolved_kind)
    if loaded.manifest is not None:
        expected_entrypoint = f"{model_class.__module__}:{model_class.__name__}"
        if loaded.manifest.model.entrypoint != expected_entrypoint:
            raise ContractError(
                "synthetic raw checkpoint manifest entrypoint mismatch: "
                f"expected {expected_entrypoint!r}, got "
                f"{loaded.manifest.model.entrypoint!r}"
            )
    model = model_class(**encoder_spec.constructor_kwargs())
    mapped = StateDictKeyMapper(strip_prefixes=("module.", "state_dict.")).map(loaded.state_dict)
    incompatible = model.load_state_dict(mapped, strict=strict)
    model = model.to(active_device).eval()
    return LoadedSyntheticRawModel(
        model=model,
        checkpoint=loaded,
        kind=resolved_kind,
        encoder=encoder_spec,
        device=active_device,
        missing_keys=tuple(incompatible.missing_keys),
        unexpected_keys=tuple(incompatible.unexpected_keys),
    )


def _single_channel(value: NDArray[Any], *, name: str) -> NDArray[np.float32]:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim == 3 and array.shape[0] == 1:
        array = array[0]
    elif array.ndim == 3 and array.shape[-1] == 1:
        array = array[..., 0]
    if array.ndim != 2:
        raise ContractError(f"{name} must be single-channel 2D, got {array.shape}")
    return np.ascontiguousarray(array, dtype=np.float32)


def _resize_nearest(
    value: NDArray[np.float32],
    target_hw: tuple[int, int],
) -> NDArray[np.float32]:
    if target_hw[0] < 1 or target_hw[1] < 1:
        raise ContractError(f"target shape must be positive, got {target_hw}")
    if value.shape == target_hw:
        return np.ascontiguousarray(value, dtype=np.float32)
    return np.ascontiguousarray(
        cv2.resize(
            value,
            (target_hw[1], target_hw[0]),
            interpolation=cv2.INTER_NEAREST,
        ),
        dtype=np.float32,
    )


def affine_align_value_depth(
    value_depth: NDArray[Any],
    gt_depth: NDArray[Any],
    *,
    min_depth: float,
    max_depth: float,
    min_valid_pixels: int = AFFINE_UNSCALE_MIN_VALID_PIXELS,
) -> AffineDepthAlignment:
    """拟合 ``gt = scale * value + shift``，不裁剪恢复后的深度范围。"""

    if min_depth < 0 or max_depth <= min_depth:
        raise ContractError("depth range must satisfy 0 <= min_depth < max_depth")
    if min_valid_pixels < 1:
        raise ContractError("min_valid_pixels must be positive")
    values = _single_channel(value_depth, name="value_depth")
    target = _single_channel(gt_depth, name="gt_depth")
    if values.shape != target.shape:
        raise ContractError(
            f"value_depth and gt_depth shapes differ: {values.shape} vs {target.shape}"
        )

    fit_mask = (
        np.isfinite(values)
        & np.isfinite(target)
        & (target > 0)
        & (target >= np.float32(min_depth))
        & (target <= np.float32(max_depth))
    )
    valid_count = int(fit_mask.sum())
    if valid_count < min_valid_pixels:
        raise ContractError(
            f"not enough valid pixels for affine alignment: {valid_count} < {min_valid_pixels}"
        )

    value_valid = values[fit_mask].reshape(-1, 1).astype(np.float64)
    gt_valid = target[fit_mask].reshape(-1, 1).astype(np.float64)
    design = np.concatenate((value_valid, np.ones_like(value_valid)), axis=1)
    coefficients = np.linalg.lstsq(design, gt_valid, rcond=None)[0].reshape(-1)
    scale, shift = float(coefficients[0]), float(coefficients[1])
    aligned = (scale * values.astype(np.float64) + shift).astype(np.float32)
    aligned[~np.isfinite(aligned)] = 0.0
    return AffineDepthAlignment(
        depth=np.ascontiguousarray(aligned, dtype=np.float32),
        scale=scale,
        shift=shift,
        valid_pixel_count=valid_count,
    )


def mask_depth_with_hole_probability(
    depth: NDArray[Any],
    hole_probability: NDArray[Any],
    *,
    hole_threshold: float = 0.5,
) -> NDArray[np.float32]:
    """把非负 depth 对齐到 Hole 输出，并按概率阈值置零。"""

    if not 0.0 <= hole_threshold <= 1.0:
        raise ContractError("hole_threshold must be in [0, 1]")
    holes = _single_channel(hole_probability, name="hole_probability")
    target = _resize_nearest(
        _single_channel(depth, name="depth"),
        cast(tuple[int, int], holes.shape),
    ).copy()
    target[(~np.isfinite(target)) | (target < 0)] = 0.0
    valid_mask = np.isfinite(holes) & (holes < np.float32(hole_threshold))
    return np.ascontiguousarray(target * valid_mask.astype(np.float32), dtype=np.float32)


def compose_synthetic_raw_depth(
    hole_probability: NDArray[Any],
    noise_prediction: NDArray[Any],
    gt_depth: NDArray[Any],
    *,
    min_depth: float,
    max_depth: float,
    hole_threshold: float = 0.5,
    min_valid_pixels: int = AFFINE_UNSCALE_MIN_VALID_PIXELS,
) -> SyntheticRawDepth:
    """恢复 Noise metric 尺度，再用 ``hole_probability < threshold`` 生成 raw depth。"""

    if not 0.0 <= hole_threshold <= 1.0:
        raise ContractError("hole_threshold must be in [0, 1]")
    holes = _single_channel(hole_probability, name="hole_probability")
    target_hw = cast(tuple[int, int], holes.shape)
    noise = _resize_nearest(
        _single_channel(noise_prediction, name="noise_prediction"),
        target_hw,
    )
    target = _resize_nearest(_single_channel(gt_depth, name="gt_depth"), target_hw)
    alignment = affine_align_value_depth(
        noise,
        target,
        min_depth=min_depth,
        max_depth=max_depth,
        min_valid_pixels=min_valid_pixels,
    )
    valid_mask = np.isfinite(holes) & (holes < np.float32(hole_threshold))
    depth = alignment.depth * valid_mask.astype(np.float32)
    depth[~np.isfinite(depth)] = 0.0
    return SyntheticRawDepth(
        depth=np.ascontiguousarray(depth, dtype=np.float32),
        aligned_gt_depth=target,
        hole_probability=holes,
        noise_prediction=noise,
        affine_depth=alignment.depth,
        valid_mask=np.ascontiguousarray(valid_mask, dtype=np.bool_),
        affine_scale=alignment.scale,
        affine_shift=alignment.shift,
        fit_valid_pixels=alignment.valid_pixel_count,
    )


__all__ = [
    "AFFINE_UNSCALE_MIN_VALID_PIXELS",
    "SYNTHETIC_RAW_ENCODERS",
    "AffineDepthAlignment",
    "LoadedSyntheticRawModel",
    "SyntheticRawDepth",
    "SyntheticRawEncoderSpec",
    "SyntheticRawModelKind",
    "affine_align_value_depth",
    "compose_synthetic_raw_depth",
    "load_synthetic_raw_model",
    "mask_depth_with_hole_probability",
]
