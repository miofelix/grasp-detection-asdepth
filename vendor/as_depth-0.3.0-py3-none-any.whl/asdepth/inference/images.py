"""内存 RGB-D 数组的稳定批预处理与 PyTorch 推理 helper。"""

from __future__ import annotations

import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal, cast

import numpy as np
import torch
from loguru import logger
from numpy.typing import NDArray

from asdepth.artifacts import validate_filename_component
from asdepth.core import ContractError, DepthSpec, RgbdSample
from asdepth.core.serialization import frozen_mapping
from asdepth.data.io import convert_metric_depth, read_metric_depth, read_rgb
from asdepth.data.transforms.legacy_dpt import LegacyDptTransform

from .preprocess import sparsify_raw_depth


def load_rgbd_images(
    rgb_path: str | Path,
    depth_path: str | Path,
    *,
    depth_scale: float,
    max_depth_m: float,
    min_depth_m: float | None = None,
) -> tuple[NDArray[np.uint8], NDArray[np.float32], NDArray[np.float32]]:
    """读取 RGB 与 raw depth，并同时返回 meter depth 和 inverse depth。"""

    if max_depth_m <= 0:
        raise ContractError("max_depth_m must be positive")
    metric = read_metric_depth(
        depth_path,
        depth_scale=depth_scale,
        min_valid=min_depth_m,
        max_valid=max_depth_m,
    )
    inverse = metric.to_inverse()
    return read_rgb(rgb_path), metric.values, inverse.values


def load_rgbd_sample(
    rgb_path: str | Path,
    depth_path: str | Path,
    *,
    sample_id: str | None = None,
    depth_scale: float = 1000.0,
    max_depth_m: float = 6.0,
    min_depth_m: float | None = None,
    raw_depth: DepthSpec | None = None,
) -> RgbdSample:
    """读取单个 RGB-D 文件对，并转换成显式 raw-depth 语义的 canonical sample。"""

    rgb_source = Path(rgb_path).expanduser().resolve()
    depth_source = Path(depth_path).expanduser().resolve()
    metric = read_metric_depth(
        depth_source,
        depth_scale=depth_scale,
        min_valid=min_depth_m,
        max_valid=max_depth_m,
    )
    requested = raw_depth or DepthSpec.metric()
    resolved_sample_id = validate_filename_component(
        sample_id or rgb_source.stem,
        field="sample_id",
    )
    return RgbdSample(
        sample_id=resolved_sample_id,
        rgb=read_rgb(rgb_source),
        raw_depth=convert_metric_depth(metric, requested),
        metadata=frozen_mapping(
            {
                "input_mode": "rgbd_image_pair",
                "rgb_path": str(rgb_source),
                "depth_path": str(depth_source),
                "depth_scale": depth_scale,
                "max_depth_m": max_depth_m,
                "min_depth_m": min_depth_m,
            }
        ),
    )


def _rgb_hwc(value: NDArray[Any]) -> NDArray[np.uint8]:
    array = np.asarray(value)
    if array.ndim != 3 or array.shape[-1] != 3:
        raise ContractError(f"RGB input must be HWC with three channels, got {array.shape}")
    if not np.issubdtype(array.dtype, np.integer):
        raise ContractError("RGB input must use integer 0-255 values")
    return np.ascontiguousarray(array, dtype=np.uint8)


def _depth_hw(value: NDArray[Any], shape: tuple[int, int]) -> NDArray[np.float32]:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim == 3 and array.shape[0] == 1:
        array = array[0]
    elif array.ndim == 3 and array.shape[-1] == 1:
        array = array[..., 0]
    if array.shape != shape:
        raise ContractError(f"RGB/depth spatial mismatch: rgb={shape}, depth={array.shape}")
    result = np.ascontiguousarray(array, dtype=np.float32)
    result[~np.isfinite(result)] = 0.0
    result[result < 0.0] = 0.0
    return result


def prepare_rgbd_images(
    rgb_images: Sequence[NDArray[Any]],
    depth_images: Sequence[NDArray[Any]],
    *,
    input_size: int = 518,
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound",
    sparse_raw_depth: bool = False,
    generator: torch.Generator | None = None,
    device: str | torch.device | None = None,
) -> tuple[torch.Tensor, tuple[tuple[int, int], ...]]:
    """把等长 RGB/depth 序列转为单输入 ``rgbd_input`` NCHW tensor。"""

    if not rgb_images or len(rgb_images) != len(depth_images):
        raise ContractError("rgb_images and depth_images must have the same non-zero length")
    transform = LegacyDptTransform(
        image_size=input_size,
        resize_method=resize_method,
    )
    tensors: list[torch.Tensor] = []
    original_shapes: list[tuple[int, int]] = []
    transformed_shapes: set[tuple[int, int]] = set()
    for rgb_value, depth_value in zip(rgb_images, depth_images, strict=True):
        rgb = _rgb_hwc(rgb_value)
        shape = (int(rgb.shape[0]), int(rgb.shape[1]))
        depth = _depth_hw(depth_value, shape)
        chw, resized_depth = transform.prepare_input(rgb, depth)
        transformed_shapes.add((int(chw.shape[1]), int(chw.shape[2])))
        tensors.append(
            torch.from_numpy(
                np.concatenate((chw, resized_depth[None]), axis=0).astype(
                    np.float32,
                    copy=False,
                )
            )
        )
        original_shapes.append(shape)
    if len(transformed_shapes) != 1:
        raise ContractError(
            "images in one batch resize to different shapes; bucket by source aspect ratio"
        )
    batch = torch.stack(tensors)
    if sparse_raw_depth:
        batch = sparsify_raw_depth(batch, generator=generator)
    if device is not None:
        active_device = torch.device(device)
        batch = batch.to(
            active_device,
            non_blocking=active_device.type == "cuda",
        )
    return batch, tuple(original_shapes)


def prepare_rgb_images(
    rgb_images: Sequence[NDArray[Any]],
    *,
    input_size: int = 518,
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound",
    device: str | torch.device | None = None,
) -> tuple[torch.Tensor, tuple[tuple[int, int], ...]]:
    """把等比例 RGB 图像转为 RGB-only 模型使用的 NCHW tensor。"""

    if not rgb_images:
        raise ContractError("rgb_images must be non-empty")
    transform = LegacyDptTransform(
        image_size=input_size,
        resize_method=resize_method,
    )
    tensors: list[torch.Tensor] = []
    original_shapes: list[tuple[int, int]] = []
    transformed_shapes: set[tuple[int, int]] = set()
    for rgb_value in rgb_images:
        rgb = _rgb_hwc(rgb_value)
        shape = (int(rgb.shape[0]), int(rgb.shape[1]))
        chw = transform.prepare_rgb(rgb)
        transformed_shapes.add((int(chw.shape[1]), int(chw.shape[2])))
        tensors.append(torch.from_numpy(chw))
        original_shapes.append(shape)
    if len(transformed_shapes) != 1:
        raise ContractError(
            "images in one batch resize to different shapes; bucket by source aspect ratio"
        )
    batch = torch.stack(tensors)
    if device is not None:
        active_device = torch.device(device)
        batch = batch.to(
            active_device,
            non_blocking=active_device.type == "cuda",
        )
    return batch, tuple(original_shapes)


def _model_device(model: torch.nn.Module) -> torch.device:
    try:
        return next(model.parameters()).device
    except StopIteration:
        return torch.device("cpu")


def _primary_tensor(value: Any) -> torch.Tensor:
    if isinstance(value, dict):
        if not value:
            raise ContractError("model returned an empty output mapping")
        value = next(iter(value.values()))
    elif isinstance(value, tuple | list):
        if not value:
            raise ContractError("model returned an empty output sequence")
        value = value[0]
    if not isinstance(value, torch.Tensor):
        raise ContractError(
            f"model primary output must be torch.Tensor, got {type(value).__name__}"
        )
    if value.ndim == 4 and value.shape[1] == 1:
        value = value[:, 0]
    if value.ndim != 3:
        raise ContractError(f"model primary depth output must be NHW or N1HW, got {value.shape}")
    return cast(torch.Tensor, value)


def infer_rgbd_images(
    model: torch.nn.Module,
    rgb_images: Sequence[NDArray[Any]],
    depth_images: Sequence[NDArray[Any]],
    *,
    input_size: int = 518,
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound",
    sparse_raw_depth: bool = False,
    generator: torch.Generator | None = None,
    device: str | torch.device | None = None,
    log_stats: bool = False,
) -> tuple[NDArray[np.float32], ...]:
    """执行一次模型 forward，并按 nearest 恢复每个输入的原始尺寸。"""

    active_device = torch.device(device) if device is not None else _model_device(model)
    batch, original_shapes = prepare_rgbd_images(
        rgb_images,
        depth_images,
        input_size=input_size,
        resize_method=resize_method,
        sparse_raw_depth=sparse_raw_depth,
        generator=generator,
        device=active_device,
    )
    if active_device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.synchronize(active_device)
    started = time.perf_counter()
    with torch.inference_mode():
        predictions = _primary_tensor(model(batch))
    if active_device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.synchronize(active_device)
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    if predictions.shape[0] != len(original_shapes):
        raise ContractError("model output batch dimension does not match RGB-D inputs")
    if log_stats:
        logger.info(
            "Forward pass: {:.2f} ms for batch_size={} ({:.2f} ms/image, {:.2f} FPS)",
            elapsed_ms,
            len(original_shapes),
            elapsed_ms / len(original_shapes),
            1000.0 * len(original_shapes) / max(elapsed_ms, 1e-9),
        )
    results: list[NDArray[np.float32]] = []
    for prediction, shape in zip(predictions, original_shapes, strict=True):
        resized = torch.nn.functional.interpolate(
            prediction[None, None],
            shape,
            mode="nearest",
        )[0, 0]
        results.append(np.ascontiguousarray(resized.detach().cpu().numpy(), dtype=np.float32))
    return tuple(results)


def infer_rgb_images(
    model: torch.nn.Module,
    rgb_images: Sequence[NDArray[Any]],
    *,
    input_size: int = 518,
    resize_method: Literal["lower_bound", "upper_bound"] = "lower_bound",
    device: str | torch.device | None = None,
    log_stats: bool = False,
) -> tuple[NDArray[np.float32], ...]:
    """按变换尺寸自动分桶执行 RGB-only forward，并恢复原始顺序与尺寸。"""

    if not rgb_images:
        raise ContractError("rgb_images must be non-empty")
    active_device = torch.device(device) if device is not None else _model_device(model)
    transform = LegacyDptTransform(
        image_size=input_size,
        resize_method=resize_method,
    )
    buckets: dict[tuple[int, int], list[int]] = {}
    for index, rgb_value in enumerate(rgb_images):
        rgb = _rgb_hwc(rgb_value)
        width, height = transform.output_size(rgb.shape[1], rgb.shape[0])
        buckets.setdefault((height, width), []).append(index)

    if active_device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.synchronize(active_device)
    started = time.perf_counter()
    results: list[NDArray[np.float32] | None] = [None] * len(rgb_images)
    for indices in buckets.values():
        batch, original_shapes = prepare_rgb_images(
            [rgb_images[index] for index in indices],
            input_size=input_size,
            resize_method=resize_method,
            device=active_device,
        )
        with torch.inference_mode():
            predictions = _primary_tensor(model(batch))
        if predictions.shape[0] != len(indices):
            raise ContractError("model output batch dimension does not match RGB inputs")
        for index, prediction, shape in zip(
            indices,
            predictions,
            original_shapes,
            strict=True,
        ):
            resized = torch.nn.functional.interpolate(
                prediction[None, None],
                shape,
                mode="nearest",
            )[0, 0]
            results[index] = np.ascontiguousarray(
                resized.detach().cpu().numpy(),
                dtype=np.float32,
            )
    if active_device.type == "cuda" and torch.cuda.is_available():
        torch.cuda.synchronize(active_device)
    elapsed_ms = (time.perf_counter() - started) * 1000.0
    if log_stats:
        logger.info(
            "Forward pass: {:.2f} ms for images={} buckets={} ({:.2f} ms/image, {:.2f} FPS)",
            elapsed_ms,
            len(rgb_images),
            len(buckets),
            elapsed_ms / len(rgb_images),
            1000.0 * len(rgb_images) / max(elapsed_ms, 1e-9),
        )
    if any(result is None for result in results):
        raise RuntimeError("internal error: incomplete RGB inference buckets")
    return tuple(result for result in results if result is not None)
