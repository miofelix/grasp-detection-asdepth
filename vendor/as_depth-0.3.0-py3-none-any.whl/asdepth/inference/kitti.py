"""KITTI Depth Completion 输出目录命名契约。"""

from __future__ import annotations

import re
from pathlib import Path

from asdepth.core import ContractError

KITTI_SAMPLE_RE = re.compile(
    r"^(?P<date>\d{4}_\d{2}_\d{2})_drive_(?P<drive>\d{4})_sync_image_"
    r"(?P<frame>\d{10})_(?P<cam>image_0[23])(?:\.png)?$"
)


def resolve_kitti_scene_frame(
    sample_name: str | None,
    rgb_path: str | Path,
) -> tuple[str, str]:
    """从显式 ``scene-frame``、官方样本名或 RGB 文件名恢复目录名。"""

    if sample_name:
        candidate = str(sample_name)
        if "-" in candidate:
            scene, frame = candidate.split("-", 1)
            if scene and frame:
                return scene, frame
        match = KITTI_SAMPLE_RE.fullmatch(candidate)
        if match is not None:
            return (
                f"{match.group('date')}_drive_{match.group('drive')}",
                f"{match.group('frame')}_{match.group('cam')}",
            )

    path = Path(rgb_path)
    for candidate in (path.name, path.stem):
        match = KITTI_SAMPLE_RE.fullmatch(candidate)
        if match is not None:
            return (
                f"{match.group('date')}_drive_{match.group('drive')}",
                f"{match.group('frame')}_{match.group('cam')}",
            )
    raise ContractError(
        "unable to resolve KITTI scene/frame from "
        f"sample_name={sample_name!r}, rgb_path={str(rgb_path)!r}"
    )
