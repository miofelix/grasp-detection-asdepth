"""脚本说明：
作用：通过 canonical sample/Dataset、RuntimeBackend 与 PredictionArtifact 执行单图或批量推理。

典型用法：
    asdepth infer --checkpoint ckpts/model.ckpt --model defm_stackconv_depth \
        --dataset data/HAMMER/test.jsonl --dataset-id hammer --output runs/demo
    asdepth infer --checkpoint ckpts/model.ckpt --model cdm_d435_pretrained_disp \
        --rgb-image example/color.png --depth-image example/depth.png --output runs/single

参数说明：
    - --checkpoint：新 envelope、Accelerate 目录或旧单文件 checkpoint。
    - --model：manifest 不含身份且路径 fallback 不可用时显式指定 model_id。
    - --is-disp：仅为旧调用兼容；进入服务前立即转换成 DepthSpec。

环境变量/外部依赖：
    - 模型构建当前仍依赖对应 torch 模型实现；CUDA 不是导入或 --help 的前置条件。

运行注意：
    - canonical 输出固定写到 <output>/predictions/，默认拒绝覆盖已有文件。
    - metric depth invalid 固定为 0.0；不要用 --is-disp 改写未知 checkpoint 的语义。
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

import torch

from asdepth.compat import depth_spec_from_is_disp
from asdepth.core import ContractError, DepthSpec, RgbdSample
from asdepth.data import create_dataloader, create_dataset
from asdepth.models import ModelCatalog, load_model_with_report
from asdepth.runtime import TorchBackend

from .artifacts import LegacyPredictionLayout, PredictionReader
from .images import load_rgbd_sample
from .postprocess import DepthPostprocessor
from .preprocess import DptBatchPreprocessor
from .service import infer


def _device(value: str) -> torch.device:
    if value != "auto":
        return torch.device(value)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _compat_depth(value: str, fallback: DepthSpec) -> DepthSpec:
    if value == "auto":
        return fallback
    return depth_spec_from_is_disp(value == "true")


def _optional_bool(value: str, fallback: bool) -> bool:
    if value == "auto":
        return fallback
    return value == "true"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asdepth infer",
        description="运行 canonical RGB-D 单图或数据集推理并写 PredictionArtifact",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--checkpoint", "--model-path", dest="checkpoint", required=True)
    parser.add_argument("--model", dest="model_id")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--dataset", help="JSONL 数据集路径")
    source.add_argument("--rgb-image", "--rgb", dest="rgb_image", help="单图 RGB 路径")
    parser.add_argument(
        "--depth-image",
        "--raw-depth",
        dest="depth_image",
        help="与 --rgb-image 配对的单通道 raw-depth 路径",
    )
    parser.add_argument("--sample-id", help="单图 PredictionArtifact 样本 ID；默认使用 RGB 文件名")
    parser.add_argument(
        "--dataset-id",
        choices=["hammer", "clearpose", "dreds", "transcg", "transpose", "kitti"],
    )
    parser.add_argument("--output", default="output_dir")
    parser.add_argument("--raw-type", default="d435")
    parser.add_argument("--depth-scale", type=float, default=1000.0)
    parser.add_argument("--max-depth", type=float, default=6.0)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument("--input-size", type=int, default=518)
    parser.add_argument(
        "--resize-method",
        choices=["lower_bound", "upper_bound"],
        default="lower_bound",
    )
    parser.add_argument("--device", default="auto")
    parser.add_argument(
        "--is-disp",
        "--is_disp",
        choices=["auto", "true", "false"],
        default="auto",
        help="旧兼容开关；auto 使用 checkpoint/catalog 深度语义",
    )
    parser.add_argument(
        "--sparse-raw-depth",
        "--is_sparse_raw_depth",
        choices=["auto", "true", "false"],
        default="auto",
    )
    parser.add_argument("--model-registry", type=Path)
    parser.add_argument("--trusted-pickle", action="store_true")
    parser.add_argument("--no-verify-checksums", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--save-vis",
        action="store_true",
        help="为单图输入保存 RGB/raw/prediction PNG 网格",
    )
    parser.add_argument("--image-min", type=float, default=0.1)
    parser.add_argument("--image-max", type=float, default=5.0)
    parser.add_argument(
        "--compat-layout",
        choices=["none", "flat", "predictions", "both"],
        default="none",
    )
    return parser


def _validate_source_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> None:
    if args.dataset is not None:
        if args.dataset_id is None:
            parser.error("--dataset-id is required with --dataset")
        if args.depth_image is not None or args.sample_id is not None:
            parser.error("--depth-image/--sample-id require --rgb-image")
        if args.save_vis:
            parser.error("--save-vis currently requires --rgb-image")
    else:
        if args.depth_image is None:
            parser.error("--depth-image is required with --rgb-image")
        if args.dataset_id is not None:
            parser.error("--dataset-id cannot be used with --rgb-image")
    if args.depth_scale <= 0:
        parser.error("--depth-scale must be positive")
    if args.max_depth <= 0:
        parser.error("--max-depth must be positive")
    if args.image_min < 0 or args.image_max <= args.image_min:
        parser.error("--image-max must be greater than non-negative --image-min")


def _compatibility_layouts(value: str) -> tuple[LegacyPredictionLayout, ...]:
    if value == "none":
        return ()
    if value == "flat":
        return (LegacyPredictionLayout.FLAT,)
    if value == "predictions":
        return (LegacyPredictionLayout.PREDICTIONS,)
    return (LegacyPredictionLayout.FLAT, LegacyPredictionLayout.PREDICTIONS)


def _build_source(
    args: argparse.Namespace,
    *,
    native_depth: DepthSpec,
    device: torch.device,
) -> tuple[Iterable[Any], dict[str, Any], RgbdSample | None]:
    if args.dataset is not None:
        dataset = create_dataset(
            args.dataset,
            dataset_id=args.dataset_id,
            raw_type=args.raw_type,
            raw_depth=native_depth,
        )
        dataloader = create_dataloader(
            dataset,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=device.type == "cuda",
        )
        return dataloader, {"input_mode": "dataset", "dataset_id": args.dataset_id}, None

    sample = load_rgbd_sample(
        args.rgb_image,
        args.depth_image,
        sample_id=args.sample_id,
        depth_scale=args.depth_scale,
        max_depth_m=args.max_depth,
        raw_depth=native_depth,
    )
    return (
        (sample,),
        {
            "input_mode": "rgbd_image_pair",
            "rgb_image": str(Path(args.rgb_image).expanduser().resolve()),
            "depth_image": str(Path(args.depth_image).expanduser().resolve()),
            "depth_scale": args.depth_scale,
            "max_depth_m": args.max_depth,
        },
        sample,
    )


def _visualization_path(output: str | Path, sample_id: str) -> Path:
    return Path(output).expanduser().resolve() / "predictions/visualizations" / f"{sample_id}.png"


def _write_single_visualization(
    output: str | Path,
    sample: RgbdSample,
    *,
    image_min: float,
    image_max: float,
) -> Path:
    from asdepth.visualization import add_title, colorize_depth, make_grid, save_rgb_image

    prediction = PredictionReader(output).read(sample.sample_id).values
    raw_metric = sample.raw_depth.to_metric().values
    panels = (
        add_title(sample.rgb, "RGB"),
        add_title(colorize_depth(raw_metric, image_min, image_max), "Raw depth"),
        add_title(colorize_depth(prediction, image_min, image_max), "Prediction"),
    )
    target = _visualization_path(output, sample.sample_id)
    return save_rgb_image(target, make_grid(panels, ncols=3))


def _run(args: argparse.Namespace) -> int:
    catalog = ModelCatalog.from_package(legacy_path=args.model_registry)
    device = _device(args.device)
    report = load_model_with_report(
        args.checkpoint,
        model_id=args.model_id,
        device=device,
        verify_checksums=not args.no_verify_checksums,
        trusted_pickle=args.trusted_pickle,
        catalog=catalog,
    )
    native_depth = _compat_depth(args.is_disp, report.spec.depth)
    sparse_default = bool(report.spec.metadata.get("is_sparse_raw_depth", False))
    sparse = _optional_bool(args.sparse_raw_depth, sparse_default)
    source, source_metadata, single_sample = _build_source(
        args,
        native_depth=native_depth,
        device=device,
    )
    visualization_path = None
    if args.save_vis:
        assert single_sample is not None
        visualization_path = _visualization_path(args.output, single_sample.sample_id)
        if visualization_path.exists() and not args.overwrite:
            raise FileExistsError(visualization_path)
    artifact = infer(
        source,
        TorchBackend(report.model, report.spec, device=device),
        output=args.output,
        preprocessor=DptBatchPreprocessor(
            depth=native_depth,
            input_size=args.input_size,
            resize_method=args.resize_method,
            sparse_raw_depth=sparse,
        ),
        postprocessor=DepthPostprocessor(native_depth=native_depth),
        metadata={
            **source_metadata,
            "checkpoint": str(Path(args.checkpoint).expanduser().resolve()),
            "model_resolution": report.resolution.source.value,
            "native_depth": native_depth.to_dict(),
        },
        compatibility_layouts=_compatibility_layouts(args.compat_layout),
        overwrite=args.overwrite,
    )
    if args.save_vis:
        assert single_sample is not None
        visualization_path = _write_single_visualization(
            args.output,
            single_sample,
            image_min=args.image_min,
            image_max=args.image_max,
        )
    print(
        json.dumps(
            {
                "artifact_id": artifact.artifact_id,
                "input_mode": source_metadata["input_mode"],
                "sample_count": artifact.sample_count,
                "manifest": str(
                    Path(args.output).expanduser().resolve() / "predictions/manifest.json"
                ),
                "visualization": str(visualization_path) if visualization_path else None,
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if exc.code == 0:
            return 0
        raise
    _validate_source_args(parser, args)
    return _run(args)


if __name__ == "__main__":  # pragma: no cover
    try:
        raise SystemExit(main())
    except (ContractError, FileExistsError, FileNotFoundError, RuntimeError) as exc:
        raise SystemExit(str(exc)) from exc
