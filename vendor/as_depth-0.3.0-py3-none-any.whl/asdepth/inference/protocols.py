"""推理流水线的框架无关协议与批级中间类型。"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Protocol

from asdepth.core import ContractError, ModelOutput, ModelSpec, RgbdBatch
from asdepth.core.serialization import frozen_mapping
from asdepth.runtime import RuntimeBatchOutput


@dataclass(frozen=True, slots=True)
class PreparedBatch:
    """预处理后的 runtime 输入及恢复原尺寸所需上下文。"""

    batch: RgbdBatch
    inputs: Any
    original_shapes: tuple[tuple[int, int], ...]
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        shapes = tuple((int(height), int(width)) for height, width in self.original_shapes)
        if len(shapes) != self.batch.batch_size:
            raise ContractError("original_shapes length must match the prepared batch size")
        if any(height <= 0 or width <= 0 for height, width in shapes):
            raise ContractError("prepared batch spatial dimensions must be positive")
        object.__setattr__(self, "original_shapes", shapes)
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))


class BatchPreprocessor(Protocol):
    """把固定字段 RgbdBatch 转为 backend 输入。"""

    def prepare(self, batch: RgbdBatch) -> PreparedBatch: ...


class BatchPostprocessor(Protocol):
    """把 backend 原始输出恢复为逐样本 canonical ModelOutput。"""

    def process(
        self,
        output: RuntimeBatchOutput,
        prepared: PreparedBatch,
        model_spec: ModelSpec,
    ) -> tuple[ModelOutput, ...]: ...
