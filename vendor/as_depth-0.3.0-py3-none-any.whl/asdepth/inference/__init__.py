"""从数据读取到 PredictionArtifact 的推理流水线。"""

from asdepth.runtime import RuntimeBackend, RuntimeBatchOutput, TorchBackend

from .artifacts import (
    LegacyPredictionLayout,
    LoadedPrediction,
    PredictionReader,
    PredictionRecord,
    PredictionWriter,
)
from .images import (
    infer_rgb_images,
    infer_rgbd_images,
    load_rgbd_images,
    load_rgbd_sample,
    prepare_rgb_images,
    prepare_rgbd_images,
)
from .kitti import KITTI_SAMPLE_RE, resolve_kitti_scene_frame
from .loading import (
    LoadedInferenceModel,
    ResolvedInferenceModel,
    load_inference_model,
    resolve_inference_model,
    select_inference_device,
)
from .postprocess import DepthPostprocessor
from .preprocess import DptBatchPreprocessor, sparsify_raw_depth
from .protocols import (
    BatchPostprocessor,
    BatchPreprocessor,
    PreparedBatch,
)
from .service import infer
from .synthetic_raw import (
    AFFINE_UNSCALE_MIN_VALID_PIXELS,
    SYNTHETIC_RAW_ENCODERS,
    AffineDepthAlignment,
    LoadedSyntheticRawModel,
    SyntheticRawDepth,
    SyntheticRawEncoderSpec,
    SyntheticRawModelKind,
    affine_align_value_depth,
    compose_synthetic_raw_depth,
    load_synthetic_raw_model,
    mask_depth_with_hole_probability,
)

__all__ = [
    "AFFINE_UNSCALE_MIN_VALID_PIXELS",
    "KITTI_SAMPLE_RE",
    "SYNTHETIC_RAW_ENCODERS",
    "AffineDepthAlignment",
    "BatchPostprocessor",
    "BatchPreprocessor",
    "DepthPostprocessor",
    "DptBatchPreprocessor",
    "LegacyPredictionLayout",
    "LoadedInferenceModel",
    "LoadedPrediction",
    "LoadedSyntheticRawModel",
    "PredictionReader",
    "PredictionRecord",
    "PredictionWriter",
    "PreparedBatch",
    "ResolvedInferenceModel",
    "RuntimeBackend",
    "RuntimeBatchOutput",
    "SyntheticRawDepth",
    "SyntheticRawEncoderSpec",
    "SyntheticRawModelKind",
    "TorchBackend",
    "affine_align_value_depth",
    "compose_synthetic_raw_depth",
    "infer",
    "infer_rgb_images",
    "infer_rgbd_images",
    "load_inference_model",
    "load_rgbd_images",
    "load_rgbd_sample",
    "load_synthetic_raw_model",
    "mask_depth_with_hole_probability",
    "prepare_rgb_images",
    "prepare_rgbd_images",
    "resolve_inference_model",
    "resolve_kitti_scene_frame",
    "select_inference_device",
    "sparsify_raw_depth",
]
