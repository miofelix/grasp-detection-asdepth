"""Decoder gradient-checkpointing helper 的 canonical 导出。"""

from ...vendor.moge_utils import (
    sync_ddp_hook,
    unwrap_module_with_gradient_checkpointing,
    wrap_dinov2_attention_with_sdpa,
    wrap_module_with_gradient_checkpointing,
)

__all__ = [
    "sync_ddp_hook",
    "unwrap_module_with_gradient_checkpointing",
    "wrap_dinov2_attention_with_sdpa",
    "wrap_module_with_gradient_checkpointing",
]
