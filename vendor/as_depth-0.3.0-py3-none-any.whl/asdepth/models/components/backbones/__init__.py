"""RGB 与 depth encoder wrapper；具体 vendor 按 variant 惰性导入。"""
