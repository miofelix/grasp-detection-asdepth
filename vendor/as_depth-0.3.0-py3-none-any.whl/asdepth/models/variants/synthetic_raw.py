"""RGB-only hole/noise synthesis models。"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, cast

import torch
import torch.nn.functional as functional
from loguru import logger

from ..components.decoders import DPTHead
from .dino import RGBDDepth


class HoleRGBDepth(RGBDDepth):
    def __init__(
        self,
        encoder: str = "vitl",
        features: int = 256,
        out_channels: Sequence[int] = (256, 512, 1024, 1024),
        use_bn: bool = False,
        use_clstoken: bool = False,
        max_depth: float = 20.0,
        pretrained: bool = False,
        pretrained_path: str | None = None,
    ) -> None:
        super().__init__(
            encoder=encoder,
            features=features,
            out_channels=out_channels,
            use_bn=use_bn,
            use_clstoken=use_clstoken,
            max_depth=max_depth,
            pretrained=pretrained,
            pretrained_path=pretrained_path,
        )
        del self.depth_pretrained
        del self.crossAtts
        del self.depth_head_rgbd
        self.hole_head = DPTHead(
            self.pretrained.embed_dim,
            features,
            use_bn,
            out_channels=out_channels,
            use_clstoken=use_clstoken,
            sigact_out=True,
        )
        logger.info("HoleRGBDepth initialized")

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        patch_h, patch_w = inputs.shape[-2] // 14, inputs.shape[-1] // 14
        features: Any = self.pretrained.get_intermediate_layers(
            inputs,
            self.intermediate_layer_idx[self.encoder],
            return_class_token=True,
        )
        return cast(torch.Tensor, self.hole_head(features, patch_h, patch_w).squeeze(1))


class NoiseRGBDepth(RGBDDepth):
    def __init__(
        self,
        encoder: str = "vitl",
        features: int = 256,
        out_channels: Sequence[int] = (256, 512, 1024, 1024),
        use_bn: bool = False,
        use_clstoken: bool = False,
        max_depth: float = 20.0,
        pretrained: bool = False,
        pretrained_path: str | None = None,
    ) -> None:
        super().__init__(
            encoder=encoder,
            features=features,
            out_channels=out_channels,
            use_bn=use_bn,
            use_clstoken=use_clstoken,
            max_depth=max_depth,
            pretrained=pretrained,
            pretrained_path=pretrained_path,
        )
        del self.depth_pretrained
        del self.crossAtts
        del self.depth_head_rgbd
        self.depth_head_rgbd = DPTHead(
            self.pretrained.embed_dim,
            features,
            use_bn,
            out_channels=out_channels,
            use_clstoken=use_clstoken,
            sigact_out=False,
        )
        logger.info("RGBDDepth initialized")

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        patch_h, patch_w = inputs.shape[-2] // 14, inputs.shape[-1] // 14
        features: Any = self.pretrained.get_intermediate_layers(
            inputs,
            self.intermediate_layer_idx[self.encoder],
            return_class_token=True,
        )
        return functional.relu(self.depth_head_rgbd(features, patch_h, patch_w)).squeeze(1)
