"""DINOv2 cross-attention + ConvStack depth variant。"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import torch
import torch.nn.functional as functional
from loguru import logger

from ..components.fusion import aggregate_feature_tokens, fuse_cross_attention
from ..components.heads import create_convstack_head, create_convstack_neck
from .dino import RGBDDepth


class StackConvRGBDDepth(RGBDDepth):
    def __init__(
        self,
        encoder: str = "vitl",
        features: int = 256,
        out_channels: Sequence[int] = (256, 512, 1024, 1024),
        use_bn: bool = False,
        use_clstoken: bool = False,
        max_depth: float = 20.0,
        pretrained: bool = False,
        pretrained_path: str | None = None,
    ) -> None:
        super().__init__(
            encoder=encoder,
            features=features,
            out_channels=out_channels,
            use_bn=use_bn,
            use_clstoken=use_clstoken,
            max_depth=max_depth,
            pretrained=pretrained,
            pretrained_path=pretrained_path,
        )
        del self.depth_head_rgbd
        self.neck = create_convstack_neck()
        self.depth_head_rgbd = create_convstack_head(1)
        logger.info("StackConvRGBDDepth initialized")

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        rgb, depth = inputs[:, :3], inputs[:, 3:]
        patch_h, patch_w = inputs.shape[-2] // 14, inputs.shape[-1] // 14
        with torch.no_grad():
            rgb_features: Any = self.pretrained.get_intermediate_layers(
                rgb,
                self.intermediate_layer_idx[self.encoder],
                return_class_token=True,
            )
        depth_features: Any = self.depth_pretrained.get_intermediate_layers(
            depth.repeat(1, 3, 1, 1),
            self.intermediate_layer_idx[self.encoder],
            return_class_token=True,
        )
        fused = fuse_cross_attention(rgb_features, depth_features, self.crossAtts)
        feature_map = aggregate_feature_tokens(
            (feature for feature, _ in fused),
            patch_height=patch_h,
            patch_width=patch_w,
        )
        decoded = self.depth_head_rgbd(self.neck([feature_map, None, None, None, None]))[-1]
        decoded = functional.interpolate(
            decoded,
            (inputs.shape[-2], inputs.shape[-1]),
            mode="bilinear",
            align_corners=False,
            antialias=False,
        )
        return functional.relu(decoded).squeeze(1)
