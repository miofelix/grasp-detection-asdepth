"""按 ModelSpec/CatalogEntry 惰性构建模型。"""

from __future__ import annotations

import importlib
import inspect
from dataclasses import dataclass
from typing import Any

from asdepth.core import ContractError, ModelSpec

from .catalog import CatalogEntry, ModelCatalog


@dataclass(frozen=True, slots=True)
class CreatedModel:
    model: Any
    spec: ModelSpec


class ModelFactory:
    def __init__(self, catalog: ModelCatalog | None = None) -> None:
        self.catalog = catalog or ModelCatalog.from_package()

    def create_with_spec(
        self,
        model: str | ModelSpec | CatalogEntry,
        **overrides: Any,
    ) -> CreatedModel:
        if isinstance(model, str):
            entry = self.catalog.get(model)
            spec = entry.to_model_spec()
            kwargs = dict(entry.constructor_kwargs)
        elif isinstance(model, CatalogEntry):
            spec = model.to_model_spec()
            kwargs = dict(model.constructor_kwargs)
        else:
            spec = model
            raw_kwargs = spec.metadata.get("constructor_kwargs", {})
            if not isinstance(raw_kwargs, dict):
                raise ContractError("ModelSpec metadata.constructor_kwargs must be a mapping")
            kwargs = dict(raw_kwargs)
        kwargs.update(overrides)

        module_name, separator, attribute = spec.entrypoint.partition(":")
        if not separator or not module_name or not attribute:
            raise ContractError(f"invalid model entrypoint {spec.entrypoint!r}")
        module = importlib.import_module(module_name)
        constructor = getattr(module, attribute, None)
        if constructor is None or not callable(constructor):
            raise ContractError(f"model entrypoint is not callable: {spec.entrypoint}")

        signature = inspect.signature(constructor)
        accepts_arbitrary = any(
            parameter.kind is inspect.Parameter.VAR_KEYWORD
            for parameter in signature.parameters.values()
        )
        unknown = kwargs.keys() - signature.parameters.keys()
        if unknown and not accepts_arbitrary:
            raise ContractError(
                f"unknown constructor arguments for {spec.entrypoint}: {sorted(unknown)}"
            )
        instance = constructor(**kwargs)
        instance.__asdepth_model_spec__ = spec
        return CreatedModel(model=instance, spec=spec)

    def create(self, model: str | ModelSpec | CatalogEntry, **overrides: Any) -> Any:
        return self.create_with_spec(model, **overrides).model


def create_model(model_id: str, **overrides: Any) -> Any:
    """正式公共模型构建 API。"""

    return ModelFactory().create(model_id, **overrides)
