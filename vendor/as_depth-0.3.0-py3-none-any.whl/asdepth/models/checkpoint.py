"""Envelope、Accelerate 与旧 `.ckpt` 的统一只读加载。"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Any

import torch
from safetensors.torch import load_file as load_safetensors

from asdepth.artifacts import (
    CheckpointEnvelope,
    CheckpointFormat,
    safe_join,
    sha256_file,
    validate_manifest,
)
from asdepth.core import ContractError, ModelSpec
from asdepth.core.serialization import frozen_mapping

from .catalog import ModelCatalog, ResolvedModel
from .factory import ModelFactory

StateDict = dict[str, torch.Tensor]


@dataclass(frozen=True, slots=True)
class LoadedCheckpoint:
    path: Path
    checkpoint_format: CheckpointFormat
    state_dict: MappingProxyType[str, torch.Tensor]
    manifest: CheckpointEnvelope | None = None
    step: int | None = None
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)


@dataclass(frozen=True, slots=True)
class KeyMapping:
    source_prefix: str
    target_prefix: str


class StateDictKeyMapper:
    """显式、可检测碰撞的 state_dict prefix 映射。"""

    def __init__(
        self,
        mappings: tuple[KeyMapping, ...] = (),
        *,
        strip_prefixes: tuple[str, ...] = (),
    ) -> None:
        self.mappings = mappings
        self.strip_prefixes = strip_prefixes

    def map_key(self, key: str) -> str:
        result = key
        for prefix in self.strip_prefixes:
            if result.startswith(prefix):
                result = result[len(prefix) :]
        for mapping in self.mappings:
            if result.startswith(mapping.source_prefix):
                return mapping.target_prefix + result[len(mapping.source_prefix) :]
        return result

    def map(self, state_dict: Mapping[str, torch.Tensor]) -> StateDict:
        result: StateDict = {}
        for source, tensor in state_dict.items():
            target = self.map_key(source)
            if target in result:
                raise ContractError(
                    f"state_dict key mapping collision: {source!r} maps to existing {target!r}"
                )
            result[target] = tensor
        return result


def _torch_load(path: Path, *, trusted_pickle: bool = False, mmap: bool = True) -> Any:
    kwargs: dict[str, Any] = {
        "map_location": "cpu",
        "weights_only": not trusted_pickle,
    }
    if mmap:
        kwargs["mmap"] = True
    try:
        return torch.load(path, **kwargs)
    except RuntimeError:
        if not mmap:
            raise
        kwargs.pop("mmap", None)
        return torch.load(path, **kwargs)


def _extract_state_dict(payload: Any) -> StateDict:
    if not isinstance(payload, Mapping):
        raise ContractError(f"checkpoint payload must be a mapping, got {type(payload).__name__}")
    for key in ("model", "state_dict", "model_state_dict", "net"):
        candidate = payload.get(key)
        if isinstance(candidate, Mapping):
            return _tensor_mapping(candidate, context=key)
    return _tensor_mapping(payload, context="root")


def _tensor_mapping(payload: Mapping[Any, Any], *, context: str) -> StateDict:
    result: StateDict = {}
    for key, value in payload.items():
        if not isinstance(key, str) or not isinstance(value, torch.Tensor):
            raise ContractError(f"{context} is not a pure string-to-tensor state_dict")
        result[key] = value
    if not result:
        raise ContractError(f"{context} state_dict is empty")
    return result


def _checkpoint_step(payload: Any) -> int | None:
    if not isinstance(payload, Mapping):
        return None
    for name in ("global_step_idx", "global_iter_idx", "global_step", "step"):
        value = payload.get(name)
        if isinstance(value, int) and value >= 0:
            return value
    return None


def _load_state_file(path: Path, *, trusted_pickle: bool = False) -> StateDict:
    if path.suffix == ".safetensors":
        return dict(load_safetensors(path, device="cpu"))
    return _extract_state_dict(_torch_load(path, trusted_pickle=trusted_pickle))


class NewEnvelopeLoader:
    MANIFEST_NAME = "manifest.json"

    def load(self, path: Path, *, verify_checksums: bool = True) -> LoadedCheckpoint:
        directory = path.parent if path.is_file() else path
        manifest_path = path if path.is_file() else directory / self.MANIFEST_NAME
        if manifest_path.name != self.MANIFEST_NAME or not manifest_path.is_file():
            raise ContractError(f"checkpoint envelope manifest not found: {manifest_path}")
        with manifest_path.open(encoding="utf-8") as stream:
            payload = json.load(stream)
        if not isinstance(payload, dict):
            raise ContractError("checkpoint envelope manifest must be an object")
        validate_manifest(payload, "checkpoint")
        manifest = CheckpointEnvelope.from_dict(payload)
        model_path = safe_join(directory, manifest.files["model"])
        if not model_path.is_file():
            raise FileNotFoundError(model_path)
        if verify_checksums:
            expected = manifest.checksums.get("model") or manifest.checksums.get(
                manifest.files["model"]
            )
            if expected is not None and sha256_file(model_path) != expected:
                raise ContractError(f"checkpoint checksum mismatch: {model_path}")
        state_dict = _load_state_file(model_path)
        return LoadedCheckpoint(
            path=directory.resolve(),
            checkpoint_format=CheckpointFormat.ENVELOPE,
            state_dict=MappingProxyType(state_dict),
            manifest=manifest,
            step=manifest.step,
        )


def _merge_state_files(paths: list[Path]) -> StateDict:
    result: StateDict = {}
    for path in paths:
        for key, tensor in _load_state_file(path).items():
            if key in result:
                raise ContractError(f"duplicate tensor {key!r} across Accelerate shards")
            result[key] = tensor
    return result


class AccelerateLoader:
    """读取 Accelerate 常见单文件或 safetensors shard 目录。"""

    def _state_files(self, directory: Path) -> list[Path]:
        index_candidates = sorted(directory.glob("*.safetensors.index.json"))
        if index_candidates:
            with index_candidates[0].open(encoding="utf-8") as stream:
                index = json.load(stream)
            weight_map = index.get("weight_map") if isinstance(index, dict) else None
            if not isinstance(weight_map, dict):
                raise ContractError(f"invalid safetensors index: {index_candidates[0]}")
            return sorted({directory / str(value) for value in weight_map.values()})

        safetensors = sorted(
            path
            for path in directory.glob("*.safetensors")
            if "model" in path.name and "optimizer" not in path.name
        )
        if safetensors:
            return safetensors
        binaries = sorted(
            path
            for pattern in ("pytorch_model*.bin", "model*.bin", "model*.pt")
            for path in directory.glob(pattern)
            if "optimizer" not in path.name
        )
        if binaries:
            return binaries
        raise ContractError(f"no Accelerate model state found in {directory}")

    def load(self, path: Path) -> LoadedCheckpoint:
        directory = path.expanduser().resolve()
        if not directory.is_dir():
            raise NotADirectoryError(directory)
        state_files = self._state_files(directory)
        for state_file in state_files:
            if not state_file.is_file():
                raise FileNotFoundError(state_file)
        step: int | None = None
        trainer_state = directory / "trainer_state.json"
        metadata: dict[str, Any] = {"state_files": [item.name for item in state_files]}
        if trainer_state.is_file():
            with trainer_state.open(encoding="utf-8") as stream:
                trainer_payload = json.load(stream)
            step = _checkpoint_step(trainer_payload)
            metadata["trainer_state"] = trainer_payload
        return LoadedCheckpoint(
            path=directory,
            checkpoint_format=CheckpointFormat.ACCELERATE,
            state_dict=MappingProxyType(_merge_state_files(state_files)),
            step=step,
            metadata=frozen_mapping(metadata),
        )


class LegacyCkptLoader:
    def load(self, path: Path, *, trusted_pickle: bool = False) -> LoadedCheckpoint:
        checkpoint_path = path.expanduser().resolve()
        if not checkpoint_path.is_file():
            raise FileNotFoundError(checkpoint_path)
        if checkpoint_path.suffix == ".safetensors":
            payload: Any = None
            state_dict = _load_state_file(checkpoint_path)
        else:
            payload = _torch_load(checkpoint_path, trusted_pickle=trusted_pickle)
            state_dict = _extract_state_dict(payload)
        return LoadedCheckpoint(
            path=checkpoint_path,
            checkpoint_format=CheckpointFormat.LEGACY_CKPT,
            state_dict=MappingProxyType(state_dict),
            step=_checkpoint_step(payload),
        )


class CheckpointLoader:
    def load(
        self,
        path: str | Path,
        *,
        verify_checksums: bool = True,
        trusted_pickle: bool = False,
    ) -> LoadedCheckpoint:
        resolved = Path(path).expanduser().resolve()
        if resolved.is_dir() and (resolved / NewEnvelopeLoader.MANIFEST_NAME).is_file():
            return NewEnvelopeLoader().load(resolved, verify_checksums=verify_checksums)
        if resolved.is_file() and resolved.name == NewEnvelopeLoader.MANIFEST_NAME:
            return NewEnvelopeLoader().load(resolved, verify_checksums=verify_checksums)
        if resolved.is_dir():
            return AccelerateLoader().load(resolved)
        return LegacyCkptLoader().load(resolved, trusted_pickle=trusted_pickle)


@dataclass(frozen=True, slots=True)
class ModelLoadReport:
    model: torch.nn.Module
    spec: ModelSpec
    resolution: ResolvedModel
    checkpoint: LoadedCheckpoint
    missing_keys: tuple[str, ...]
    unexpected_keys: tuple[str, ...]


def load_model_with_report(
    checkpoint: str | Path,
    *,
    model_id: str | None = None,
    device: str | torch.device = "cpu",
    strict: bool = False,
    verify_checksums: bool = True,
    trusted_pickle: bool = False,
    key_mapper: StateDictKeyMapper | None = None,
    catalog: ModelCatalog | None = None,
) -> ModelLoadReport:
    active_catalog = catalog or ModelCatalog.from_package()
    loaded = CheckpointLoader().load(
        checkpoint,
        verify_checksums=verify_checksums,
        trusted_pickle=trusted_pickle,
    )
    resolution = active_catalog.resolve(
        checkpoint_manifest=loaded.manifest,
        model_id=model_id,
        checkpoint_path=checkpoint,
    )
    created = ModelFactory(active_catalog).create_with_spec(resolution.spec)
    if not isinstance(created.model, torch.nn.Module):
        raise ContractError(
            f"model entrypoint did not create torch.nn.Module: {resolution.spec.entrypoint}"
        )
    mapper = key_mapper or StateDictKeyMapper(strip_prefixes=("module.", "state_dict."))
    state_dict = mapper.map(loaded.state_dict)
    incompatible = created.model.load_state_dict(state_dict, strict=strict)
    model = created.model.to(device).eval()
    return ModelLoadReport(
        model=model,
        spec=created.spec,
        resolution=resolution,
        checkpoint=loaded,
        missing_keys=tuple(incompatible.missing_keys),
        unexpected_keys=tuple(incompatible.unexpected_keys),
    )


def load_model(
    checkpoint: str | Path,
    *,
    model_id: str | None = None,
    device: str | torch.device = "cpu",
    strict: bool = False,
    verify_checksums: bool = True,
    trusted_pickle: bool = False,
) -> torch.nn.Module:
    """正式公共 checkpoint 加载 API。"""

    return load_model_with_report(
        checkpoint,
        model_id=model_id,
        device=device,
        strict=strict,
        verify_checksums=verify_checksums,
        trusted_pickle=trusted_pickle,
    ).model
