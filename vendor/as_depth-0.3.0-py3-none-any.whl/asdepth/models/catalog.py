"""Canonical model catalog 与旧 registry 路径 fallback。"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from enum import Enum
from importlib import resources
from pathlib import Path
from types import MappingProxyType
from typing import Any, cast

import yaml

from asdepth.artifacts import CheckpointEnvelope
from asdepth.core import ContractError, DepthSpec, ModelSpec, TensorSpec
from asdepth.core.serialization import frozen_mapping, to_primitive


class ModelResolutionError(ContractError):
    """checkpoint manifest、CLI 和旧路径均不能唯一确定模型。"""


class ResolutionSource(str, Enum):
    CHECKPOINT_MANIFEST = "checkpoint_manifest"
    CLI_MODEL = "cli_model"
    LEGACY_REGISTRY = "legacy_registry"


@dataclass(frozen=True, slots=True)
class LegacyRegistryEntry:
    name: str
    path_patterns: tuple[str, ...]


def _canonical_hash(value: dict[str, Any]) -> str:
    payload = json.dumps(
        to_primitive(value),
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _depth_spec(value: str) -> DepthSpec:
    if value == "metric_depth":
        return DepthSpec.metric()
    if value == "inverse_depth":
        return DepthSpec.inverse()
    raise ContractError(f"catalog does not support depth representation {value!r}")


def _auxiliary_tensor(payload: dict[str, Any]) -> TensorSpec:
    values = dict(payload)
    values.setdefault("optional", False)
    return TensorSpec.from_dict(values)


@dataclass(frozen=True, slots=True)
class CatalogEntry:
    """模型构造信息、正式身份和旧 registry 名称。"""

    model_id: str
    model_version: str
    entrypoint: str
    constructor_kwargs: MappingProxyType[str, Any]
    depth: DepthSpec
    legacy_registry_name: str
    auxiliary_outputs: tuple[TensorSpec, ...] = ()
    metadata: MappingProxyType[str, Any] = field(default_factory=frozen_mapping)

    def __post_init__(self) -> None:
        if not self.model_id or not self.model_version or ":" not in self.entrypoint:
            raise ContractError("catalog entry requires model_id, model_version, and module:class")
        if not isinstance(self.constructor_kwargs, MappingProxyType):
            object.__setattr__(
                self,
                "constructor_kwargs",
                frozen_mapping(dict(self.constructor_kwargs)),
            )
        object.__setattr__(self, "auxiliary_outputs", tuple(self.auxiliary_outputs))
        if not isinstance(self.metadata, MappingProxyType):
            object.__setattr__(self, "metadata", frozen_mapping(dict(self.metadata)))

    @property
    def config_hash(self) -> str:
        return _canonical_hash(
            {
                "entrypoint": self.entrypoint,
                "constructor_kwargs": dict(self.constructor_kwargs),
                "depth": self.depth.to_dict(),
                "auxiliary_outputs": [item.to_dict() for item in self.auxiliary_outputs],
            }
        )

    def to_model_spec(self) -> ModelSpec:
        representation = self.depth.representation.value
        primary_output = TensorSpec(
            name=representation,
            dtype="float32",
            shape=("N", "H", "W"),
            layout="NHW",
            semantic=representation,
        )
        model_metadata = dict(self.metadata)
        model_metadata.update(
            {
                "constructor_kwargs": dict(self.constructor_kwargs),
                "legacy_registry_name": self.legacy_registry_name,
            }
        )
        return ModelSpec(
            model_id=self.model_id,
            model_version=self.model_version,
            config_hash=self.config_hash,
            entrypoint=self.entrypoint,
            inputs=(
                TensorSpec(
                    name="rgbd_input",
                    dtype="float32",
                    shape=("N", 4, "H", "W"),
                    layout="NCHW",
                    semantic="normalized_rgb_plus_depth",
                ),
            ),
            outputs=(primary_output, *self.auxiliary_outputs),
            depth=self.depth,
            metadata=frozen_mapping(model_metadata),
        )


@dataclass(frozen=True, slots=True)
class ResolvedModel:
    spec: ModelSpec
    source: ResolutionSource
    catalog_entry: CatalogEntry | None


def legacy_registry_path() -> Path:
    """返回随 ``asdepth`` 包安装的历史 checkpoint 路径映射。"""

    resource = resources.files("asdepth.resources").joinpath("catalog/legacy-model-registry.yaml")
    path = Path(str(resource))
    if not path.is_file():
        raise FileNotFoundError("AS-Depth legacy model registry is missing from package data")
    return path


def load_legacy_registry(path: Path | None = None) -> dict[str, LegacyRegistryEntry]:
    registry_path = legacy_registry_path() if path is None else path.expanduser().resolve()
    with registry_path.open(encoding="utf-8") as stream:
        payload = yaml.safe_load(stream)
    if not isinstance(payload, dict) or not isinstance(payload.get("models"), list):
        raise ContractError(f"invalid legacy model registry: {registry_path}")
    entries: dict[str, LegacyRegistryEntry] = {}
    for raw in payload["models"]:
        name = str(raw["name"])
        if name in entries:
            raise ContractError(f"duplicate legacy registry entry {name!r}")
        entries[name] = LegacyRegistryEntry(
            name=name,
            path_patterns=tuple(str(pattern) for pattern in raw["path_patterns"]),
        )
    return entries


class ModelCatalog:
    """Canonical entries are primary; path matching is an isolated fallback."""

    def __init__(
        self,
        entries: tuple[CatalogEntry, ...],
        legacy_registry: dict[str, LegacyRegistryEntry] | None = None,
    ) -> None:
        self._entries = entries
        self._by_id = {entry.model_id: entry for entry in entries}
        if len(self._by_id) != len(entries):
            raise ContractError("canonical model catalog contains duplicate model_id values")
        self._by_legacy_name = {entry.legacy_registry_name: entry for entry in entries}
        if len(self._by_legacy_name) != len(entries):
            raise ContractError("canonical model catalog contains duplicate legacy names")
        self._legacy_registry = dict(legacy_registry or {})
        if legacy_registry is not None:
            missing = self._legacy_registry.keys() - self._by_legacy_name.keys()
            unmapped = self._by_legacy_name.keys() - self._legacy_registry.keys()
            if missing or unmapped:
                raise ContractError(
                    "canonical/legacy registry mismatch: "
                    f"missing canonical={sorted(missing)}, missing legacy={sorted(unmapped)}"
                )

    @classmethod
    def from_package(cls, *, legacy_path: Path | None = None) -> ModelCatalog:
        resource = resources.files("asdepth.resources").joinpath("catalog/models.yaml")
        payload = yaml.safe_load(resource.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("schema_version") != "1.0.0":
            raise ContractError("unsupported or malformed model catalog")
        model_version = str(payload["model_version"])
        raw_models = payload.get("models")
        if not isinstance(raw_models, list):
            raise ContractError("model catalog models must be a list")

        legacy_registry = load_legacy_registry(legacy_path)
        entries: list[CatalogEntry] = []
        for raw in raw_models:
            if not isinstance(raw, dict):
                raise ContractError("model catalog entries must be mappings")
            auxiliary = tuple(
                _auxiliary_tensor(cast(dict[str, Any], item))
                for item in raw.get("auxiliary_outputs", [])
            )
            legacy_name = str(raw["legacy_registry_name"])
            if legacy_name not in legacy_registry:
                raise ContractError(
                    f"catalog model {raw['model_id']!r} has no legacy registry entry"
                )
            entry_metadata = dict(raw.get("metadata", {}))
            entries.append(
                CatalogEntry(
                    model_id=str(raw["model_id"]),
                    model_version=model_version,
                    entrypoint=str(raw["entrypoint"]),
                    constructor_kwargs=frozen_mapping(dict(raw["constructor_kwargs"])),
                    depth=_depth_spec(str(raw["depth_representation"])),
                    legacy_registry_name=legacy_name,
                    auxiliary_outputs=auxiliary,
                    metadata=frozen_mapping(entry_metadata),
                )
            )
        return cls(tuple(entries), legacy_registry)

    @property
    def entries(self) -> tuple[CatalogEntry, ...]:
        return self._entries

    def get(self, identifier: str) -> CatalogEntry:
        try:
            return self._by_id[identifier]
        except KeyError:
            try:
                return self._by_legacy_name[identifier]
            except KeyError as exc:
                raise ModelResolutionError(
                    f"unknown model {identifier!r}; available IDs: {sorted(self._by_id)}"
                ) from exc

    def match_legacy_path(self, checkpoint_path: str | Path) -> CatalogEntry:
        value = os.path.expanduser(str(checkpoint_path)).replace("\\", "/")
        matches: list[tuple[int, CatalogEntry, str]] = []
        for legacy_name, legacy in self._legacy_registry.items():
            entry = self._by_legacy_name[legacy_name]
            for pattern in legacy.path_patterns:
                if pattern in value:
                    matches.append((len(pattern), entry, pattern))
        if not matches:
            raise ModelResolutionError(f"no legacy registry path matches checkpoint {value!r}")
        best_length = max(length for length, _, _ in matches)
        best = [(entry, pattern) for length, entry, pattern in matches if length == best_length]
        model_ids = {entry.model_id for entry, _ in best}
        if len(model_ids) != 1:
            detail = [(entry.model_id, pattern) for entry, pattern in best]
            raise ModelResolutionError(f"ambiguous longest legacy path match: {detail}")
        return best[0][0]

    def resolve(
        self,
        *,
        checkpoint_manifest: CheckpointEnvelope | None = None,
        model_id: str | None = None,
        checkpoint_path: str | Path | None = None,
    ) -> ResolvedModel:
        """manifest > CLI model > legacy registry fallback > error。"""

        if checkpoint_manifest is not None:
            try:
                entry = self.get(checkpoint_manifest.model.model_id)
            except ModelResolutionError:
                entry = None
            return ResolvedModel(
                spec=checkpoint_manifest.model,
                source=ResolutionSource.CHECKPOINT_MANIFEST,
                catalog_entry=entry,
            )
        if model_id is not None:
            entry = self.get(model_id)
            return ResolvedModel(
                spec=entry.to_model_spec(),
                source=ResolutionSource.CLI_MODEL,
                catalog_entry=entry,
            )
        if checkpoint_path is not None:
            entry = self.match_legacy_path(checkpoint_path)
            return ResolvedModel(
                spec=entry.to_model_spec(),
                source=ResolutionSource.LEGACY_REGISTRY,
                catalog_entry=entry,
            )
        raise ModelResolutionError(
            "model identity is missing: provide a checkpoint manifest, --model, or a legacy path match"
        )
