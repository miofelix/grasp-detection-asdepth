"""框架无关 runtime 协议、批输出和错误类型。"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Protocol

from asdepth.core import ContractError, ModelSpec


class RuntimeBackendKind(str, Enum):
    """正式支持的 runtime 后端。"""

    TORCH = "torch"
    ONNX = "onnx"
    TENSORRT = "tensorrt"


class RuntimeDependencyError(RuntimeError):
    """请求的可选 runtime 依赖未安装或不可用。"""


@dataclass(frozen=True, slots=True)
class RuntimeBatchOutput:
    """RuntimeBackend 的原始批输出和批级计时。"""

    values: Any
    timings_ms: MappingProxyType[str, float] = field(default_factory=lambda: MappingProxyType({}))

    def __post_init__(self) -> None:
        timings = {str(name): float(value) for name, value in self.timings_ms.items()}
        if any(value < 0 for value in timings.values()):
            raise ContractError("runtime timings cannot be negative")
        object.__setattr__(self, "timings_ms", MappingProxyType(timings))


class RuntimeBackend(Protocol):
    """推理、部署与 realtime 共用的最小 runtime 接口。"""

    @property
    def model_spec(self) -> ModelSpec: ...

    def infer(self, inputs: Any) -> RuntimeBatchOutput: ...


def require_single_rgbd_input(model_spec: ModelSpec) -> None:
    """校验当前活跃部署主线的 host-preprocess 单输入契约。"""

    if len(model_spec.inputs) != 1:
        raise ContractError("runtime requires exactly one model input")
    spec = model_spec.inputs[0]
    if spec.name != "rgbd_input" or len(spec.shape) != 4 or spec.shape[1] != 4:
        raise ContractError(
            "runtime input must be NCHW rgbd_input with four channels; "
            f"got name={spec.name!r}, shape={spec.shape}"
        )
