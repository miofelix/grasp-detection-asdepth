"""正式 ``create_runtime`` 工厂。"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from asdepth.core import ContractError, ModelSpec

from .base import RuntimeBackend, RuntimeBackendKind
from .onnx import ONNXBackend
from .tensorrt import TensorRTBackend, TensorRTRunner
from .torch import TorchBackend


def create_runtime(
    backend: RuntimeBackendKind | str,
    *,
    model_spec: ModelSpec,
    model: Any | None = None,
    artifact: str | Path | None = None,
    device: str = "cpu",
    providers: tuple[str, ...] | None = None,
    runner: TensorRTRunner | None = None,
) -> RuntimeBackend:
    """按显式 backend 创建 runtime，不从 checkpoint 文件名推断模型身份。"""

    kind = backend if isinstance(backend, RuntimeBackendKind) else RuntimeBackendKind(backend)
    if kind is RuntimeBackendKind.TORCH:
        if model is None:
            raise ContractError("Torch runtime requires an already constructed model")
        return TorchBackend(model, model_spec, device=device)
    if artifact is None:
        raise ContractError(f"{kind.value} runtime requires an artifact path")
    if kind is RuntimeBackendKind.ONNX:
        return ONNXBackend(artifact, model_spec, providers=providers)
    return TensorRTBackend(
        artifact,
        model_spec,
        device=device,
        runner=runner,
    )
