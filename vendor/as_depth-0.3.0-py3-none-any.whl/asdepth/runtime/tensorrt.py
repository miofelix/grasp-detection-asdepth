"""TensorRT 单输入 runtime；TensorRT/CUDA 依赖保持惰性加载。"""

from __future__ import annotations

import ctypes
import time
from contextlib import suppress
from pathlib import Path
from types import MappingProxyType
from typing import Any, Protocol, cast

import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError, ModelSpec

from .base import (
    RuntimeBatchOutput,
    RuntimeDependencyError,
    require_single_rgbd_input,
)


class TensorRTRunner(Protocol):
    """测试注入和平台特化 runner 所需的最小接口。"""

    @property
    def input_shape(self) -> tuple[int, ...]: ...

    def infer(self, inputs: Any) -> Any: ...

    def close(self) -> None: ...


def _parse_cuda_device(value: str) -> int:
    if value == "cuda":
        return 0
    if value.startswith("cuda:"):
        try:
            index = int(value.split(":", 1)[1])
        except ValueError as exc:
            raise ContractError(f"invalid CUDA device {value!r}") from exc
        if index < 0:
            raise ContractError(f"invalid CUDA device {value!r}")
        return index
    raise ContractError(f"TensorRT requires a CUDA device, got {value!r}")


class _CudaRuntime:
    _LIBRARIES = (
        "libcudart.so",
        "libcudart.so.13",
        "libcudart.so.12",
        "libcudart.so.11.0",
    )

    def __init__(self) -> None:
        last_error: OSError | None = None
        for name in self._LIBRARIES:
            try:
                self.lib = ctypes.CDLL(name)
                break
            except OSError as exc:
                last_error = exc
        else:
            raise RuntimeDependencyError(f"cannot load CUDA runtime: {last_error}")

        void = ctypes.c_void_p
        integer = ctypes.c_int
        size = ctypes.c_size_t
        self.lib.cudaSetDevice.argtypes = [integer]
        self.lib.cudaSetDevice.restype = integer
        self.lib.cudaMalloc.argtypes = [ctypes.POINTER(void), size]
        self.lib.cudaMalloc.restype = integer
        self.lib.cudaFree.argtypes = [void]
        self.lib.cudaFree.restype = integer
        self.lib.cudaMemcpyAsync.argtypes = [void, void, size, integer, void]
        self.lib.cudaMemcpyAsync.restype = integer
        self.lib.cudaStreamCreate.argtypes = [ctypes.POINTER(void)]
        self.lib.cudaStreamCreate.restype = integer
        self.lib.cudaStreamDestroy.argtypes = [void]
        self.lib.cudaStreamDestroy.restype = integer
        self.lib.cudaStreamSynchronize.argtypes = [void]
        self.lib.cudaStreamSynchronize.restype = integer
        self.lib.cudaGetErrorString.argtypes = [integer]
        self.lib.cudaGetErrorString.restype = ctypes.c_char_p

    def _check(self, code: int, operation: str) -> None:
        if code == 0:
            return
        raw = self.lib.cudaGetErrorString(code)
        message = raw.decode("utf-8") if raw else str(code)
        raise RuntimeError(f"{operation} failed: {message}")

    def set_device(self, index: int) -> None:
        self._check(self.lib.cudaSetDevice(index), "cudaSetDevice")

    def malloc(self, size: int) -> int:
        pointer = ctypes.c_void_p()
        self._check(self.lib.cudaMalloc(ctypes.byref(pointer), size), "cudaMalloc")
        if pointer.value is None:
            raise RuntimeError("cudaMalloc returned a null pointer")
        return int(pointer.value)

    def free(self, pointer: int | None) -> None:
        if pointer:
            self._check(self.lib.cudaFree(ctypes.c_void_p(pointer)), "cudaFree")

    def stream_create(self) -> int:
        stream = ctypes.c_void_p()
        self._check(self.lib.cudaStreamCreate(ctypes.byref(stream)), "cudaStreamCreate")
        if stream.value is None:
            raise RuntimeError("cudaStreamCreate returned a null stream")
        return int(stream.value)

    def stream_destroy(self, stream: int | None) -> None:
        if stream:
            self._check(
                self.lib.cudaStreamDestroy(ctypes.c_void_p(stream)),
                "cudaStreamDestroy",
            )

    def synchronize(self, stream: int) -> None:
        self._check(
            self.lib.cudaStreamSynchronize(ctypes.c_void_p(stream)),
            "cudaStreamSynchronize",
        )

    def copy_host_to_device(self, target: int, source: NDArray[Any], stream: int) -> None:
        self._check(
            self.lib.cudaMemcpyAsync(
                ctypes.c_void_p(target),
                ctypes.c_void_p(int(source.ctypes.data)),
                source.nbytes,
                1,
                ctypes.c_void_p(stream),
            ),
            "cudaMemcpyAsync(H2D)",
        )

    def copy_device_to_host(self, target: NDArray[Any], source: int, stream: int) -> None:
        self._check(
            self.lib.cudaMemcpyAsync(
                ctypes.c_void_p(int(target.ctypes.data)),
                ctypes.c_void_p(source),
                target.nbytes,
                2,
                ctypes.c_void_p(stream),
            ),
            "cudaMemcpyAsync(D2H)",
        )


def _trt_dtype_to_numpy(trt: Any, value: Any) -> np.dtype[Any]:
    mapping: dict[Any, Any] = {
        trt.DataType.FLOAT: np.float32,
        trt.DataType.HALF: np.float16,
        trt.DataType.INT32: np.int32,
        trt.DataType.BOOL: np.bool_,
        trt.DataType.INT8: np.int8,
    }
    for name, dtype in (("INT64", np.int64), ("UINT8", np.uint8)):
        if hasattr(trt.DataType, name):
            mapping[getattr(trt.DataType, name)] = dtype
    try:
        return cast(np.dtype[Any], np.dtype(mapping[value]))
    except KeyError as exc:
        raise RuntimeError(f"unsupported TensorRT dtype {value}") from exc


def _numpy(value: Any) -> NDArray[Any]:
    try:
        import torch
    except ImportError:  # pragma: no cover - torch is a base dependency
        torch = None  # type: ignore[assignment]
    if torch is not None and isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


class _TensorRTEngineRunner:
    """基于 TensorRT v3 tensor API 与 libcudart 的通用静态/动态 runner。"""

    def __init__(self, engine_path: Path, *, device: str) -> None:
        try:
            import tensorrt as trt
        except ImportError as exc:
            raise RuntimeDependencyError(
                "TensorRTBackend requires NVIDIA TensorRT Python bindings and libcudart"
            ) from exc

        self._trt = trt
        self._cuda = _CudaRuntime()
        self._device_index = _parse_cuda_device(device)
        self._cuda.set_device(self._device_index)
        self._stream: int | None = self._cuda.stream_create()
        logger = trt.Logger(trt.Logger.WARNING)
        runtime = trt.Runtime(logger)
        engine = runtime.deserialize_cuda_engine(engine_path.read_bytes())
        if engine is None:
            self.close()
            raise RuntimeError(f"failed to deserialize TensorRT engine: {engine_path}")
        context = engine.create_execution_context()
        if context is None:
            self.close()
            raise RuntimeError(f"failed to create TensorRT context: {engine_path}")
        self._runtime = runtime
        self._engine = engine
        self._context = context

        names = tuple(engine.get_tensor_name(index) for index in range(engine.num_io_tensors))
        self._input_names = tuple(
            name for name in names if engine.get_tensor_mode(name) == trt.TensorIOMode.INPUT
        )
        self._output_names = tuple(
            name for name in names if engine.get_tensor_mode(name) == trt.TensorIOMode.OUTPUT
        )
        if self._input_names != ("rgbd_input",) or len(self._output_names) != 1:
            self.close()
            raise ContractError(
                "TensorRT engine must use host preprocess with one rgbd_input and one output; "
                f"inputs={self._input_names}, outputs={self._output_names}"
            )
        self._input_name = self._input_names[0]
        self._output_name = self._output_names[0]
        raw_input_shape = tuple(int(item) for item in engine.get_tensor_shape(self._input_name))
        if any(item < 0 for item in raw_input_shape):
            try:
                _minimum, optimum, _maximum = engine.get_tensor_profile_shape(
                    self._input_name,
                    0,
                )
            except (AttributeError, RuntimeError) as exc:
                self.close()
                raise ContractError(
                    "TensorRT dynamic rgbd_input requires an optimization profile"
                ) from exc
            raw_input_shape = tuple(int(item) for item in optimum)
        if (
            len(raw_input_shape) != 4
            or raw_input_shape[1] != 4
            or any(item <= 0 for item in raw_input_shape)
        ):
            self.close()
            raise ContractError(
                "TensorRT rgbd_input must resolve to positive NCHW C=4 shape; "
                f"got {raw_input_shape}"
            )
        self._input_shape = raw_input_shape
        self._input_dtype = _trt_dtype_to_numpy(trt, engine.get_tensor_dtype(self._input_name))
        self._output_dtype = _trt_dtype_to_numpy(trt, engine.get_tensor_dtype(self._output_name))
        if self._input_dtype not in {np.dtype(np.float16), np.dtype(np.float32)}:
            self.close()
            raise ContractError(
                f"TensorRT rgbd_input must use float16 or float32, got {self._input_dtype}"
            )
        if self._output_dtype not in {np.dtype(np.float16), np.dtype(np.float32)}:
            self.close()
            raise ContractError(
                f"TensorRT depth output must use float16 or float32, got {self._output_dtype}"
            )
        self._input_pointer: int | None = None
        self._output_pointer: int | None = None
        self._input_capacity = 0
        self._output_capacity = 0

    @property
    def input_shape(self) -> tuple[int, ...]:
        return self._input_shape

    def _allocate(self, input_bytes: int, output_bytes: int) -> None:
        if input_bytes > self._input_capacity:
            self._cuda.free(self._input_pointer)
            self._input_pointer = self._cuda.malloc(input_bytes)
            self._input_capacity = input_bytes
        if output_bytes > self._output_capacity:
            self._cuda.free(self._output_pointer)
            self._output_pointer = self._cuda.malloc(output_bytes)
            self._output_capacity = output_bytes

    def infer(self, inputs: Any) -> NDArray[Any]:
        value = np.ascontiguousarray(_numpy(inputs), dtype=self._input_dtype)
        if value.ndim != 4 or value.shape[1] != 4:
            raise ContractError(f"TensorRT rgbd_input must be NCHW C=4, got {value.shape}")
        if not self._context.set_input_shape(self._input_name, tuple(value.shape)):
            raise ContractError(f"TensorRT rejected input shape {value.shape}")
        output_shape = tuple(
            int(item) for item in self._context.get_tensor_shape(self._output_name)
        )
        if not output_shape or any(item <= 0 for item in output_shape):
            raise ContractError(f"TensorRT output shape is unresolved: {output_shape}")
        output = np.empty(output_shape, dtype=self._output_dtype)
        self._allocate(value.nbytes, output.nbytes)
        assert self._input_pointer is not None
        assert self._output_pointer is not None
        assert self._stream is not None
        self._context.set_tensor_address(self._input_name, self._input_pointer)
        self._context.set_tensor_address(self._output_name, self._output_pointer)
        self._cuda.copy_host_to_device(self._input_pointer, value, self._stream)
        if not self._context.execute_async_v3(self._stream):
            raise RuntimeError("TensorRT execute_async_v3 failed")
        self._cuda.copy_device_to_host(output, self._output_pointer, self._stream)
        self._cuda.synchronize(self._stream)
        return output

    def close(self) -> None:
        cuda = getattr(self, "_cuda", None)
        if cuda is None:
            return
        cuda.free(getattr(self, "_input_pointer", None))
        cuda.free(getattr(self, "_output_pointer", None))
        self._input_pointer = None
        self._output_pointer = None
        cuda.stream_destroy(getattr(self, "_stream", None))
        self._stream = None

    def __del__(self) -> None:  # pragma: no cover - best-effort interpreter cleanup
        with suppress(Exception):
            self.close()


class TensorRTBackend:
    """把 host-preprocess 的单输入 TensorRT engine 适配为 RuntimeBackend。"""

    def __init__(
        self,
        engine_path: str | Path,
        model_spec: ModelSpec,
        *,
        device: str = "cuda",
        runner: TensorRTRunner | None = None,
    ) -> None:
        require_single_rgbd_input(model_spec)
        if len(model_spec.outputs) != 1:
            raise ContractError("canonical TensorRTBackend currently requires one output")
        path = Path(engine_path).expanduser().resolve()
        if runner is None and not path.is_file():
            raise FileNotFoundError(path)
        self.path = path
        self._model_spec = model_spec
        self._runner = runner or _TensorRTEngineRunner(path, device=device)

    @property
    def model_spec(self) -> ModelSpec:
        return self._model_spec

    @property
    def input_shape(self) -> tuple[int, ...]:
        """返回 engine 的静态 shape 或动态 profile optimum shape。"""

        value = getattr(self._runner, "input_shape", None)
        if value is not None:
            shape = tuple(int(item) for item in value)
        else:
            declared = self.model_spec.inputs[0].shape
            if not all(isinstance(item, int) for item in declared):
                raise ContractError(
                    "TensorRT runner does not expose input_shape and ModelSpec is dynamic"
                )
            shape = cast(tuple[int, ...], declared)
        if len(shape) != 4 or shape[1] != 4 or any(item <= 0 for item in shape):
            raise ContractError(f"invalid TensorRT rgbd_input shape: {shape}")
        return shape

    def infer(self, inputs: Any) -> RuntimeBatchOutput:
        started = time.perf_counter()
        values = self._runner.infer(inputs)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        return RuntimeBatchOutput(
            values=values,
            timings_ms=MappingProxyType({"forward_batch": elapsed_ms}),
        )

    def close(self) -> None:
        self._runner.close()

    def __enter__(self) -> TensorRTBackend:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
