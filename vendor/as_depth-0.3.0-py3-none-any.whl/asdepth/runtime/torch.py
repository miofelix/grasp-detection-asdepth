"""设备无关的 PyTorch runtime 后端。"""

from __future__ import annotations

import time
from types import MappingProxyType
from typing import Any

import torch

from asdepth.core import ContractError, ModelSpec

from .base import RuntimeBatchOutput


class TorchBackend:
    """把已加载的 ``torch.nn.Module`` 适配为 RuntimeBackend。"""

    def __init__(
        self,
        model: torch.nn.Module,
        model_spec: ModelSpec,
        *,
        device: str | torch.device = "cpu",
    ) -> None:
        if not isinstance(model, torch.nn.Module):
            raise ContractError("TorchBackend requires torch.nn.Module")
        self._model_spec = model_spec
        self.device = torch.device(device)
        self.model = model.to(self.device).eval()

    @property
    def model_spec(self) -> ModelSpec:
        return self._model_spec

    def _synchronize(self) -> None:
        if self.device.type == "cuda" and torch.cuda.is_available():
            torch.cuda.synchronize(self.device)

    def infer(self, inputs: Any) -> RuntimeBatchOutput:
        if not isinstance(inputs, torch.Tensor):
            raise ContractError("TorchBackend inputs must be torch.Tensor")
        prepared = inputs.to(self.device, non_blocking=self.device.type == "cuda")
        self._synchronize()
        started = time.perf_counter()
        with torch.inference_mode():
            values = self.model(prepared)
        self._synchronize()
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        return RuntimeBatchOutput(
            values=values,
            timings_ms=MappingProxyType({"forward_batch": elapsed_ms}),
        )
