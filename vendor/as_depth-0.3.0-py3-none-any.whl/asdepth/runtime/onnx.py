"""ONNX Runtime 后端；可选依赖只在实例化时加载。"""

from __future__ import annotations

import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from types import MappingProxyType
from typing import Any

import numpy as np
from numpy.typing import NDArray

from asdepth.core import ContractError, ModelSpec

from .base import RuntimeBatchOutput, RuntimeDependencyError


def _numpy(value: Any) -> NDArray[Any]:
    try:
        import torch
    except ImportError:  # pragma: no cover - torch is a base dependency
        torch = None  # type: ignore[assignment]
    if torch is not None and isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy()
    return np.asarray(value)


class ONNXBackend:
    """通过 ``onnxruntime.InferenceSession`` 执行 ModelSpec 声明的 IO。"""

    def __init__(
        self,
        model_path: str | Path,
        model_spec: ModelSpec,
        *,
        providers: Sequence[str] | None = None,
        session_options: Any | None = None,
    ) -> None:
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        try:
            import onnxruntime as ort
        except ImportError as exc:
            raise RuntimeDependencyError(
                "ONNXBackend requires the 'export' extra: pip install 'as-depth[export]'"
            ) from exc

        selected = list(providers or ("CPUExecutionProvider",))
        available = set(ort.get_available_providers())
        missing = set(selected) - available
        if missing:
            raise RuntimeDependencyError(
                f"requested ONNX Runtime providers are unavailable: {sorted(missing)}; "
                f"available={sorted(available)}"
            )
        self._model_spec = model_spec
        self.path = path
        self.providers = tuple(selected)
        self.session = ort.InferenceSession(
            str(path),
            sess_options=session_options,
            providers=selected,
        )
        self._input_names = tuple(item.name for item in self.session.get_inputs())
        self._output_names = tuple(item.name for item in self.session.get_outputs())
        expected_inputs = tuple(item.name for item in model_spec.inputs)
        if self._input_names != expected_inputs:
            raise ContractError(
                f"ONNX inputs do not match ModelSpec: expected={expected_inputs}, "
                f"actual={self._input_names}"
            )
        if len(self._output_names) != len(model_spec.outputs):
            raise ContractError(
                "ONNX output count does not match ModelSpec: "
                f"expected={len(model_spec.outputs)}, actual={len(self._output_names)}"
            )
        model_output_names = tuple(item.name for item in model_spec.outputs)
        # Deployment intentionally normalizes the sole public output name to
        # ``depth``.  Catalog ModelSpec values keep the richer semantic name
        # (usually ``metric_depth``), so a single-output graph is mapped by
        # position.  Multi-output models still require exact names to avoid an
        # ambiguous auxiliary-output mapping.
        names_match = self._output_names == model_output_names
        is_deployment_single_output = (
            len(self._output_names) == 1 and self._output_names[0] == "depth"
        )
        if not names_match and not is_deployment_single_output:
            raise ContractError(
                f"ONNX outputs do not match ModelSpec: expected={model_output_names}, "
                f"actual={self._output_names}"
            )

    @property
    def model_spec(self) -> ModelSpec:
        return self._model_spec

    def _feeds(self, inputs: Any) -> dict[str, NDArray[Any]]:
        if isinstance(inputs, Mapping):
            feeds = {str(name): _numpy(value) for name, value in inputs.items()}
        elif len(self._input_names) == 1:
            feeds = {self._input_names[0]: _numpy(inputs)}
        elif isinstance(inputs, tuple | list):
            if len(inputs) != len(self._input_names):
                raise ContractError("ONNX input count does not match ModelSpec")
            feeds = {
                name: _numpy(value) for name, value in zip(self._input_names, inputs, strict=True)
            }
        else:
            raise ContractError("multi-input ONNX runtime requires a mapping or sequence")

        if set(feeds) != set(self._input_names):
            raise ContractError(
                f"ONNX input names do not match: expected={self._input_names}, "
                f"actual={tuple(feeds)}"
            )
        for spec in self.model_spec.inputs:
            value = feeds[spec.name]
            if not spec.matches(value):
                raise ContractError(
                    f"ONNX input {spec.name!r} violates TensorSpec: "
                    f"shape={value.shape}, dtype={value.dtype}"
                )
        return feeds

    def infer(self, inputs: Any) -> RuntimeBatchOutput:
        feeds = self._feeds(inputs)
        started = time.perf_counter()
        outputs = self.session.run(list(self._output_names), feeds)
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        values: Any
        if len(outputs) == 1:
            values = outputs[0]
        else:
            values = {
                spec.name: value
                for spec, value in zip(self.model_spec.outputs, outputs, strict=True)
            }
        return RuntimeBatchOutput(
            values=values,
            timings_ms=MappingProxyType({"forward_batch": elapsed_ms}),
        )
